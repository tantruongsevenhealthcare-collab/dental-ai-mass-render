# HƯỚNG DẪN VẬN HÀNH THỰC TẾ (PRODUCTION MANUAL)
## Hệ thống Đa tác nhân AI (Zero-Touch MAS) - 24 Seven Health Care Vietnam
**Địa điểm kho trung tâm:** 17 Phạm Vấn | **Website:** https://www.24sevenhc.com.vn/ | **Hotline/Zalo:** 0963166698

---

### 1. Tổng quan hệ thống và Mục tiêu Kinh doanh
Hệ thống Multi-Agent System (MAS) được thiết kế theo mô hình **Zero-Touch** (không ôm hàng, tự động hóa toàn bộ quy trình kinh doanh vật tư & thiết bị nha khoa) nhằm đạt KPI doanh số **300 triệu VNĐ/tháng** (~10 triệu VNĐ/ngày). Hệ thống bao gồm 5 AI Agent chuyên biệt:
1. **AI CEO**: Tổng hợp báo cáo 08:00 sáng, chạy Decision Engine kiểm duyệt tự động có điều kiện, quản lý đàm phán đối tác và giám sát đơn kẹt > 24h.
2. **AI Marketing**: Nghiên cứu thị trường gắn bằng chứng thực tế (Evidence-First), lên lịch Facebook/Zalo, lập kế hoạch TikTok Livestream.
3. **AI Sales**: Tư vấn kỹ thuật dựa trên catalogue chuẩn Google Sheets, khóa giá server-side và tạo đơn nháp tự động.
4. **AI Kho**: Giám sát tồn kho tại kho 17 Phạm Vấn và kiểm tra đơn hàng thời gian thực.
5. **AI Kế toán**: Ghi nhận doanh thu, phân tách tỷ lệ vật tư / thiết bị và tính toán hoa hồng minh bạch.

---

### 2. Quy trình Chuyển từ Demo sang Vận Hành Thật (Production)
Trong giai đoạn đầu, hệ thống chứa dữ liệu kiểm thử (seed/demo data) để minh họa tính năng. Trước khi đưa vào vận hành chính thức với khách hàng thật, chủ sở hữu bắt buộc phải thực hiện các bước sau:

* **Bước 1: Làm sạch dữ liệu mô phỏng (Reset Production)**
  - Trên thanh tiêu đề điều hành của trang quản trị, bấm vào nút màu đỏ **"Reset Vận Hành Thật"**.
  - Hệ thống sẽ hiển thị cảnh báo xác nhận. Thao tác này sẽ **xóa sạch toàn bộ đơn hàng thử, nhật ký đàm phán demo, báo cáo nghiên cứu mẫu và hàng đợi kiểm thử**.
  - **Lưu ý quan trọng**: Catalogue 12 sản phẩm chuẩn (đồng bộ từ Google Sheets) và cấu hình System Prompts của các Agent **vẫn được giữ nguyên tuyệt đối**, không bị ảnh hưởng.

* **Bước 2: Kiểm tra nguồn dữ liệu sản phẩm Google Sheets**
  - Đảm bảo bảng Google Sheets chính thức (`https://docs.google.com/spreadsheets/d/19WB-7Lf8rzG9vYcqW_1-ZN0SB_VT0AlT0QP8H1pRzgE/edit`) đã cập nhật đầy đủ giá niêm yết, giá sỉ và đặc tính kỹ thuật.
  - Sử dụng nút **"Đồng bộ Sheet"** tại khu vực AI Sales để nạp mới nhất vào cơ sở dữ liệu hệ thống.

---

### 3. Hướng dẫn Vận hành Chi tiết 5 AI Agent

#### 3.1. AI CEO & Trung tâm Điều hành (08:00 Sáng)
- **Báo cáo 08:00**: Hằng ngày vào lúc 08:00, AI CEO tổng hợp tiến độ KPI ngày (mục tiêu 10 triệu VNĐ), tình trạng tồn kho tại 17 Phạm Vấn và các đề xuất cần kiểm duyệt.
- **Decision Engine**: Cho phép chuyển đổi giữa chế độ *Tự động có điều kiện (Conditional Auto)* và *Thủ công (Manual Only)*. Chủ sở hữu có thể tùy chỉnh các quy tắc phê duyệt tại giao diện *Rule Builder* (Kiểm tra tồn kho 17 Phạm Vấn, chuẩn giá niêm yết, an toàn y khoa, KPI ngày).
- **Đàm phán Đối tác**: AI CEO thay mặt doanh nghiệp thiết lập chiến lược tối ưu quyền lợi khi đàm phán với nhà cung cấp/phòng khám, sau đó trình chủ sở hữu phê duyệt bản chốt cuối cùng.

#### 3.2. AI Marketing & Cổng Xác Minh (Evidence-Gate)
- **Chống ảo hóa dữ liệu**: Mọi báo cáo nghiên cứu thị trường đều phải đính kèm danh sách `evidenceSources` (bao gồm tiêu đề, URL nguồn chính thức, thời điểm thu thập `scrapedAt`, đoạn trích dẫn `snippet` và trạng thái `verificationStatus`).
- **Evidence-Gate**: AI CEO bắt buộc **từ chối phê duyệt** nếu báo cáo không có nguồn xác minh thực tế (`verified_real`), ngăn chặn tuyệt đối tình trạng AI tự bịa số liệu.
- **Hàng đợi đăng bài**: Quản lý nội dung Facebook, Zalo OA và khu vực TikTok Livestream (kịch bản video hướng dẫn ứng dụng lâm sàng).

#### 3.3. AI Sales & Pipeline Chốt Đơn
- Tư vấn trực tiếp dựa trên 12 sản phẩm cố định. Khi khách hàng chốt đơn, AI Sales thu thập tên phòng khám, số điện thoại, địa chỉ và tạo đơn nháp.
- **Khóa giá server-side**: Backend tự động đối chiếu giá từ catalogue chuẩn, ngăn chặn sai lệch giá do client truyền lên.
- Đơn hàng sau khi xác nhận sẽ tự động chuyển trạng thái sang **AI Kho (17 Phạm Vấn)** và **AI Kế toán**.

---

### 4. Giới hạn Kỹ thuật và Lộ trình Kết nối Thực tế (Production)
Hiện tại, hệ thống đã hoàn thiện lớp ứng dụng và cơ chế kiểm duyệt nội bộ. Để kết nối với hạ tầng thực tế bên ngoài, cần thực hiện các bước tích hợp sau:
1. **Cổng thanh toán**: Tích hợp API SePay / VietQR động hoặc VNPay/MoMo Webhook với chữ ký bảo mật HMAC SHA256.
2. **Kho & Vận chuyển**: Kết nối API Giao Hàng Nhanh (GHN v2) hoặc GHTK để tự động tạo vận đơn xuất phát từ kho 17 Phạm Vấn.
3. **Thông báo di động**: Cấu hình Zalo OA API hoặc Telegram Bot Token để AI CEO tự động bắn tin nhắn báo cáo điều hành 08:00 về điện thoại quản lý.

---
*Tài liệu được biên soạn tự động bởi Hệ thống Quản trị AI - 24 Seven Health Care Vietnam.*
