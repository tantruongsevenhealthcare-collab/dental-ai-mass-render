import { describe, expect, it } from "vitest";
import {
  summarizeAgentActivity,
  summarizeOrderStatuses,
  summarizeProposalStatuses,
} from "../client/src/lib/kpiDashboard";

describe("KPI dashboard summaries", () => {
  it("groups actual order statuses", () => {
    expect(summarizeOrderStatuses([{ status: "processing" }, { status: "processing" }, { status: "completed" }])).toEqual([
      { status: "processing", value: 2 },
      { status: "completed", value: 1 },
    ]);
  });

  it("separates approved and pending CEO proposals", () => {
    expect(summarizeProposalStatuses([{ status: "approved" }, { status: "auto_approved" }, { status: "pending" }])).toEqual([
      { name: "Đã duyệt", value: 2, fill: "#059669" },
      { name: "Chờ duyệt", value: 1, fill: "#f59e0b" },
    ]);
  });

  it("counts activity by agent key", () => {
    expect(summarizeAgentActivity(
      [{ name: "AI CEO", agentKey: "ceo" }, { name: "AI Kho", agentKey: "warehouse" }],
      [{ agentKey: "ceo" }, { agentKey: "ceo" }, { agentKey: "warehouse" }],
    )).toEqual([
      { name: "CEO", interactions: 2 },
      { name: "Kho", interactions: 1 },
    ]);
  });
});
