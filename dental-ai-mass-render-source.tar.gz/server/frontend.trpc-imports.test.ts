import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import {
  clearDealerIdentity,
  DEALER_IDENTITY_STORAGE_KEY,
  DEFAULT_DEALER_IDENTITY,
  getOrCreateDealerIdentity,
  readDealerIdentity,
  saveDealerIdentity,
} from "../client/src/lib/dealerIdentity";

const projectRoot = resolve(import.meta.dirname, "..");

function readClientFile(relativePath: string) {
  return readFileSync(resolve(projectRoot, relativePath), "utf8");
}

describe("frontend tRPC imports", () => {
  it("imports the tRPC client before constructing the Provider", () => {
    const source = readClientFile("client/src/main.tsx");

    expect(source).toMatch(/import\s+\{\s*trpc\s*\}\s+from\s+[\"']@\/lib\/trpc[\"']/);
    expect(source).toContain("const trpcClient = trpc.createClient");
    expect(source).toContain("<trpc.Provider client={trpcClient}");
  });

  it("imports tRPC in components that call tRPC hooks", () => {
    const dashboardSource = readClientFile("client/src/components/DashboardLayout.tsx");
    const homeSource = readClientFile("client/src/pages/Home.tsx");

    expect(dashboardSource).toMatch(/import\s+\{\s*trpc\s*\}\s+from\s+[\"']@\/lib\/trpc[\"']/);
    expect(dashboardSource).toContain("trpc.auth.ownerLogin.useMutation");
    expect(homeSource).toMatch(/import\s+\{\s*trpc\s*\}\s+from\s+[\"']@\/lib\/trpc[\"']/);
    expect(homeSource).toContain("trpc.zeroTouch.getProducts.useQuery");
  });
});

describe("dealer identity localStorage flow", () => {
  function createMemoryStorage() {
    const values = new Map<string, string>();
    return {
      getItem: (key: string) => values.get(key) ?? null,
      setItem: (key: string, value: string) => values.set(key, value),
      removeItem: (key: string) => values.delete(key),
    };
  }

  it("persists a valid dealer identity and restores it as Owner", () => {
    const storage = createMemoryStorage();
    const saved = saveDealerIdentity(
      {
        name: "Nguyễn Văn A",
        phone: "0963166698",
        email: "owner@example.com",
      },
      storage,
    );

    expect(saved).toMatchObject({
      name: "Nguyễn Văn A",
      phone: "0963166698",
      email: "owner@example.com",
      role: "owner",
    });
    expect(readDealerIdentity(storage)).toEqual(saved);
  });

  it("rejects invalid identity and clears the stored identity on logout", () => {
    const storage = createMemoryStorage();
    expect(
      saveDealerIdentity(
        { name: "", phone: "not-a-phone", email: "not-an-email" },
        storage,
      ),
    ).toBeNull();

    saveDealerIdentity(
      {
        name: "Chủ đại lý",
        phone: "0987654321",
        email: "dealer@example.com",
      },
      storage,
    );
    expect(storage.getItem(DEALER_IDENTITY_STORAGE_KEY)).not.toBeNull();

    clearDealerIdentity(storage);
    expect(readDealerIdentity(storage)).toEqual(DEFAULT_DEALER_IDENTITY);
    expect(getOrCreateDealerIdentity(storage)).toEqual(DEFAULT_DEALER_IDENTITY);
    expect(storage.getItem(DEALER_IDENTITY_STORAGE_KEY)).toBe(JSON.stringify(DEFAULT_DEALER_IDENTITY));
  });
});

// This test intentionally checks the source boundary: an undefined tRPC symbol
// can escape a server-only typecheck and still crash the browser at module load.
// Keeping the import contract explicit prevents that regression.

/* c8 ignore next */
void 0;

// Vitest runs this file in ESM mode, so import.meta.dirname is available in the
// current Node runtime and keeps the test independent of the working directory.
