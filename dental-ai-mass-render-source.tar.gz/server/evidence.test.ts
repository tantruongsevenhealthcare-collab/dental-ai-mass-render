import { describe, it, expect } from "vitest";

describe("Evidence-First & Anti-Hallucination Architecture", () => {
  it("should define evidenceSources and verificationStatus structure correctly", () => {
    const mockReport = {
      reportDate: "2026-08-21",
      marketTrends: "Phân tích nhu cầu vật tư nha khoa",
      competitorInsights: "Thông tin đối thủ",
      strategicProposals: [],
      evidenceSources: [
        {
          title: "Danh mục sản phẩm Google Sheets",
          url: "https://docs.google.com/spreadsheets/d/...",
          scrapedAt: new Date().toISOString(),
          snippet: "Nguồn chính thức",
          verificationStatus: "verified_real"
        }
      ],
      verificationStatus: "unverified_simulated"
    };

    expect(mockReport.evidenceSources).toBeDefined();
    expect(mockReport.evidenceSources.length).toBeGreaterThan(0);
    expect(mockReport.verificationStatus).toBe("unverified_simulated");
    expect(mockReport.evidenceSources[0].verificationStatus).toBe("verified_real");
  });
});
