import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { sdk } from "./_core/sdk";

import { zeroTouchRouter } from "./routers/zeroTouchRouter";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    ownerLogin: publicProcedure
      .input(z.object({
        name: z.string().min(2, "Vui lòng nhập họ tên"),
        phone: z.string().min(9, "Vui lòng nhập số điện thoại hợp lệ"),
        email: z.string().email("Vui lòng nhập email hợp lệ"),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const openId = `owner_${input.phone.replace(/\D/g, "")}`;
        const existing = await db.select().from(users).where(eq(users.openId, openId));
        
        const now = new Date();
        if (existing.length === 0) {
          await db.insert(users).values({
            openId,
            name: input.name,
            email: input.email,
            loginMethod: "owner_phone",
            role: "admin",
            lastSignedIn: now,
          });
        } else {
          await db.update(users)
            .set({
              name: input.name,
              email: input.email,
              role: "admin",
              lastSignedIn: now,
            })
            .where(eq(users.openId, openId));
        }

        const sessionToken = await sdk.createSessionToken(openId, { name: input.name });
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, {
          ...cookieOptions,
          maxAge: 365 * 24 * 60 * 60 * 1000,
        });

        return {
          success: true,
          name: input.name,
          email: input.email,
          // The browser-side fallback mirrors the existing preview auth path
          // for environments that reject third-party/HttpOnly cookies.
          sessionToken,
        };
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  zeroTouch: zeroTouchRouter,
});

export type AppRouter = typeof appRouter;
