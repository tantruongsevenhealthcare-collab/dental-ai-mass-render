import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createTestContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "owner-open-id",
      email: "owner@24sevenhc.com.vn",
      name: "Chủ sở hữu",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as any,
    res: { clearCookie: () => {} } as any,
  };
}

describe("AI CEO Partner Negotiation Engine - Advanced Tests", () => {
  it("fetches negotiations list successfully", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.zeroTouch.getPartnerNegotiations();
    expect(Array.isArray(result)).toBe(true);
  }, 15000);
});
