import { describe, expect, it } from "vitest";
import { getSessionCookieOptions } from "./_core/cookies";

describe("getSessionCookieOptions behind Render proxy", () => {
  it("marks SameSite=None cookies as Secure for forwarded HTTPS", () => {
    const req = { protocol: "http", headers: { "x-forwarded-proto": "https" } } as any;
    expect(getSessionCookieOptions(req)).toMatchObject({ sameSite: "none", secure: true, httpOnly: true, path: "/" });
  });

  it("keeps local HTTP development cookies non-secure", () => {
    const req = { protocol: "http", headers: {} } as any;
    expect(getSessionCookieOptions(req).secure).toBe(false);
  });
});
