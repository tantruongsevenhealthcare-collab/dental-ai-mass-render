import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(resolve(import.meta.dirname, "routers/zeroTouchRouter.ts"), "utf8");
const homeSource = readFileSync(resolve(import.meta.dirname, "../client/src/pages/Home.tsx"), "utf8");

describe("catalogue guardrails", () => {
  it("keeps sensitive warehouse and approval actions Owner/Admin-only", () => {
    expect(routerSource).toMatch(/updateProductPrice:\s*adminProcedure/);
    expect(routerSource).toMatch(/approveProductPrice:\s*adminProcedure/);
    expect(routerSource).toMatch(/syncProductsFromSheet:\s*adminProcedure/);
    expect(routerSource).toMatch(/toggleProductStatus:\s*adminProcedure/);
    expect(routerSource).toMatch(/approveCeoProposal:\s*adminProcedure/);
  });

  it("applies the verified and active guardrail to operational catalogue choices", () => {
    expect(routerSource).toContain('eq(products.verificationStatus, "verified_real")');
    expect(routerSource).toContain("isOperationalProduct(product)");
    expect(homeSource).toContain('product.verificationStatus === "verified_real"');
    expect(homeSource).toContain("operationalProducts.map");
  });

  it("exposes the explicit Owner price approval action in the warehouse UI", () => {
    expect(homeSource).toContain("trpc.zeroTouch.approveProductPrice.useMutation");
    expect(homeSource).toContain("Chủ đại lý duyệt giá");
  });
});
