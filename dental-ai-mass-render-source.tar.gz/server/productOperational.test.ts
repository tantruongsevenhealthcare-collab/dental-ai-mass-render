import { describe, expect, it } from "vitest";
import { isOperationalProduct } from "./productCatalogSync";

describe("operational product guardrail", () => {
  it("accepts only active products with verified real sources", () => {
    expect(isOperationalProduct({ isActive: true, verificationStatus: "verified_real" })).toBe(true);
    expect(isOperationalProduct({ isActive: false, verificationStatus: "verified_real" })).toBe(false);
    expect(isOperationalProduct({ isActive: true, verificationStatus: "unverified_simulated" })).toBe(false);
    expect(isOperationalProduct({ isActive: true, verificationStatus: "flagged" })).toBe(false);
  });

  it("fails closed when legacy or incomplete rows lack verification metadata", () => {
    expect(isOperationalProduct({ isActive: true })).toBe(false);
    expect(isOperationalProduct({ isActive: undefined, verificationStatus: "verified_real" })).toBe(false);
    expect(isOperationalProduct({ isActive: null, verificationStatus: "verified_real" })).toBe(false);
  });
});
