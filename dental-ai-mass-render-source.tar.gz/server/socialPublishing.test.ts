import { beforeEach, describe, expect, it, vi } from "vitest";

process.env.SOCIAL_TOKEN_ENCRYPTION_KEY = "test-social-token-key-at-least-32-bytes";

const { decryptSocialToken, encryptSocialToken, isRetryableSocialError, publishFacebookPage } = await import("./socialPublishing");

describe("social publishing core", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("encrypts and decrypts tokens without exposing plaintext", () => {
    const encrypted = encryptSocialToken("secret-access-token");
    expect(encrypted).not.toContain("secret-access-token");
    expect(decryptSocialToken(encrypted)).toBe("secret-access-token");
  });

  it("returns a real Facebook result only from a successful API response", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(JSON.stringify({ id: "page_123_post_456" }), { status: 200 })));
    await expect(publishFacebookPage({ platform: "facebook", accessToken: "token", content: "hello", targetId: "page_123" })).resolves.toEqual({ externalPostId: "page_123_post_456", externalUrl: "https://www.facebook.com/page_123_post_456" });
  });

  it("recognizes rate-limit and server errors as retryable", () => {
    expect(isRetryableSocialError({ status: 429 })).toBe(true);
    expect(isRetryableSocialError({ status: 503 })).toBe(true);
    expect(isRetryableSocialError({ status: 400 })).toBe(false);
  });
});
