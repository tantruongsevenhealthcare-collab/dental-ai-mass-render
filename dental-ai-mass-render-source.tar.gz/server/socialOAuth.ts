import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import { eq } from "drizzle-orm";
import { socialConnections, users } from "../drizzle/schema";
import { getDb } from "./db";
import { ENV } from "./_core/env";
import { encryptSocialToken } from "./socialPublishing";

export type OAuthPlatform = "facebook" | "zalo" | "tiktok";
const stateKey = () => crypto.createHash("sha256").update(ENV.cookieSecret || ENV.socialTokenEncryptionKey || "missing").digest();

export function signSocialState(userOpenId: string, platform: OAuthPlatform): string {
  const payload = Buffer.from(JSON.stringify({ userOpenId, platform, nonce: crypto.randomBytes(16).toString("hex"), exp: Date.now() + 10 * 60_000 })).toString("base64url");
  const sig = crypto.createHmac("sha256", stateKey()).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export function verifySocialState(state: string): { userOpenId: string; platform: OAuthPlatform } {
  const [payload, signature] = state.split(".");
  if (!payload || !signature) throw new Error("Invalid social OAuth state");
  const expected = crypto.createHmac("sha256", stateKey()).update(payload).digest("base64url");
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) throw new Error("Invalid social OAuth signature");
  const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
  if (!parsed.userOpenId || !parsed.platform || parsed.exp < Date.now()) throw new Error("Expired social OAuth state");
  return parsed;
}

export function socialRedirectUri(platform: OAuthPlatform): string {
  return `${ENV.publicAppUrl}/api/social/${platform}/callback`;
}

export function isSocialOAuthConfigured(platform: OAuthPlatform): boolean {
  if (platform === "facebook") return Boolean(ENV.facebookAppId && ENV.facebookAppSecret);
  if (platform === "zalo") return Boolean(ENV.zaloAppId && ENV.zaloAppSecret);
  return Boolean(ENV.tiktokClientKey && ENV.tiktokClientSecret);
}

export function buildSocialAuthorizationUrl(userOpenId: string, platform: OAuthPlatform): string {
  const state = signSocialState(userOpenId, platform);
  if (!isSocialOAuthConfigured(platform)) throw new Error(`OAuth Production chưa được cấu hình cho ${platform}; Admin cần nạp credentials server-side.`);
  const redirect_uri = socialRedirectUri(platform);
  if (platform === "facebook") {
    const url = new URL("https://www.facebook.com/v20.0/dialog/oauth");
    url.searchParams.set("client_id", ENV.facebookAppId); url.searchParams.set("redirect_uri", redirect_uri); url.searchParams.set("state", state); url.searchParams.set("scope", "pages_show_list,pages_read_engagement,pages_manage_posts");
    return url.toString();
  }
  if (platform === "zalo") {
    const url = new URL("https://oauth.zaloapp.com/v4/permission");
    url.searchParams.set("app_id", ENV.zaloAppId); url.searchParams.set("redirect_uri", redirect_uri); url.searchParams.set("state", state); url.searchParams.set("code_challenge", crypto.createHash("sha256").update(state).digest("base64url"));
    return url.toString();
  }
  const url = new URL("https://www.tiktok.com/v2/auth/authorize/");
  url.searchParams.set("client_key", ENV.tiktokClientKey); url.searchParams.set("redirect_uri", redirect_uri); url.searchParams.set("response_type", "code"); url.searchParams.set("scope", "user.info.basic,video.publish"); url.searchParams.set("state", state);
  return url.toString();
}

async function exchange(url: string, body: URLSearchParams, headers?: Record<string, string>): Promise<any> {
  const response = await fetch(url, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded", ...headers }, body });
  const text = await response.text(); let json: any; try { json = JSON.parse(text); } catch { json = {}; }
  if (!response.ok || json.error || json.error_code) throw new Error(`OAuth token exchange failed (${response.status})`);
  return json;
}

export async function exchangeSocialCode(platform: OAuthPlatform, code: string, redirectUri: string) {
  if (platform === "facebook") {
    const body = new URLSearchParams({ client_id: ENV.facebookAppId, client_secret: ENV.facebookAppSecret, redirect_uri: redirectUri, code });
    return exchange("https://graph.facebook.com/v20.0/oauth/access_token", body);
  }
  if (platform === "zalo") {
    const body = new URLSearchParams({ app_id: ENV.zaloAppId, app_secret: ENV.zaloAppSecret, code, redirect_uri: redirectUri });
    return exchange("https://oauth.zaloapp.com/v4/access_token", body);
  }
  const body = new URLSearchParams({ client_key: ENV.tiktokClientKey, client_secret: ENV.tiktokClientSecret, code, grant_type: "authorization_code", redirect_uri: redirectUri });
  return exchange("https://open.tiktokapis.com/v2/oauth/token/", body);
}

async function fetchSocialProfile(platform: OAuthPlatform, accessToken: string) {
  if (platform === "facebook") {
    const r = await fetch(`https://graph.facebook.com/v20.0/me?fields=id,name,picture&access_token=${encodeURIComponent(accessToken)}`); return r.json();
  }
  if (platform === "zalo") {
    const r = await fetch("https://graph.zalo.me/v2.0/me?fields=id,name,picture", { headers: { access_token: accessToken } }); return r.json();
  }
  const r = await fetch("https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url", { headers: { authorization: `Bearer ${accessToken}` } }); return r.json();
}

export function registerSocialOAuthRoutes(app: Express) {
  for (const platform of ["facebook", "zalo", "tiktok"] as OAuthPlatform[]) {
    app.get(`/api/social/${platform}/callback`, async (req: Request, res: Response) => {
      try {
        const code = typeof req.query.code === "string" ? req.query.code : "";
        const state = typeof req.query.state === "string" ? req.query.state : "";
        if (!code || !state) return res.status(400).send("OAuth callback thiếu code/state");
        const verified = verifySocialState(state);
        if (verified.platform !== platform) return res.status(400).send("OAuth platform mismatch");
        const token = await exchangeSocialCode(platform, code, socialRedirectUri(platform));
        const accessToken = token.access_token || token.accessToken;
        const refreshToken = token.refresh_token || token.refreshToken;
        if (!accessToken) throw new Error("Provider returned no access token");
        const profile = await fetchSocialProfile(platform, accessToken);
        const data = platform === "tiktok" ? profile.data || {} : profile;
        const externalAccountId = data.id || data.open_id;
        if (!externalAccountId) throw new Error("Provider returned no account id");
        await saveSocialConnection({ userOpenId: verified.userOpenId, platform, accountType: platform === "facebook" ? "page" : platform === "zalo" ? "oa" : "business", externalAccountId: String(externalAccountId), displayName: data.name || data.display_name, avatarUrl: data.picture?.data?.url || data.avatar_url, accessToken, refreshToken, expiresIn: Number(token.expires_in || 0), scopes: typeof token.scope === "string" ? token.scope.split(/[ ,]/).filter(Boolean) : [] });
        const payload = JSON.stringify({ type: "social-oauth-result", platform, success: true, externalAccountId: String(externalAccountId), displayName: data.name || data.display_name || "", avatarUrl: data.picture?.data?.url || data.avatar_url || "", scopes: typeof token.scope === "string" ? token.scope.split(/[ ,]/).filter(Boolean) : [] }).replace(/</g, "\\u003c");
        res.type("html").send(`<script>window.opener?.postMessage(${payload}, ${JSON.stringify(ENV.publicAppUrl)});window.close();</script><p>Kết nối thành công. Có thể đóng cửa sổ này.</p>`);
      } catch (error) { console.error(`[Social OAuth] ${platform} callback failed`, error); res.status(500).send("Kết nối OAuth thất bại; vui lòng thử lại."); }
    });
  }
}

export async function refreshSocialAccessToken(platform: OAuthPlatform, refreshToken: string) {
  if (platform === "facebook") {
    const url = new URL("https://graph.facebook.com/v20.0/oauth/access_token");
    url.searchParams.set("grant_type", "fb_exchange_token"); url.searchParams.set("client_id", ENV.facebookAppId); url.searchParams.set("client_secret", ENV.facebookAppSecret); url.searchParams.set("fb_exchange_token", refreshToken);
    const response = await fetch(url); const body = await response.json(); if (!response.ok || !body.access_token) throw new Error("Facebook token refresh failed"); return body;
  }
  const body = new URLSearchParams(platform === "zalo" ? { app_id: ENV.zaloAppId, app_secret: ENV.zaloAppSecret, refresh_token: refreshToken, grant_type: "refresh_token" } : { client_key: ENV.tiktokClientKey, client_secret: ENV.tiktokClientSecret, refresh_token: refreshToken, grant_type: "refresh_token" });
  return exchange(platform === "zalo" ? "https://oauth.zaloapp.com/v4/access_token" : "https://open.tiktokapis.com/v2/oauth/token/", body);
}

export async function saveSocialConnection(params: { userOpenId: string; platform: OAuthPlatform; accountType: "personal" | "page" | "oa" | "business"; externalAccountId: string; displayName?: string; avatarUrl?: string; accessToken: string; refreshToken?: string; expiresIn?: number; scopes: string[] }) {
  const db = await getDb(); if (!db) throw new Error("Database not available");
  const user = await db.select({ id: users.id }).from(users).where(eq(users.openId, params.userOpenId)).limit(1);
  if (!user[0]) throw new Error("User not found for social OAuth callback");
  const values = { userId: user[0].id, platform: params.platform, accountType: params.accountType, externalAccountId: params.externalAccountId, displayName: params.displayName || null, avatarUrl: params.avatarUrl || null, accessTokenCiphertext: encryptSocialToken(params.accessToken), refreshTokenCiphertext: params.refreshToken ? encryptSocialToken(params.refreshToken) : null, tokenExpiresAt: params.expiresIn ? new Date(Date.now() + params.expiresIn * 1000) : null, scopes: params.scopes, status: "connected" as const, lastError: null };
  await db.insert(socialConnections).values(values).onDuplicateKeyUpdate({ set: values });
  return { userId: user[0].id, platform: params.platform };
}
