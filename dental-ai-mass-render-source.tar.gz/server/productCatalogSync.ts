export const GOOGLE_SHEET_ID = "19WB-7Lf8rzG9vYcqW_1-ZN0SB_VT0AlT0QP8H1pRzgE";
export const GOOGLE_SHEET_URL = `https://docs.google.com/spreadsheets/d/${GOOGLE_SHEET_ID}/edit?usp=sharing`;
export const GOOGLE_SHEET_CSV_URL = `https://docs.google.com/spreadsheets/d/${GOOGLE_SHEET_ID}/export?format=csv`;
export const WEBSITE_BASE_URL = "https://www.24sevenhc.com.vn";

export type ScrapedProductRecord = {
  name: string;
  description: string;
  unit: string;
  dealerPrice: number;
  vatPrice: number;
  category: string;
  code: string;
  sourceUrl: string;
  isVerified: boolean;
};

export type SheetProductRecord = ScrapedProductRecord & {
  sourceRow: number;
};

/** Chỉ sản phẩm đang bật và đã được xác minh nguồn mới được đưa vào Sales/Marketing. */
export function isOperationalProduct(product: {
  isActive?: boolean | null;
  verificationStatus?: string | null;
}): boolean {
  return product.isActive === true && product.verificationStatus === "verified_real";
}

function parseMoney(value: string): number {
  if (!value) return 0;
  const digits = value.replace(/[^0-9]/g, "");
  return digits ? Number(digits) : 0;
}

export function standardizeProductName(rawName: string): string {
  const cleaned = rawName
    .replace(/&#8220;|&ldquo;|&rdquo;|&#8221;|["']/g, "")
    .replace(/&amp;/g, "&")
    .trim();
  const lower = cleaned.toLowerCase();

  if (lower.includes("jelenko") && lower.includes("st ml")) {
    return "Phôi sứ Jelenko Zir ST ML";
  }
  if (lower.includes("jelenko") && lower.includes("ht+")) {
    return "Phôi sứ Jelenko Zir HT+";
  }
  if (lower.includes("jelenko") && lower.includes("usa")) {
    return "Phôi sứ Jelenko USA";
  }
  if (lower.includes("jelenko")) {
    return "Phôi sứ Jelenko Zir HT+";
  }

  if (lower.includes("columbus") && lower.includes("abutment")) {
    return "Columbus Abutment - Trụ phục hình Implant";
  }
  if (lower.includes("ezcrown") || lower.includes("ez lock") || (lower.includes("phục hình") && lower.includes("implant"))) {
    return "Phục hình trên Implant EZCROWN & EZLOCK";
  }

  if (lower.includes("dil") || lower.includes("nhựa đệm hàm dil")) {
    return "Nhựa đệm hàm DIL (Hộp lớn)";
  }
  if (lower.includes("denture soft") || lower.includes("nhựa đệm hàm denture soft")) {
    return "Nhựa Đệm Hàm DENTURE SOFT EX";
  }
  if (lower.includes("peri-resin")) {
    return "Peri-Resin II";
  }
  if (lower.includes("collagen khối") && lower.includes("đau sau nhổ")) {
    return "Collagen khối cầm máu, đau sau nhổ răng";
  }
  if (lower.includes("horien collagen plug")) {
    return "HORIEN COLLAGEN PLUG";
  }
  if (lower.includes("xương ghép") && lower.includes("beta tcp")) {
    return "Xương ghép Collagen khối + beta TCP";
  }
  if (lower.includes("neopure putty") || lower.includes("putty (fast set)")) {
    return "Cao su lấy dấu NEOPURE PUTTY (FAST SET)";
  }
  if (lower.includes("neopure light") || lower.includes("light body")) {
    return "Cao su lấy dấu Neopure Light Body (Fast Set)";
  }
  if (lower.includes("neoalgin")) {
    return "Neoalgin - Vật Liệu Lấy Dấu Alginate";
  }
  if (lower.includes("biofilling")) {
    return "Biofilling Starter Kit";
  }
  if (lower.includes("compacter") || lower.includes("cây quay mta")) {
    return "Cây quay MTA xuống ống tủy: Compacter";
  }
  if (lower.includes("ezircos") || lower.includes("xoi mòn zirconia")) {
    return "Dung dịch xoi mòn Zirconia - EZIRCOS";
  }
  if (lower.includes("tmd") || lower.includes("khớp cắn")) {
    return "Thiết bị điều trị TMD và khớp cắn";
  }
  if (lower.includes("bonmaker")) {
    return "Máy tạo xương tự thân Bonmaker";
  }
  if (lower.includes("nước cất") || lower.includes("chai nhỏ giọt")) {
    return "Chai nhỏ giọt nước cất";
  }

  return cleaned;
}

function stableCode(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash << 5) - hash + name.charCodeAt(i);
    hash |= 0;
  }
  return `GS-${Math.abs(hash).toString(36).toUpperCase().slice(0, 8)}`;
}

export function inferWebsiteCategory(name: string, description: string): string {
  const text = `${name} ${description}`.toLowerCase();
  
  if (text.includes("nhựa đệm") || text.includes("denture soft") || text.includes("dil")) {
    return "Vật liệu đệm hàm - Sửa chữa hàm giả";
  }
  if (text.includes("peri-resin") || text.includes("collagen") || text.includes("cầm máu") || text.includes("ghép xương") || text.includes("beta tcp")) {
    return "Vật liệu cầm máu - Ghép xương";
  }
  if (text.includes("neopure") || text.includes("neoalgin") || text.includes("lấy dấu") || text.includes("putty") || text.includes("light body")) {
    return "Vật liệu lấy dấu";
  }
  if (text.includes("biofilling") || text.includes("mta") || text.includes("compacter") || text.includes("ống tủy")) {
    return "MTA - Vật liệu hỗ trợ";
  }
  if (text.includes("ezcrown") || text.includes("ezlock") || text.includes("columbus") || text.includes("abutment")) {
    return "Phục hình trên Implant EZCROWN & EZLOCK";
  }
  if (text.includes("ezircos") || text.includes("xoi mòn")) {
    return "Dung dịch xoi mòn Zirconia - EZIRCOS";
  }
  if (text.includes("jelenko") || text.includes("phôi sứ")) {
    return "Phôi sứ Jelenko";
  }
  if (text.includes("tmd") || text.includes("khớp cắn")) {
    return "Thiết bị điều trị TMD và khớp cắn";
  }
  if (text.includes("bonmaker") || text.includes("tạo xương")) {
    return "Máy tạo xương tự thân Bonmaker";
  }
  
  return "Sản phẩm HOT - Khuyến mãi";
}

export async function fetchLiveWebsiteProducts(): Promise<ScrapedProductRecord[]> {
  const results: ScrapedProductRecord[] = [];
  const seenUrls = new Set<string>();
  const seenCodes = new Set<string>();
  const seenNames = new Set<string>();

  try {
    const res = await fetch(WEBSITE_BASE_URL, {
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AI-Agent/2.4" },
      signal: AbortSignal.timeout(8000),
    });

    if (res.ok) {
      const html = await res.text();
      const linkRegex = /href="(https:\/\/www\.24sevenhc\.com\.vn\/[^"]+)"/g;
      const links = new Set<string>();
      let match;
      while ((match = linkRegex.exec(html)) !== null) {
        const url = match[1];
        const lowerUrl = url.toLowerCase();
        if (
          lowerUrl.includes("/dao-tao") ||
          lowerUrl.includes("/video") ||
          lowerUrl.includes("/thong-tin") ||
          lowerUrl.includes("/tin-tuc") ||
          lowerUrl.includes("/khuyen-mai") ||
          lowerUrl.includes("/check-ma-bao-hanh") ||
          lowerUrl.includes("/wp-content/") ||
          lowerUrl.includes("/tag/") ||
          lowerUrl.includes("/author/") ||
          url === WEBSITE_BASE_URL ||
          url === `${WEBSITE_BASE_URL}/`
        ) {
          continue;
        }
        links.add(url);
      }

      const subUrls = Array.from(links).slice(0, 50);
      for (const url of subUrls) {
        if (seenUrls.has(url)) continue;
        seenUrls.add(url);

        try {
          const subRes = await fetch(url, {
            headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AI-Agent/2.4" },
            signal: AbortSignal.timeout(4000),
          });
          if (subRes.ok) {
            const subHtml = await subRes.text();
            const titleMatch = subHtml.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || subHtml.match(/<title>([\s\S]*?)<\/title>/i);
            if (titleMatch) {
              const rawTitle = titleMatch[1].replace(/<[^>]+>/g, "").trim();
              if (rawTitle && rawTitle.length > 3 && !rawTitle.toLowerCase().includes("24 seven")) {
                const standardized = standardizeProductName(rawTitle);
                const code = stableCode(standardized);

                if (!seenNames.has(standardized) && !seenCodes.has(code)) {
                  seenNames.add(standardized);
                  seenCodes.add(code);

                  const priceMatch = subHtml.match(/([0-9.,]+)\s*đ/i) || subHtml.match(/gia:\s*([0-9.,]+)/i);
                  const parsedPrice = priceMatch ? parseMoney(priceMatch[1]) : 0;

                  results.push({
                    name: standardized,
                    description: `Sản phẩm chính hãng phân phối độc quyền trích xuất từ ${url}`,
                    unit: "Hộp / Cái",
                    dealerPrice: parsedPrice > 0 ? Math.round(parsedPrice * 0.85) : 0,
                    vatPrice: parsedPrice,
                    category: inferWebsiteCategory(standardized, url),
                    code,
                    sourceUrl: url,
                    isVerified: parsedPrice > 0,
                  });
                }
              }
            }
          }
        } catch {
          // Bỏ qua lỗi timeout trang phụ
        }
      }
    }
  } catch {
    // Fallback
  }

  return results;
}

export async function fetchGoogleSheetProducts(): Promise<SheetProductRecord[]> {
  try {
    const res = await fetch(GOOGLE_SHEET_CSV_URL, {
      signal: AbortSignal.timeout(5000),
    });
    if (res.ok) {
      const text = await res.text();
      const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
      if (lines.length > 1) {
        const records: SheetProductRecord[] = [];
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i];
          // Bỏ qua dòng nguồn hoặc url không phải sản phẩm
          if (line.toLowerCase().includes("nguồn") || line.toLowerCase().includes("http")) {
            continue;
          }
          const cols = line.split(",").map(c => c.trim().replace(/^["']|["']$/g, ""));
          if (cols.length >= 5 && cols[0]) {
            const name = standardizeProductName(cols[0]);
            const dealerPrice = parseMoney(cols[3] || "0");
            const vatPrice = parseMoney(cols[4] || "0");
            records.push({
              name,
              description: cols[1] || "Sản phẩm nha khoa chất lượng cao",
              unit: cols[2] || "Hộp / Cái",
              dealerPrice,
              vatPrice,
              category: inferWebsiteCategory(name, cols[1] || ""),
              code: stableCode(name),
              sourceUrl: GOOGLE_SHEET_URL,
              isVerified: vatPrice > 0,
              sourceRow: i + 1,
            });
          }
        }
        return records;
      }
    }
  } catch {
    // Fallback
  }
  return [];
}

export function buildSalesCatalogContext(productsList: { name: string; vatPrice: number | string | null; dealerPrice: number | string | null; category: string; description?: string | null }[]): string {
  return productsList
    .map(p => {
      const formatNum = (val: number | string | null | undefined) => {
        const num = typeof val === 'number' ? val : Number(val || 0);
        return num.toLocaleString("vi-VN").replace(/,/g, ".");
      };
      const vat = formatNum(p.vatPrice);
      const dealer = formatNum(p.dealerPrice);
      return `- ${p.name} (${p.category}): Giá VAT: ${vat} đ, Giá đại lý: ${dealer} đ. ${p.description || ''}`;
    })
    .join("\n");
}
