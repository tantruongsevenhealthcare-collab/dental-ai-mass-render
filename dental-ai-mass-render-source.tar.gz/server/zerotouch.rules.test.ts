import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createTestContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-owner",
      email: "owner@24sevenhc.com.vn",
      name: "Owner 24 Seven",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as any,
    res: { clearCookie: () => {} } as any,
  };
}

describe("CEO Decision Rules & Rule Builder", () => {
  it("should fetch CEO rules successfully", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const rules = await caller.zeroTouch.getCeoRules();
    expect(Array.isArray(rules)).toBe(true);
    expect(rules.length).toBeGreaterThan(0);
  });

  it("should update rule status and details", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const rules = await caller.zeroTouch.getCeoRules();
    if (rules.length > 0) {
      const firstRule = rules[0]!;
      
      // Update status
      const resStatus = await caller.zeroTouch.updateCeoRuleStatus({
        ruleId: firstRule.id,
        isEnabled: !firstRule.isEnabled,
      });
      expect(resStatus).toEqual({ success: true });

      // Revert status
      await caller.zeroTouch.updateCeoRuleStatus({
        ruleId: firstRule.id,
        isEnabled: firstRule.isEnabled,
      });

      // Update details
      const resDetails = await caller.zeroTouch.updateCeoRuleDetails({
        ruleId: firstRule.id,
        ruleName: "Updated Rule Name",
        description: "Updated description for testing",
      });
      expect(resDetails).toEqual({ success: true });
    }
  });
});
