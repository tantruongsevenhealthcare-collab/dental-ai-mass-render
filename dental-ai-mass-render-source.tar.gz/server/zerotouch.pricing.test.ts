import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { getDb } from "./db";
import { products } from "../drizzle/schema";

function createTestContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-admin",
      email: "admin@24sevenhc.com.vn",
      name: "Admin Zero-Touch",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as any,
    res: { clearCookie: () => {} } as any,
  };
}

describe("24 Seven Health Care Vietnam - Server-Side Catalog Price Lock Tests", () => {
  it("should enforce database catalog price rules during order creation", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const productList = await caller.zeroTouch.getProducts();
    expect(productList.length).toBeGreaterThan(0);
    let targetProduct = productList.find(p => Number(p.price) > 0) || productList[0];
    if (Number(targetProduct.price) <= 0) {
      await caller.zeroTouch.updateProductPrice({ productId: targetProduct.id, price: 1500000 });
      const updatedList = await caller.zeroTouch.getProducts();
      targetProduct = updatedList.find(p => p.id === targetProduct.id)!;
    }

    const fakeClientPrice = 1; // Khách hàng cố tình gửi giá cực thấp từ client
    const res = await caller.zeroTouch.createOrder({
      customerName: "Phòng khám Test Khóa Giá",
      customerPhone: "0963166698",
      customerAddress: "17 Phạm Vấn, TP.HCM",
      items: [
        {
          productId: targetProduct.id,
          code: targetProduct.code,
          name: targetProduct.name,
          category: targetProduct.category as any,
          price: fakeClientPrice,
          quantity: 1,
        }
      ],
      notes: "Test khóa giá server-side",
      isRealData: false,
    });

    expect(res.success).toBe(true);
    const orders = await caller.zeroTouch.getOrders();
    const createdOrder = orders.find(o => o.orderCode === res.orderCode);
    expect(createdOrder).toBeDefined();
    
    // Kiểm tra rằng đơn hàng ghi nhận đúng giá chuẩn từ catalogue
    const expectedAmount = Number(targetProduct.price) * 1;
    expect(Number(createdOrder?.totalAmount)).toBe(expectedAmount);
  });
});
