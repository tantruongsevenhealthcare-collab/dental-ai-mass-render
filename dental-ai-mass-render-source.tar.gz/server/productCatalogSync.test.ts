import { afterEach, describe, expect, it, vi } from "vitest";
import { buildSalesCatalogContext, fetchGoogleSheetProducts } from "./productCatalogSync";

describe("Google Sheets product catalog", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("parses valid products, skips source/url rows, and maps VAT/dealer prices", async () => {
    const csv = [
      "TÊN SẢN PHẨM,THÔNG TIN SẢN PHẨM,ĐƠN VỊ TÍNH,ĐƠN GIÁ ĐẠI LÝ (CHIẾT KHẤU 20%),GIÁ ĐẠI LÍ BAO GỒM VAT",
      "RetroMTA,Che tủy lộ và trám bít,Hộp (8 TÉP),2.624.000,3.271.800",
      "Nguồn,,,,",
      "https://example.com/product,,,,",
    ].join("\n");

    vi.stubGlobal("fetch", vi.fn(async () => new Response(csv, { status: 200 })));

    const products = await fetchGoogleSheetProducts();

    expect(products).toHaveLength(1);
    expect(products[0]).toMatchObject({
      name: "RetroMTA",
      description: "Che tủy lộ và trám bít",
      unit: "Hộp (8 TÉP)",
      dealerPrice: 2624000,
      vatPrice: 3271800,
      sourceRow: 2,
    });
    expect(products[0]?.code).toMatch(/^GS-/);
  });

  it("builds AI Sales context with VAT price, dealer price, and characteristics (no internal stock disclosed)", () => {
    const context = buildSalesCatalogContext([
      {
        code: "GS-RETRO",
        name: "RetroMTA",
        category: "material",
        price: "3271800",
        unit: "Hộp",
        description: "Che tủy lộ và trám bít",
        stock: 7,
        dealerPrice: "2624000",
        vatPrice: "3271800",
      },
    ]);

    expect(context).toContain("RetroMTA");
    expect(context).toContain("Giá VAT: 3.271.800 đ");
    expect(context).toContain("Giá đại lý: 2.624.000 đ");
    expect(context).not.toContain("Tồn kho");
    expect(context).toContain("Che tủy lộ và trám bít");
  });
});
