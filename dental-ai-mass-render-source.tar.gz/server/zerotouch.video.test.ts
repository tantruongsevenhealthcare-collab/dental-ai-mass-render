import { describe, it, expect, vi } from "vitest";
import { appRouter } from "./routers";
import { formatVeoProviderFailure, sanitizeCatalogVideoDraft, veoProvider } from "./routers/zeroTouchRouter";
import { getDb } from "./db";
import { tiktokVideos, backorderRequests } from "../drizzle/schema";

describe("24 Seven Health Care Vietnam - AI Video Studio & Backorder Tests", () => {
  it("should create self-generated video content automatically and record the selected product", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: { id: 1, openId: "test", name: "Owner", email: "owner@24seven.vn", role: "admin", createdAt: new Date(), updatedAt: new Date() }
    });

    // Lấy danh sách sản phẩm
    const products = await caller.zeroTouch.getProducts();
    expect(products.length).toBeGreaterThan(0);
    const targetProduct = products[0];
    const otherCatalogNames = products
      .filter(product => product.id !== targetProduct.id)
      .map(product => product.name)
      .filter(name => !targetProduct.name.includes(name));

    // Gọi procedure generateTiktokVideo
    const res = await caller.zeroTouch.generateTiktokVideo({ productId: targetProduct.id });
    expect(res.success).toBe(true);

    // Kiểm tra DB
    const db = await getDb();
    if (db) {
      const videos = await db.select().from(tiktokVideos);
      expect(videos.length).toBeGreaterThan(0);
      const latest = videos[videos.length - 1];
      expect(latest.productName).toBe(targetProduct.name);
      expect(latest.approvalStatus).toBe("approved");
      expect(latest.generationMode).toBe("self_generated");
      expect(latest.generationStatus).toBe("provider_pending");
      expect(latest.videoUrl).toBeNull();
      expect(latest.script).toContain(targetProduct.name);
      expect(latest.avatarPrompt).toContain(targetProduct.name);
      const latestVideoText = `${latest.videoTitle} ${latest.script} ${latest.avatarPrompt}`;
      expect(latestVideoText).not.toMatch(/UltraTech/i);
      for (const otherName of otherCatalogNames) expect(latestVideoText).not.toContain(otherName);
    }
  }, 30000);

  it("should create reference-adapted video content automatically without copying the source video", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: { id: 1, openId: "test", name: "Owner", email: "owner@24seven.vn", role: "admin", createdAt: new Date(), updatedAt: new Date() }
    });

    const products = await caller.zeroTouch.getProducts();
    const targetProduct = products[0];
    const otherCatalogNames = products
      .filter(product => product.id !== targetProduct.id)
      .map(product => product.name)
      .filter(name => !targetProduct.name.includes(name));
    const referenceVideoUrl = "https://www.tiktok.com/@publiccreator/video/123456789";
    const res = await caller.zeroTouch.generateTiktokVideo({
      productId: targetProduct.id,
      generationMode: "reference_adapted",
      searchKeyword: "dental collagen plug",
      referenceVideoUrl,
      creativeBrief: "Giữ hook ngắn, đổi toàn bộ cảnh quay và nhấn mạnh ứng dụng lâm sàng hợp lệ.",
    });

    expect(res.success).toBe(true);
    const db = await getDb();
    if (db) {
      const videos = await db.select().from(tiktokVideos);
      const adapted = videos.filter(video => video.referenceVideoUrl === referenceVideoUrl).sort((a, b) => b.id - a.id)[0];
      expect(adapted).toBeDefined();
      expect(adapted?.generationMode).toBe("reference_adapted");
      expect(adapted?.referenceSearchKeyword).toBe("dental collagen plug");
      expect(adapted?.generationStatus).toBe("provider_pending");
      expect(adapted?.videoUrl).toBeNull();
      expect(adapted?.script).not.toContain(referenceVideoUrl);
      expect(adapted?.productName).toBe(targetProduct.name);
      expect(adapted?.script).toContain(targetProduct.name);
      expect(adapted?.avatarPrompt).toContain(targetProduct.name);
      const adaptedVideoText = `${adapted?.videoTitle} ${adapted?.script} ${adapted?.avatarPrompt}`;
      expect(adaptedVideoText).not.toMatch(/UltraTech/i);
      for (const otherName of otherCatalogNames) expect(adaptedVideoText).not.toContain(otherName);
      const checklist = adapted?.adaptationChecklist ? JSON.parse(adapted.adaptationChecklist) : null;
      expect(checklist).toMatchObject({
        sourceReviewed: true,
        hookChanged: true,
        visualPlanChanged: true,
        scriptChanged: true,
        voiceoverChanged: true,
        ctaChanged: true,
        sourceElementsReused: [],
      });
      expect(checklist.originalityStatement.length).toBeGreaterThanOrEqual(30);
    }
  }, 30000);

  it("should sanitize draft and reject non-catalog claims or foreign brand names", () => {
    const productName = "Collagen khối cầm máu, đau sau nhổ răng";
    const activeCatalogNames = [productName, "HORIEN COLLAGEN PLUG", "Neoalgin - Vật Liệu Lấy Dấu Alginate"];
    for (const generationMode of ["self_generated", "reference_adapted"] as const) {
      const safeDraft = sanitizeCatalogVideoDraft({
        productName,
        productDescription: "Vật liệu nha khoa dùng theo hướng dẫn sản phẩm.",
        activeCatalogNames,
        generationMode,
        videoTitle: `Review ${productName} by NovaDent`,
        script: `Thương hiệu: NovaDent. Giới thiệu ${productName} với thông tin chưa được catalogue xác nhận.`,
        avatarPrompt: `NovaDent presenter giới thiệu ${productName}.`,
      });
      const text = `${safeDraft.videoTitle} ${safeDraft.script} ${safeDraft.avatarPrompt}`;
      expect(text).toContain(productName);
      expect(text).not.toContain("NovaDent");
      expect(text).not.toContain("HORIEN COLLAGEN PLUG");
      expect(text).not.toContain("Neoalgin - Vật Liệu Lấy Dấu Alginate");
    }
  });

  it("should keep MP4 pending and explain quota errors instead of claiming completion", () => {
    expect(formatVeoProviderFailure({ status: 429, message: "RESOURCE_EXHAUSTED quota" })).toContain("hết quota");
    expect(formatVeoProviderFailure(new Error("provider unavailable"))).toContain("provider_pending");
  });

  it("should preserve provider_pending when Veo rejects a real generation attempt", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: { id: 1, openId: "test", name: "Owner", email: "owner@24seven.vn", role: "admin", createdAt: new Date(), updatedAt: new Date() }
    });
    const products = await caller.zeroTouch.getProducts();
    const targetProduct = products[0];
    const originalTestProviderFlag = process.env.VEO_TEST_PROVIDER;
    process.env.VEO_TEST_PROVIDER = "true";
    const providerSpy = vi.spyOn(veoProvider, "generate").mockRejectedValue({ status: 429, message: "RESOURCE_EXHAUSTED quota" });

    try {
      const res = await caller.zeroTouch.generateTiktokVideo({ productId: targetProduct.id });
      expect(res.success).toBe(true);
      expect(res.generationStatus).toBe("provider_pending");
      expect(res.videoUrl).toBeNull();
      expect(res.message).toContain("hết quota");

      const db = await getDb();
      if (db) {
        const videos = await db.select().from(tiktokVideos);
        const latest = videos.filter(video => video.productName === targetProduct.name).sort((a, b) => b.id - a.id)[0];
        expect(latest?.generationStatus).toBe("provider_pending");
        expect(latest?.videoUrl).toBeNull();
        expect(latest?.approvalStatus).toBe("approved");
      }
    } finally {
      providerSpy.mockRestore();
      if (originalTestProviderFlag === undefined) delete process.env.VEO_TEST_PROVIDER;
      else process.env.VEO_TEST_PROVIDER = originalTestProviderFlag;
    }
  }, 30000);

  it("should reject reference-adapted mode when no public reference URL is supplied", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: { id: 1, openId: "test", name: "Owner", email: "owner@24seven.vn", role: "admin", createdAt: new Date(), updatedAt: new Date() }
    });
    const products = await caller.zeroTouch.getProducts();
    await expect(caller.zeroTouch.generateTiktokVideo({ productId: products[0].id, generationMode: "reference_adapted" })).rejects.toThrow("link video công khai");
  });

  it("should create backorder request when product is out of stock", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: { id: 1, openId: "test", name: "Owner", email: "owner@24seven.vn", role: "admin", createdAt: new Date(), updatedAt: new Date() }
    });

    const res = await caller.zeroTouch.createBackorderRequest({
      productName: "Nhựa đệm hàm DIL",
      productCode: "DIL-01",
      requestedQuantity: 50,
      dealerName: "Phòng khám Nha khoa Sài Gòn",
      dealerPhone: "0909123456"
    });
    expect(res.success).toBe(true);

    const list = await caller.zeroTouch.listBackorderRequests();
    expect(list.length).toBeGreaterThan(0);
    expect(list[0].dealerName).toBe("Phòng khám Nha khoa Sài Gòn");
  });

  it("should successfully store MP4 and mark completed when Veo provider succeeds", async () => {
    const caller = appRouter.createCaller({
      req: {} as any,
      res: {} as any,
      user: { id: 1, openId: "test", name: "Owner", email: "owner@24seven.vn", role: "admin", createdAt: new Date(), updatedAt: new Date() }
    });
    const products = await caller.zeroTouch.getProducts();
    const targetProduct = products[0];
    const originalTestProviderFlag = process.env.VEO_TEST_PROVIDER;
    process.env.VEO_TEST_PROVIDER = "true";

    const providerSpy = vi.spyOn(veoProvider, "generate").mockResolvedValue({
      key: "ai-videos/mock-video.mp4",
      url: "/manus-storage/ai-videos/mock-video.mp4"
    });

    try {
      const res = await caller.zeroTouch.generateTiktokVideo({ productId: targetProduct.id });
      expect(res.success).toBe(true);
      expect(res.generationStatus).toBe("completed");
      expect(res.videoUrl).toMatch(/^\/manus-storage\/.+\.mp4$/);

      const db = await getDb();
      if (db) {
        const videos = await db.select().from(tiktokVideos);
        const latest = videos.filter(video => video.productName === targetProduct.name).sort((a, b) => b.id - a.id)[0];
        expect(latest?.generationStatus).toBe("completed");
        expect(latest?.videoUrl).toMatch(/^\/manus-storage\/.+\.mp4$/);
        expect(latest?.approvalStatus).toBe("approved");
      }
    } finally {
      providerSpy.mockRestore();
      if (originalTestProviderFlag === undefined) delete process.env.VEO_TEST_PROVIDER;
      else process.env.VEO_TEST_PROVIDER = originalTestProviderFlag;
    }
  }, 30000);
});

describe("Gemini provider configuration", () => {
  it("accepts the configured Gemini API key on the lightweight models endpoint", async () => {
    const apiKey = process.env.GEMINI_API_KEY;
    expect(apiKey).toBeTruthy();
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey ?? "")}`,
    );
    expect(response.status).toBe(200);
  });
});
