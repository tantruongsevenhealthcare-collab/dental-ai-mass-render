import { describe, expect, it } from "vitest";
import { getAssistedSocialUrl, getMissingPublishScopes, socialPlatforms } from "../client/src/lib/socialPlatforms";
import { isSocialOAuthConfigured, buildSocialAuthorizationUrl } from "./socialOAuth";
import { composeFacebookPost, createFacebookPublisherPayload } from "../client/src/lib/facebookPublisher";
import { composeTikTokCaption, createTikTokPublisherPayload } from "../client/src/lib/tiktokPublisher";

describe("social connection dashboard", () => {
  it("exposes exactly the three requested personal channels", () => {
    expect(socialPlatforms.map((platform) => platform.key)).toEqual(["facebook", "zalo", "tiktok"]);
    expect(socialPlatforms.every((platform) => platform.name.includes("cá nhân"))).toBe(true);
    expect(socialPlatforms.every((platform) => platform.description.length > 20)).toBe(true);
    expect(socialPlatforms.map((platform) => platform.officialUrl)).toEqual([
      "https://www.facebook.com/",
      "https://id.zalo.me/",
      "https://www.tiktok.com/login",
    ]);
    expect(socialPlatforms.every((platform) => !platform.description.includes("Client Secret"))).toBe(true);
    expect(socialPlatforms.every((platform) => platform.description.includes("Sale") || platform.description.includes("Sale"))).toBe(true);
  });

  it("opens the same official assisted-connect destinations as the standalone reference flow", () => {
    expect(getAssistedSocialUrl("facebook")).toBe("https://www.facebook.com/");
    expect(getAssistedSocialUrl("zalo")).toBe("https://id.zalo.me/");
    expect(getAssistedSocialUrl("tiktok")).toBe("https://www.tiktok.com/login");
    expect(getAssistedSocialUrl("unknown")).toBeUndefined();
  });

  it("composes approved Facebook content with the configured landing URL", () => {
    expect(composeFacebookPost({ content: "Bài viết sản phẩm", landingUrl: "https://example.com/san-pham" })).toBe("Bài viết sản phẩm\n\nXem chi tiết tại: https://example.com/san-pham");
    expect(composeFacebookPost({ content: "Bài viết sản phẩm", landingUrl: "" })).toBe("Bài viết sản phẩm");
    expect(createFacebookPublisherPayload({ content: "Bài viết sản phẩm", landingUrl: "https://example.com", mediaUrl: "https://example.com/a.jpg", productName: "Collagen", sourceId: 7 })).toMatchObject({ approved: true, platform: "facebook", mediaUrl: "https://example.com/a.jpg", sourceId: "7" });
  });

  it("composes TikTok caption with hashtags, landing URL and media payload", () => {
    const caption = composeTikTokCaption({ script: "Video hướng dẫn sản phẩm", landingUrl: "https://example.com", productName: "Collagen Plug" });
    expect(caption).toContain("Video hướng dẫn sản phẩm");
    expect(caption).toContain("#NhaKhoa");
    expect(caption).toContain("Xem chi tiết tại: https://example.com");
    expect(createTikTokPublisherPayload({ script: "Video", mediaUrl: "https://example.com/video.mp4", sourceId: 9 })).toMatchObject({ approved: true, platform: "tiktok", mediaUrl: "https://example.com/video.mp4", sourceId: "9" });
  });

  it("does not create an OAuth URL from missing development credentials", () => {
    expect(isSocialOAuthConfigured("facebook")).toBe(false);
    expect(() => buildSocialAuthorizationUrl("test-user", "facebook")).toThrow(/OAuth Production chưa được cấu hình/);
  });

  it("detects missing publish scopes per Business platform", () => {
    expect(getMissingPublishScopes("facebook", ["pages_manage_posts"])).toEqual([]);
    expect(getMissingPublishScopes("facebook", [])).toEqual(["pages_manage_posts"]);
    expect(getMissingPublishScopes("zalo", [])).toEqual(["oa.post"]);
    expect(getMissingPublishScopes("tiktok", ["user.info.basic"])).toEqual(["video.publish"]);
  });
});
