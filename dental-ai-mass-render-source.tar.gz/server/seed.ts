import { getDb } from "./db";
import { products, agentConfigs, ceoDecisionRules } from "../drizzle/schema";

export async function seedInitialData() {
  const db = await getDb();
  if (!db) {
    console.warn("[Seed] Database not available");
    return;
  }

  try {
    // 1. Seed 12 fixed dental products with upsert
    const initialProducts = [
      {
        code: "SP-01",
        name: "Nhựa đệm hàm DIL (hộp lớn)",
        category: "material" as const,
        price: "3025000",
        unit: "Hộp lớn",
        description: "Nhựa đệm hàm chất lượng cao DIL, hộp lớn chuyên dụng cho labo và phòng khám nha khoa.",
        stock: 150,
      },
      {
        code: "SP-02",
        name: "Nhựa Đệm Hàm DENTURE SOFT EX",
        category: "material" as const,
        price: "877000",
        unit: "Hộp",
        description: "Nhựa đệm hàm mềm DENTURE SOFT EX giúp tăng độ thoải mái cho hàm giả.",
        stock: 200,
      },
      {
        code: "SP-03",
        name: "Peri-Resin II",
        category: "material" as const,
        price: "847000",
        unit: "Bộ",
        description: "Vật liệu nha khoa Peri-Resin II chuyên dùng trong phục hình và điều trị nha chu.",
        stock: 120,
      },
      {
        code: "SP-04",
        name: "Collagen khối cầm máu, đau sau nhổ răng",
        category: "material" as const,
        price: "69000",
        unit: "Miếng/Khối",
        description: "Collagen khối hỗ trợ cầm máu nhanh chóng và giảm đau hiệu quả sau khi nhổ răng.",
        stock: 500,
      },
      {
        code: "SP-05",
        name: "HORIEN COLLAGEN PLUG",
        category: "material" as const,
        price: "750000",
        unit: "Hộp",
        description: "Mút collagen cắm ghép Horien Collagen Plug chất lượng quốc tế.",
        stock: 100,
      },
      {
        code: "SP-06",
        name: "Xương ghép Collagen khối + beta TCP",
        category: "material" as const,
        price: "1460000",
        unit: "Lọ/Khối",
        description: "Vật liệu ghép xương sinh học kết hợp Collagen và Beta TCP tái tạo xương ổ răng tối ưu.",
        stock: 90,
      },
      {
        code: "SP-07",
        name: "Cao su lấy dấu NEOPURE PUTTY (FAST SET)",
        category: "material" as const,
        price: "1000000",
        unit: "Bộ",
        description: "Cao su đặc lấy dấu Neopure Putty đông cứng nhanh, độ chính xác cao.",
        stock: 180,
      },
      {
        code: "SP-08",
        name: "Cao su lấy dấu Neopure Light Body (Fast Set)",
        category: "material" as const,
        price: "450000",
        unit: "Tuýp",
        description: "Cao su lỏng lấy dấu chi tiết viền nướu Neopure Light Body.",
        stock: 220,
      },
      {
        code: "SP-09",
        name: "Neoalgin - Vật Liệu Lấy Dấu Alginate",
        category: "material" as const,
        price: "125000",
        unit: "Gói",
        description: "Bột lấy dấu Alginate Neoalgin mịn, dễ trộn, hương thơm dễ chịu.",
        stock: 300,
      },
      {
        code: "SP-10",
        name: "Biofilling Starter Kit",
        category: "equipment" as const,
        price: "13125000",
        unit: "Bộ Kit",
        description: "Bộ thiết bị khởi đầu Biofilling chuyên nghiệp cho điều trị nội nha và trám bít.",
        stock: 35,
      },
      {
        code: "SP-11",
        name: "Cây quay MTA xuống ống tủy: Compacter",
        category: "equipment" as const,
        price: "385000",
        unit: "Cây",
        description: "Dụng cụ chuyên dụng đưa MTA xuống ống tủy chính xác và an toàn.",
        stock: 150,
      },
      {
        code: "SP-12",
        name: "Chai nhỏ giọt nước cất",
        category: "material" as const,
        price: "330000",
        unit: "Chai",
        description: "Chai nhỏ giọt nước cất tinh khiết phục vụ thao tác phòng khám nha khoa.",
        stock: 250,
      },
    ];

    for (const p of initialProducts) {
      await db.insert(products).values(p).onDuplicateKeyUpdate({
        set: { price: p.price, stock: p.stock, description: p.description }
      });
    }

    // 2. Seed 5 Agent System Prompts with upsert
    const initialAgents = [
      {
        agentKey: "ceo",
        name: "AI CEO",
        roleDescription: "Tổng hợp số liệu toàn hệ thống, quản lý KPI 300Tr/tháng, báo cáo tinh gọn và cảnh báo kẹt đơn > 24h.",
        systemPrompt: `QUY TẮC BẮT BUỘC: TRẢ LỜI CỰC KỲ NGẮN GỌN, ĐÚNG TRỌNG TÂM, KHÔNG LAN MAN.
Bạn là AI CEO của "24 Seven Health Care Vietnam".
Nhiệm vụ: Quản lý KPI 300Tr/tháng (10Tr/ngày), duyệt giá, báo cáo ngắn gọn doanh số và trạng thái đơn hàng. Chỉ tập trung vào số liệu cốt lõi, tên sản phẩm, giá và hành động cần duyệt.`,
        status: "active" as const,
      },
      {
        agentKey: "marketing",
        name: "AI Marketing",
        roleDescription: "Chuyên gia sáng tạo content, kịch bản video TikTok, Facebook, Zalo dựa trên sản phẩm.",
        systemPrompt: `QUY TẮC BẮT BUỘC: TRẢ LỜI CỰC KỲ NGẮN GỌN, ĐÚNG TRỌNG TÂM, KHÔNG LAN MAN.
Bạn là AI Marketing chuyên trách của "24 Seven Health Care Vietnam".
Nhiệm vụ: Đề xuất nội dung, kịch bản TikTok/Facebook ngắn gọn bám sát tên chuẩn sản phẩm và giá chính thức từ Kho. Không viết văn dài dòng.`,
        status: "active" as const,
      },
      {
        agentKey: "sales",
        name: "AI Sales",
        roleDescription: "Chuyên gia tư vấn và chốt đơn dựa trên catalogue sản phẩm chính thức.",
        systemPrompt: `QUY TẮC BẮT BUỘC: TRẢ LỜI CỰC KỲ NGẮN GỌN, ĐÚNG TRỌNG TÂM, KHÔNG LAN MAN.
Bạn là AI Sales chuyên nghiệp của "24 Seven Health Care Vietnam".
Nhiệm vụ: Tư vấn tên chuẩn sản phẩm, quy cách, đơn giá và chốt đơn nhanh chóng. Không tiết lộ tồn kho nội bộ, không lan man.`,
        status: "active" as const,
      },
      {
        agentKey: "warehouse",
        name: "AI Kho",
        roleDescription: "Theo dõi trạng thái xuất đơn, đơn giá và cảnh báo đơn kẹt.",
        systemPrompt: `QUY TẮC BẮT BUỘC: TRẢ LỜI CỰC KỲ NGẮN GỌN, ĐÚNG TRỌNG TÂM, KHÔNG LAN MAN.
Bạn là AI Kho phụ trách kho trung tâm của "24 Seven Health Care Vietnam".
Nhiệm vụ: Cập nhật trạng thái xuất đơn, tình trạng sản phẩm trong kho và cảnh báo đơn kẹt > 24h. Chỉ báo cáo đúng trọng tâm.`,
        status: "active" as const,
      },
      {
        agentKey: "accountant",
        name: "AI Kế toán",
        roleDescription: "Ghi nhận doanh số, phân tách tỷ lệ vật tư/thiết bị và tính hoa hồng tự động.",
        systemPrompt: `QUY TẮC BẮT BUỘC: TRẢ LỜI CỰC KỲ NGẮN GỌN, ĐÚNG TRỌNG TÂM, KHÔNG LAN MAN.
Bạn là AI Kế toán của "24 Seven Health Care Vietnam".
Nhiệm vụ: Ghi nhận doanh số, phân tách vật tư/thiết bị và báo cáo dòng tiền chuẩn xác bằng số liệu ngắn gọn.`,
        status: "active" as const,
      },
    ];

    for (const a of initialAgents) {
      await db.insert(agentConfigs).values(a).onDuplicateKeyUpdate({
        set: { name: a.name, roleDescription: a.roleDescription, systemPrompt: a.systemPrompt }
      });
    }

    // 3. Seed CEO Decision Rules
    const initialRules = [
      {
        ruleKey: "rule_stock_check",
        ruleName: "Kiểm tra tồn kho 17 Phạm Vấn (Stock Validation)",
        isEnabled: true,
        description: "Chỉ tự phê duyệt đề xuất marketing/chiến dịch khi sản phẩm liên quan còn đủ số lượng tồn kho thực tế tại kho 17 Phạm Vấn."
      },
      {
        ruleKey: "rule_price_policy",
        ruleName: "Chuẩn hóa giá niêm yết (Price Policy Check)",
        isEnabled: true,
        description: "Đảm bảo các đề xuất không tự ý giảm giá vượt quá hạn mức chiết khấu cho phép hoặc sai lệch giá niêm yết 12 sản phẩm."
      },
      {
        ruleKey: "rule_medical_safety",
        ruleName: "Bộ lọc an toàn y khoa (Medical Safety Guardrail)",
        isEnabled: true,
        description: "Chặn ngay các nội dung quảng cáo có cam kết điều trị y khoa quá đà hoặc sai lệch tiêu chuẩn chuyên ngành nha khoa."
      },
      {
        ruleKey: "rule_kpi_alignment",
        ruleName: "Định hướng mục tiêu doanh số ngày (KPI Daily Alignment)",
        isEnabled: true,
        description: "Ưu tiên tự động phê duyệt các chiến dịch tập trung vào sản phẩm chủ lực để hỗ trợ đạt mục tiêu doanh số ngày."
      }
    ];

    for (const r of initialRules) {
      await db.insert(ceoDecisionRules).values(r).onDuplicateKeyUpdate({
        set: { ruleName: r.ruleName, isEnabled: r.isEnabled, description: r.description }
      });
    }

    console.log("[Seed] Data seeded successfully with upsert.");
  } catch (error) {
    console.error("[Seed] Error seeding initial data:", error);
  }
}
