import crypto from "node:crypto";
import { ENV } from "./_core/env";

export type SocialPlatform = "facebook" | "zalo" | "tiktok";
export type PublishInput = { platform: SocialPlatform; accessToken: string; content: string; mediaUrl?: string | null; targetId: string };
export type PublishResult = { externalPostId: string; externalUrl: string };

export function isSocialDemoMode(): boolean {
  return !ENV.facebookAppId && !ENV.zaloAppId && !ENV.tiktokClientKey;
}

function encryptionKey(): Buffer {
  const configuredKey = ENV.socialTokenEncryptionKey;
  if (!configuredKey && !isSocialDemoMode()) throw new Error("SOCIAL_TOKEN_ENCRYPTION_KEY is not configured");
  return crypto.createHash("sha256").update(configuredKey || "dental-ai-mass-demo-token-key").digest();
}

export function encryptSocialToken(value: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return [iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), encrypted.toString("base64url")].join(".");
}

export function decryptSocialToken(value: string): string {
  const [ivPart, tagPart, dataPart] = value.split(".");
  if (!ivPart || !tagPart || !dataPart) throw new Error("Invalid encrypted social token");
  const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivPart, "base64url"));
  decipher.setAuthTag(Buffer.from(tagPart, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(dataPart, "base64url")), decipher.final()]).toString("utf8");
}

async function apiRequest(url: string, init: RequestInit): Promise<any> {
  const response = await fetch(url, init);
  const text = await response.text();
  let body: any;
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!response.ok) {
    const error = new Error(`Social API ${response.status}: ${body?.error?.message || body?.message || text.slice(0, 300)}`) as Error & { status?: number; body?: unknown };
    error.status = response.status;
    error.body = body;
    throw error;
  }
  return body;
}

export async function publishFacebookPage(input: PublishInput): Promise<PublishResult> {
  const body = await apiRequest(`https://graph.facebook.com/v20.0/${encodeURIComponent(input.targetId)}/feed`, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ message: input.content, access_token: input.accessToken }),
  });
  if (!body.id) throw new Error("Facebook API returned no post id");
  return { externalPostId: String(body.id), externalUrl: `https://www.facebook.com/${body.id}` };
}

export async function publishZaloOa(input: PublishInput): Promise<PublishResult> {
  if (!input.targetId) throw new Error("Zalo OA targetId is required; personal Zalo feed is not assumed to be publishable by API");
  const body = await apiRequest("https://openapi.zalo.me/v2.0/article/create", {
    method: "POST", headers: { "content-type": "application/json", access_token: input.accessToken },
    body: JSON.stringify({ oa_id: input.targetId, title: input.content.slice(0, 120), description: input.content, status: "show" }),
  });
  const postId = body?.data?.article_id || body?.article_id || body?.data?.id;
  if (!postId) throw new Error("Zalo API returned no article id");
  return { externalPostId: String(postId), externalUrl: `https://zalo.me/${postId}` };
}

export async function publishTikTokVideo(input: PublishInput): Promise<PublishResult> {
  if (!input.mediaUrl) throw new Error("TikTok Content Posting API requires a video URL");
  const body = await apiRequest("https://open.tiktokapis.com/v2/post/publish/video/init/", {
    method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${input.accessToken}` },
    body: JSON.stringify({ post_info: { title: input.content, privacy_level: "PUBLIC_TO_EVERYONE", disable_duet: false, disable_comment: false, disable_stitch: false }, source_info: { source: "PULL_FROM_URL", video_url: input.mediaUrl } }),
  });
  const publishId = body?.data?.publish_id;
  if (!publishId) throw new Error("TikTok API returned no publish id");
  return { externalPostId: String(publishId), externalUrl: `https://www.tiktok.com/@me/video/${publishId}` };
}

export async function publishSocialPost(input: PublishInput): Promise<PublishResult> {
  if (input.platform === "facebook") return publishFacebookPage(input);
  if (input.platform === "zalo") return publishZaloOa(input);
  return publishTikTokVideo(input);
}

export function isRetryableSocialError(error: unknown): boolean {
  const status = (error as { status?: number })?.status;
  return status === 408 || status === 409 || status === 425 || status === 429 || (typeof status === "number" && status >= 500);
}
