import { describe, expect, it } from "vitest";
import { extractLLMText } from "./routers/zeroTouchRouter";

describe("AI Marketing LLM output", () => {
  it("extracts text content from a normal completion", () => {
    expect(extractLLMText({
      choices: [{ message: { content: "  Bài viết sản phẩm  " } }],
    })).toBe("Bài viết sản phẩm");
  });

  it("joins text parts without exposing the provider response object", () => {
    expect(extractLLMText({
      choices: [{ message: { content: [
        { type: "text", text: "Phần một" },
        { type: "image_url", image_url: { url: "https://example.invalid/image" } },
        { type: "text", text: "Phần hai" },
      ] } }],
    })).toBe("Phần một\\nPhần hai");
  });

  it("returns empty text for an invalid provider result", () => {
    expect(extractLLMText({ choices: [{ message: { content: null } }] })).toBe("");
    expect(extractLLMText(undefined)).toBe("");
  });
});
