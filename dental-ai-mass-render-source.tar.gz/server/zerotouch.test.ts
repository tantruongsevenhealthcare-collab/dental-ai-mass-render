import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createTestContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-admin",
      email: "admin@24sevenhc.com.vn",
      name: "Admin Zero-Touch",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as any,
    res: { clearCookie: () => {} } as any,
  };
}

describe("24 Seven Health Care Vietnam - Zero Touch MAS Comprehensive Tests", () => {
  it("should initialize data, fetch 12 dental products and agent configs", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const initRes = await caller.zeroTouch.initData();
    expect(initRes.success).toBe(true);

    const products = await caller.zeroTouch.getProducts();
    expect(products.length).toBeGreaterThanOrEqual(1);

    const agents = await caller.zeroTouch.getAgents();
    expect(agents.length).toBe(5);
  }, 20000);

  it("should retrieve KPI dashboard statistics correctly", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const kpi = await caller.zeroTouch.getKPIDashboard();
    expect(kpi).toBeDefined();
    expect(kpi.monthlyTarget).toBe(300000000);
    expect(kpi.dailyTarget).toBe(10000000);
  }, 20000);

  it("should execute order pipeline from AI Sales to Warehouse and Accountant", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);

    const products = await caller.zeroTouch.getProducts();
    const sampleProduct = products.find(p => Number(p.price) > 0) || products[0];
    if (Number(sampleProduct.price) <= 0) {
      // Đảm bảo có giá test hợp lệ
      await caller.zeroTouch.updateProductPrice({ productId: sampleProduct.id, price: 1500000 });
    }

    const orderRes = await caller.zeroTouch.createOrder({
      customerName: "Phòng khám Nha khoa Test",
      customerPhone: "0963166698",
      customerAddress: "17 Phạm Vấn, Tân Phú, TP.HCM",
      items: [
        {
          productId: sampleProduct.id,
          code: sampleProduct.code,
          name: sampleProduct.name,
          category: sampleProduct.category,
          price: Number(sampleProduct.price),
          quantity: 2,
        }
      ],
      notes: "Đơn hàng kiểm thử tự động Zero-Touch",
    });

    expect(orderRes.success).toBe(true);
    expect(orderRes.orderCode).toBeDefined();

    const orders = await caller.zeroTouch.getOrders();
    const createdOrder = orders.find(o => o.orderCode === orderRes.orderCode);
    expect(createdOrder).toBeDefined();
    expect(createdOrder?.status).toBe("processing");

    const updateRes = await caller.zeroTouch.updateOrderStatus({
      orderId: createdOrder!.id,
      status: "completed",
      paymentStatus: "paid",
    });
    expect(updateRes.success).toBe(true);

    const logs = await caller.zeroTouch.getAgentLogs();
    expect(logs.length).toBeGreaterThan(0);
  }, 20000);
});
