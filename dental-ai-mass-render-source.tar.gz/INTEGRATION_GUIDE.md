# Hướng dẫn Kỹ thuật Triển khai Tích hợp Thực tế (Zero-Touch MAS)
**Tập đoàn Phân phối Vật tư & Thiết bị Nha khoa: 24 Seven Health Care Vietnam**
- **Địa điểm Kho Trung tâm**: 17 Phạm Vấn, Tân Phú, TP.HCM
- **Hotline/Zalo**: 0963166698 | **Website**: https://www.24sevenhc.com.vn/

---

## Tổng quan Kiến trúc Tích hợp
Để chuyển đổi hệ thống từ mô hình mô phỏng (pilot/demo) sang môi trường vận hành thực tế (Production), hệ thống cần kết nối thông qua các cổng API chuẩn và cơ chế bảo mật Webhook với 3 đối tác hạ tầng cốt lõi:
1. **Cổng Thanh toán Điện tử** (Ví dụ: VNPay, MoMo, SePay / Chuyển khoản ngân hàng tự động qua QR code động).
2. **Hệ thống Quản lý Kho / WMS nội bộ hoặc WMS đối tác tại 17 Phạm Vấn**.
3. **Đơn vị Vận chuyển Logistics** (Ví dụ: GHN - Giao Hàng Nhanh, GHTK, Viettel Post hoặc dịch vụ vận chuyển lạnh chuyên dụng cho vật tư y tế).

---

## 1. Kết nối Cổng Thanh toán Điện tử (Payment Gateway)

### 1.1. Lựa chọn Đề xuất tại Việt Nam
- **SePay / VietQR (Khuyên dùng cho B2B Nha khoa)**: Cung cấp Webhook tự động nhận thông báo biến động số dư tài khoản ngân hàng thông qua mã QR động (nội dung chuyển khoản chứa mã đơn hàng `ORD-XXXXXX`).
- **VNPay-QR / MoMo Business API**: Phù hợp cho thanh toán thẻ quốc tế/nội địa và quét mã QR ứng dụng ngân hàng.

### 1.2. Quy trình Kỹ thuật (Workflow)
1. **Khởi tạo giao dịch**: Khi AI Sales chốt đơn, hệ thống tạo bản ghi đơn hàng với trạng thái `paymentStatus: 'pending'` và sinh mã QR động (hoặc URL thanh toán VNPay) gắn liền với `orderCode`.
2. **Xử lý Webhook thanh toán thành công**:
   - Cổng thanh toán gửi HTTP POST request tới endpoint bảo mật của hệ thống: `/api/webhooks/payment`.
   - Hệ thống xác thực chữ ký số (HMAC SHA256) từ payload để đảm bảo an toàn.
   - Cập nhật trạng thái đơn hàng thành `paymentStatus: 'paid'`, chuyển trạng thái đơn sang Kho và ghi nhận doanh thu thực tế vào AI Kế toán.

### 1.3. Mã nguồn Mẫu tRPC/Express Webhook Xử lý Thanh toán
```ts
// server/routers/webhookRouter.ts (Mẫu định hướng)
export const paymentWebhookRouter = createTRPCRouter({
  handlePaymentWebhook: publicProcedure
    .input(z.object({
      orderCode: z.string(),
      amount: z.number(),
      transactionId: z.string(),
      signature: z.string(),
    }))
    .mutation(async ({ input }) => {
      // 1. Xác thực chữ ký HMAC bảo mật
      // 2. Cập nhật trạng thái đơn hàng sang 'paid' và kích hoạt AI Kế toán ghi nhận doanh thu
      return { success: true };
    }),
});
```

---

## 2. Kết nối Hệ thống Kho thực tế tại 17 Phạm Vấn (Inventory / WMS)

### 2.1. Yêu cầu Hạ tầng
- Nếu kho 17 Phạm Vấn sử dụng phần mềm quản lý kho riêng (như Sapo, KiotViet, hoặc WMS tùy chỉnh), cần xin cấp **API Key / Bearer Token** và tài liệu API Quản lý Tồn kho.
- Nếu vận hành theo mô hình Zero-Touch thuần túy (nhà cung cấp giao thẳng hoặc kho trung chuyển 17 Phạm Vấn quản lý xuất nhập), hệ thống sẽ kết nối trực tiếp qua REST API tới hệ thống WMS của đối tác.

### 2.2. Quy trình Kỹ thuật
1. **Kiểm tra tồn kho trước khi chốt đơn**: Trước khi AI Sales xác nhận đơn hàng, hệ thống gọi API `GET /api/wms/stock?sku=CODE` để kiểm tra số lượng tồn thực tế tại kho 17 Phạm Vấn.
2. **Tạo phiếu xuất kho tự động (Pick & Pack)**: Ngay khi đơn hàng được thanh toán hoặc phê duyệt bởi AI CEO, hệ thống tự động gọi API `POST /api/wms/orders` để đẩy thông tin đơn hàng xuống máy in nhãn tại kho 17 Phạm Vấn.

---

## 3. Kết nối Đơn vị Vận chuyển (Logistics API - GHN / GHTK)

### 3.1. Tích hợp Giao Hàng Nhanh (GHN) API v2
- **Đăng ký tài khoản**: Lấy `Token` (API Token) và `Shop_id` tại cổng phát triển của GHN.
- **Các bước API chính**:
  1. `POST /v2/shipping-order/fee`: Tính phí vận chuyển tự động dựa trên địa chỉ phòng khám nha khoa khách hàng và trọng lượng 12 sản phẩm cố định.
  2. `POST /v2/shipping-order/create`: Tạo vận đơn giao hàng xuất phát từ kho **17 Phạm Vấn, Tân Phú, TP.HCM**.
  3. `GET /v2/shipping-order/detail`: Tra cứu hành trình đơn hàng thời gian thực để AI CEO giám sát đơn kẹt > 24h.

### 3.2. Mẫu Payload Tạo Vận Đơn GHN
```json
{
  "payment_type_id": 1,
  "note": "Giao giờ hành chính, hàng vật tư y tế nha khoa cẩn thận",
  "required_note": "KHONGCHOXEMHANG",
  "from_name": "24 Seven Health Care Vietnam",
  "from_phone": "0963166698",
  "from_address": "17 Phạm Vấn, Phường Phú Thọ Hòa, Quận Tân Phú, TP.HCM",
  "to_name": "Phòng Khám Nha Khoa Khách Hàng",
  "to_phone": "0900000000",
  "to_address": "Số 123 Đường ABC, Quận 1, TP.HCM",
  "weight": 500,
  "length": 15,
  "width": 15,
  "height": 10,
  "service_type_id": 2,
  "items": [
    {
      "name": "Nhựa đệm hàm DIL",
      "quantity": 1,
      "weight": 200
    }
  ]
}
```

---

## 4. Bảo mật, Đối soát và Xử lý Lỗi (Security & Reconciliation)
1. **Bảo mật Webhook**: Mọi endpoint nhận callback từ cổng thanh toán và vận chuyển bắt buộc phải kiểm tra `IP Whitelisting` và `HMAC Signature Header` để ngăn chặn giả mạo request.
2. **Cơ chế Đối soát Cuối ngày**: AI Kế toán sẽ tự động chạy một tiến trình background lúc 23:59 hằng ngày để đối soát tổng số tiền thực nhận từ tài khoản ngân hàng / cổng thanh toán với tổng giá trị đơn hàng hoàn thành trong ngày, phát hiện chênh lệch và gửi cảnh báo khẩn cấp cho Quản lý.
3. **Cơ chế Retry (Thử lại thông minh)**: Khi kết nối API Kho hoặc Vận chuyển bị lỗi mạng (Timeout), hệ thống tự động đưa request vào hàng đợi (Queue) và thử lại tối đa 3 lần trước khi chuyển đơn sang trạng thái `stuck` để AI CEO can thiệp.

---

## 5. Checklist Thông tin Cần chuẩn bị để Triển khai Thật
- [ ] **Cổng Thanh toán**: Hợp đồng mở tài khoản doanh nghiệp với SePay, VNPay hoặc MoMo Business; nhận API Key và Secret Key.
- [ ] **Vận chuyển**: Tài khoản đối tác GHN / GHTK / Viettel Post, lấy API Token và xác nhận địa chỉ kho xuất phát chính xác là **17 Phạm Vấn, Tân Phú, TP.HCM**.
- [ ] **Tên miền & Hosting Production**: Trỏ tên miền chính thức (ví dụ: `app.24sevenhc.com.vn`) lên hệ thống và cấu hình chứng chỉ SSL bảo mật HTTPS.
- [ ] **Zalo OA / Telegram Bot**: Đăng ký Zalo Official Account doanh nghiệp và tạo Telegram Bot Token để AI CEO tự động bắn thông báo báo cáo sáng 08:00 và cảnh báo đơn kẹt trực tiếp về điện thoại quản lý.
