# Project TODO - 24 Seven Health Care Vietnam

## Sửa lỗi Runtime (August 2026)
- [x] Khắc phục lỗi ReferenceError: trpc is not defined ở frontend (DashboardLayout.tsx và các component liên quan)
- [x] Chuẩn hóa import trpc từ `@/lib/trpc` trong toàn bộ client src
- [x] Chạy pnpm build và vitest để đảm bảo không còn lỗi biên dịch hoặc runtime

- [x] Thiết kế cơ sở dữ liệu (`drizzle/schema.ts`) cho sản phẩm nha khoa từ Google Sheets, đơn hàng, cấu hình Agent và nhật ký hoạt động
- [x] Xây dựng bộ 5 System Prompts chuẩn xác cho AI CEO, AI Marketing, AI Sales, AI Kho (17 Phạm Vấn), và AI Kế toán
- [x] Xây dựng các tRPC procedures (`server/routers.ts`) xử lý luồng đơn hàng tự động, chat AI với LLM, thống kê KPI và cảnh báo đơn kẹt > 24h
- [x] Xây dựng giao diện Dashboard tổng quan KPI, Quản lý kho sản phẩm cố định, Kênh chat đa Agent và Quản lý pipeline đơn hàng
- [x] Nâng cấp AI CEO thành trung tâm điều hành có báo cáo 08:00, Decision Engine tự phê duyệt có điều kiện và Rule Builder
- [x] Lập trình Negotiation Engine và tRPC procedures cho AI CEO đàm phán với đối tác nha khoa
- [x] Nâng cấp AI Sales thành quy trình chốt đơn thực tế kết nối catalogue Google Sheets với cơ chế khóa giá server-side
- [x] Xây dựng Market Intelligence Engine tự động thu thập tín hiệu đa nguồn (Google, Facebook, TikTok, Đối thủ) có kiểm chứng evidence-first
- [x] Gỡ bỏ hoàn toàn lớp xác nhận Chủ doanh nghiệp bằng OTP phức tạp, trả lại quyền truy cập dashboard mượt mà trực tiếp
- [x] Chạy kiểm thử toàn bộ test suite Vitest (đạt 100% pass)
- [x] Xóa hẳn trường `stock` khỏi response `getProducts` công khai, trả `availabilityStatus` thay thế
- [x] Tích hợp `dealerTrackOrder` vào giao diện đại lý với đúng 3 trạng thái chuẩn
- [x] Kết nối tự động khi thiếu hàng trong đơn sang bảng `backorder_requests` và bắn thông báo cho AI Kho
- [x] Mở rộng bảng tiktokStreamAssets hoặc tạo tiktokVideos table để lưu trữ storyboard/kịch bản, avatar prompt, trạng thái sinh file và trạng thái kiểm duyệt
- [x] Xây dựng tRPC procedure tạo storyboard/kịch bản video ngắn TikTok/Reels bám sát thông số kỹ thuật sản phẩm Google Sheets
- [x] Tích hợp giao diện AI Video Studio trong tab AI Marketing với nút tạo storyboard, xem trạng thái file và trình duyệt CEO
- [x] Chạy kiểm thử hệ thống và xác nhận module tạo storyboard hoạt động ổn định

- [x] Xây dựng giao diện tra cứu đơn hàng dành riêng cho đại lý (Dealer Portal) gọi `dealerTrackOrder` với 3 trạng thái chuẩn
- [x] Cập nhật luồng chốt đơn thiếu hàng tự động ghi nhận vào `backorder_requests` và bắn thông báo cho AI Kho thay vì chỉ báo lỗi
- [x] Thay thế URL video mẫu giả lập bằng trạng thái cấu hình thực tế; không còn ghi hoặc mở link MP4 mẫu khi chưa có nhà cung cấp text-to-video
- [x] Chạy kiểm thử tích hợp cho luồng video hai chế độ và backorder; xác minh typecheck, Vitest và browser render

- [x] Mở rộng bảng `tiktok_videos` hỗ trợ 2 chế độ: tự tạo mới từ dữ liệu sản phẩm hoặc tạo lại dựa trên video tham khảo công khai (không sao chép nguyên bản)
- [x] Nâng cấp tRPC procedure `generateTiktokVideo` nhận tham số `generationMode` ('self_generated' | 'reference_adapted') cùng `referenceVideoUrl` và `searchKeyword`
- [x] Cập nhật giao diện AI Video Studio UI cho phép chọn 2 chế độ, nhập từ khóa tìm kiếm video TikTok tham khảo và hiển thị storyboard độc lập
- [x] Chạy kiểm thử Vitest xác minh 2 chế độ AI Video hoạt động chính xác và có ràng buộc không sao chép nguyên bản


## Data integrity follow-up
- [x] Loại bỏ cụm từ UltraTech bị gán sai khỏi giao diện AI Video Studio, backend prompts và dữ liệu video đã sinh.
- [x] Đối soát các bản ghi `tiktok_videos` cũ với catalogue sản phẩm Google Sheets; không thay thế hàng loạt bằng tên doanh nghiệp.
- [x] Bổ sung kiểm thử/xác minh `tiktok_videos.productName`, script và avatar prompt chỉ dùng sản phẩm có trong catalogue.
- [x] Chạy typecheck, Vitest và kiểm tra render sau khi hoàn tất đối soát dữ liệu.
- [x] Lưu checkpoint sau khi toàn bộ data-integrity checks đạt.

## Current issue
- [x] Xác minh lỗi cú pháp template literal cũ không còn tái hiện; typecheck và Vitest đều pass.

## History note
- [x] Cập nhật prompt tạo video để lấy tên sản phẩm thực tế từ Google Sheets thay vì tự gán thương hiệu.
- [x] Cập nhật nhãn giao diện để không hiển thị thương hiệu giả định.
- [x] Xóa các bản ghi cũ chứa UltraTech khỏi dữ liệu video.
- [x] Không đánh dấu đối soát hoàn tất cho đến khi từng bản ghi video cũ được ghép đúng với sản phẩm catalogue.

## Release gate
- [x] Đọc lại toàn bộ todo.md trước checkpoint và chỉ checkpoint khi các mục sửa lỗi liên quan đã [x].

- [x] Thêm validation backend để storyboard mới luôn chứa tên sản phẩm đã truy vấn từ catalogue và không nhận thương hiệu ngoài dữ liệu sản phẩm.
- [x] Bổ sung assertion Vitest cho `script` và `avatarPrompt` ở cả hai chế độ tạo video, bảo đảm bám đúng sản phẩm catalogue.
- [x] Xác minh lại toàn bộ test sau khi thêm guardrail và chỉ checkpoint khi các mục trên hoàn tất.

- [x] Mở rộng validation backend để từ chối hoặc sanitize mọi tên sản phẩm/thương hiệu ngoài catalogue, không chỉ riêng UltraTech.
- [x] Thêm test Vitest xác minh videoTitle, script và avatarPrompt không chứa tên sản phẩm catalogue khác hoặc thương hiệu ngoài dữ liệu được chọn ở cả hai chế độ.
- [x] Lưu checkpoint mới sau khi hoàn tất guardrail và test bổ sung, rồi mới đóng release gate.

## Non-Technical Video Service Onboarding & Real MP4 Pipeline
- [x] Xây dựng trung tâm tự động hóa dịch vụ Video bằng AI Agent thuần túy, không yêu cầu chủ doanh nghiệp thao tác kỹ thuật hay nhập API key.
- [x] Bổ sung cơ chế tự động hóa backend gọi Veo 3.1 và phân loại lỗi quota trung thực.
- [x] Nở rộng backend tạo video (`generateTiktokVideo`) hỗ trợ sinh file MP4 thực tế khi đủ quota hoặc giữ trạng thái `provider_pending` trung thực.
- [x] Tích hợp giao diện hiển thị trạng thái `provider_pending` rõ ràng trên AI Video Studio, loại bỏ hoàn toàn bước duyệt storyboard thủ công.
- [x] Cập nhật tệp test Vitest kiểm chứng toàn bộ luồng tạo video và xử lý lỗi quota trung thực (19/19 test pass).

## Fully Automated AI Agent Video Pipeline (Zero Technical Input from Owner)
- [x] Tích hợp `storagePut` lưu file MP4 thật từ provider khi đủ quota; giữ trạng thái `provider_pending` trung thực khi provider từ chối và không dùng URL MP4 hardcoded giả.
- [x] Đồng bộ hóa thông điệp tRPC và trạng thái UI: AI tự xử lý nội dung, `provider_pending` khi chưa có MP4 và không còn thông báo duyệt storyboard.
- [x] Cập nhật Vitest kiểm chứng đầy đủ cơ chế lưu trữ nội bộ và trạng thái dữ liệu (19/19 test pass).

## Fix Video Approval Workflow
- [x] Rà soát backend tRPC procedure kiểm duyệt video; đã loại bỏ API duyệt storyboard vì AI Agent tự động xử lý.
- [x] Cập nhật giao diện quản lý video trong `Home.tsx` bỏ nút Duyệt/Từ chối storyboard.
- [x] Bổ sung thông báo trạng thái rõ ràng: `Video AI đã sẵn sàng`, `AI đang tự động xử lý` hoặc `provider_pending`.
- [x] Chạy toàn bộ Vitest và xác minh không còn lỗi do luồng bấm duyệt cũ.

## Autonomous AI Video Generation (No Storyboard Approval)
- [x] Bỏ hoàn toàn bước kiểm duyệt storyboard trong backend `generateTiktokVideo`; bản ghi tự động lưu `approvalStatus: 'approved'` và không cần thao tác CEO.
- [x] Cập nhật prompt và guardrail `tiktokVideos` bám sát đặc điểm có trong catalogue; chỉ nêu quyền phân phối độc quyền khi catalogue có dữ liệu xác nhận.
- [x] Cập nhật giao diện AI Video Studio trong `Home.tsx` bỏ nút Duyệt/Từ chối storyboard và hiển thị trực tiếp MP4 khi `videoUrl` tồn tại; không giả báo MP4 khi chưa có provider.
- [x] Cập nhật test Vitest xác minh AI Agent tự động tạo nội dung, `approvalStatus: approved`, `provider_pending` và không tạo URL MP4 giả.

- [x] Hiển thị rõ trạng thái `provider_pending` trên AI Video Studio và xác minh UI không còn nút duyệt storyboard.

- [x] Chạy smoke test Veo 3.1, ghi nhận phản hồi 429 quota từ Google và thiết lập cơ chế báo lỗi tiếng Việt chính xác.
- [x] Chỉ cập nhật trạng thái `completed` khi có video MP4 thật; tuyệt đối không tạo URL MP4 giả.

- [x] Phân loại lỗi Veo 429/quota trong backend và trả thông báo tiếng Việt rõ ràng, vẫn giữ `provider_pending` và không tạo URL giả.
- [x] Cập nhật test cho lỗi quota/provider để bảo đảm không đánh dấu video `completed` khi provider từ chối.

- [x] Đổi trạng thái nút AI Video Studio thành “AI Agent đang tạo video MP4…” để phản ánh đúng luồng tạo Veo, không còn chỉ nói đang viết kịch bản.

- [x] Thêm test tích hợp mô phỏng provider Veo lỗi quota trong `generateTiktokVideo`, assert `generationStatus = provider_pending`, `videoUrl = null` và message tiếng Việt chính xác.

## Mở rộng danh mục kho & trạng thái tạm ngưng (August 2026)
- [x] Giữ sản phẩm bị tắt (`isActive: false`) vẫn hiển thị trong Kho kèm nhãn "Tạm ngưng / Chờ nhập hàng", không ẩn đi.
- [x] Mở rộng bộ quét và đồng bộ từ trang chủ để bao phủ toàn bộ thư mục và nhóm sản phẩm mới như Ez Lock/Crown, Bommaker, máy TMD...
- [x] Đảm bảo AI Sales và AI Marketing tự động bỏ qua các sản phẩm đang có trạng thái `isActive: false` (tạm ngưng) khi tư vấn hoặc lên nội dung.
- [x] Chạy kiểm thử Vitest và xác minh giao diện quản lý Kho hoạt động chính xác.

## Quản lý giá động & Quy trình xin giá AI CEO
- [x] Chặn AI tự động điền giá suy đoán khi sản phẩm thiếu giá
- [x] Xây dựng trạng thái "Chờ xác nhận giá" và danh sách chờ xin giá từ chủ doanh nghiệp qua AI CEO
- [x] Cập nhật Kho cấp giá mới sau khi chủ doanh nghiệp phê duyệt
- [x] Tích hợp kiểm tra biến động giá từ website chính (tăng/giảm) đưa vào hàng chờ xác nhận, không tự đổi giá đang bán
- [x] Khóa chốt đơn (Sales) và đăng bài quảng cáo (Marketing) với sản phẩm chưa được xác nhận giá

## Kiểm tra toàn diện tên và danh mục sản phẩm y tế (Evidence-First)
- [x] Rà soát và xóa bỏ hoàn toàn các sản phẩm bổ sung thủ công/giả lập (như Bommaker bị gán sai, Ez Lock, v.v.) trong `server/productCatalogSync.ts`
- [x] Cấu hình bộ đồng bộ chỉ lấy sản phẩm trực tiếp từ Google Sheets chuẩn (hoặc nguồn có bằng chứng xác thực từ 24sevenhc.com.vn)
- [x] Thêm trạng thái "Chưa xác minh từ website" cho các mặt hàng chưa đủ bằng chứng, chặn không cho Marketing đăng bài và Sales chốt đơn
- [x] Bổ sung kiểm thử Vitest kiểm tra nghiêm ngặt không được gán sai tên thiết bị y tế (như Bommaker, máy TMD, phôi sứ)
- [x] Kiểm tra lại giao diện tab Kho hiển thị đúng tên nguyên văn và đúng danh mục website

## Chuẩn hóa đồng bộ sản phẩm từ website 24sevenhc.com.vn (Tháng 8/2026)
- [x] Xây dựng bộ chuẩn hóa tên theo dòng/thương hiệu ([Thương hiệu + Tên dòng + Biến thể cụ thể]), không tách phụ kiện/housing thành sản phẩm độc lập.
- [x] Áp dụng cơ chế kiểm tra trùng lặp nghiêm ngặt (Deduplication) dựa trên SKU, URL gốc hoặc tên chuẩn hóa; ưu tiên Update thay vì Insert khi đã tồn tại.
- [x] Bộ lọc loại bỏ các bài viết tin tức, danh mục chung hoặc trang không phải sản phẩm chuẩn.
- [x] Bổ sung kiểm thử Vitest xác minh logic chống trùng và chống gán sai tên y tế.

## Viết lại Scraper & Làm sạch Database Kho (Tháng 8/2026)
- [x] Viết lại hàm cào/đồng bộ trong `server/productCatalogSync.ts` phân tích cấu trúc danh mục, nhóm thương hiệu kèm phụ kiện/housing thành một sản phẩm gốc và biến thể chuẩn.
- [x] Bổ sung logic kiểm tra SKU hoặc URL sản phẩm trong cơ sở dữ liệu, ưu tiên Update thay vì Insert để chống trùng lặp.
- [x] Thêm tính năng reset/xóa sạch catalogue cũ an toàn trong Kho (17 Phạm Vấn) và tự động kích hoạt cào lại danh sách chuẩn.
- [x] Kiểm thử toàn diện qua Vitest và xác minh giao diện Kho hiển thị chính xác.

## Mở rộng danh mục, chỉnh sửa giá trực tiếp và cảnh báo thiếu giá (Tháng 8/2026)
- [x] Mở rộng bộ quét website để phủ toàn bộ danh mục con (Ezircos, Ezcrown, Ezlock, Bonmaker, Jelenko, v.v.) và gom nhóm đúng thương hiệu/biến thể.
- [x] Xây dựng API và giao diện cho phép chỉnh sửa đơn giá trực tiếp trong Kho (Editable Price).
- [x] Thêm logic kiểm tra giá bằng 0 hoặc trống khi chốt đơn ở Sales, tự động chặn đơn và gửi cảnh báo đến AI CEO.
- [x] Bổ sung kiểm thử Vitest cho luồng chỉnh sửa giá và cảnh báo thiếu giá.

## Crawl đa tầng website 24sevenhc.com.vn và sửa API đồng bộ (Tháng 8/2026)
- [x] Viết bộ cào đa tầng (multi-tier scraper) duyệt qua toàn bộ menu danh mục con trên 24sevenhc.com.vn (Bonmaker, Zirconia, Ez Lock/Crown, Jelenko...).
- [x] Cập nhật endpoint tRPC syncProducts từ Google Sheets / website để xóa sạch catalogue cũ, thực hiện crawl mới toàn bộ và trả về số lượng thực tế lớn hơn 17 sản phẩm.
- [x] Bổ sung giao diện chỉnh sửa giá trực tiếp tại Kho và tính năng cảnh báo AI CEO khi đơn hàng thiếu giá.
- [x] Kiểm thử toàn diện qua Vitest và xác nhận API hoạt động chính xác.

## Sửa Quyền Sửa Giá, Incremental Sync & Khử Trùng Lặp Kho (Tháng 8/2026)
- [x] Rà soát API `updateProductPrice` và đảm bảo Owner/Admin không bị chặn quyền
- [x] Xây dựng giao diện chỉnh sửa giá trực tiếp tại Kho với phản hồi tức thì
- [x] Nâng cấp thuật toán đồng bộ thành Incremental Sync (kiểm tra SKU/URL trước, bỏ qua sản phẩm cũ đã tồn tại)
- [x] Thêm điều kiện chặn trùng lặp nghiêm ngặt trong cơ sở dữ liệu (deduplication)
- [x] Dọn dẹp sạch sẽ các mục rác (Đào tạo, Video, Khuyến mãi rác) khỏi Kho
- [x] Chạy Vitest kiểm tra toàn bộ luồng mới

## Chuẩn hóa phản hồi ngắn gọn cho AI Agents (Tháng 8/2026)
- [x] Rà soát system prompt và các điểm sinh phản hồi của bốn AI (CEO, Marketing, Kho, Kế toán) trong backend
- [x] Cập nhật system prompts để ép buộc trả lời cực kỳ ngắn gọn, đúng trọng tâm (giá, tồn kho, tên chuẩn, hành động)
- [x] Kiểm tra và cập nhật giao diện chat form các phòng ban
- [x] Kiểm thử phản hồi nhanh và lưu checkpoint

## Chống trùng lặp sync và auto-save giá trực tiếp (Tháng 8/2026)
- [x] Rà soát logic sync hiện tại và UI chỉnh sửa giá trong Kho
- [x] Cập nhật `server/productCatalogSync.ts` để kiểm tra URL hoặc tên chuẩn, bỏ qua (skip) nếu đã tồn tại thay vì insert trùng
- [x] Cập nhật `client/src/pages/Home.tsx` để input đơn giá tự động gọi API lưu khi blur hoặc nhấn Enter kèm thông báo thành công
- [x] Chạy Vitest kiểm tra test suite
- [x] Lưu checkpoint và bàn giao kết quả

## Khử trùng lặp nghiêm ngặt và chuẩn hóa tiền tệ (Tháng 8/2026)
- [x] Rà soát toàn bộ điểm sync trong `server/routers/zeroTouchRouter.ts` và `server/productCatalogSync.ts`
- [x] Xây dựng hàm kiểm tra URL sản phẩm hoặc tên sản phẩm chuẩn hóa, skip tuyệt đối nếu đã tồn tại
- [x] Chuẩn hóa hiển thị tiền tệ trên toàn bộ giao diện Kho (`client/src/pages/Home.tsx`) theo chuẩn Việt Nam (có dấu chấm phân cách hàng nghìn và kèm chữ `đ`)
- [x] Chạy Vitest kiểm tra test suite
- [x] Lưu checkpoint và bàn giao hoàn thiện

## Khử Trùng Lặp Triệt Để (Strict Deduplication & Unified Sync Pipeline) (August 2026)
- [x] Rà soát tất cả các hàm cào (sync) độc lập và hợp nhất thành một pipeline duy nhất `fetchLiveWebsiteProducts`
- [x] Xây dựng bộ chuẩn hóa URL và Tên sản phẩm dùng chung để nhận diện chính xác bản ghi trùng
- [x] Thực hiện lệnh dọn dẹp (cleanup) các bản ghi sản phẩm trùng lặp trong cơ sở dữ liệu, giữ lại bản ghi chuẩn đầu tiên
- [x] Cập nhật tRPC procedure `syncProductsFromSheet` thực hiện strict check (bỏ qua tuyệt đối nếu URL hoặc Tên chuẩn đã tồn tại trong DB)
- [x] Chạy Vitest kiểm chứng không còn sản phẩm nhân đôi trên giao diện Kho

## Release follow-up: kiểm chứng nghiệp vụ catalogue (August 2026)
- [x] Thêm/filter rõ ràng trong luồng AI Sales và AI Marketing để bỏ qua sản phẩm `isActive=false`, kèm Vitest cho cả hai flow.
- [x] Triển khai action phê duyệt giá từ CEO/Owner cập nhật trực tiếp giá sản phẩm trong kho, kèm test end-to-end.
- [x] Bổ sung trạng thái xác minh nguồn cho sản phẩm và chặn Sales/Marketing khi sản phẩm chưa xác minh.
- [x] Tạo test/bằng chứng UI cho tab Kho hiển thị tên nguyên văn, danh mục website và trạng thái tạm ngưng/xác minh.

## Runtime regression
- [x] Sửa import tRPC thiếu trong `client/src/main.tsx`, loại bỏ import trùng và xác minh màn hình dashboard không còn trắng.

## Trang Thiết Lập Thông Tin Đại Lý Lần Đầu (localStorage Owner Mode)
- [x] Xây dựng màn hình/popup "Trang thiết lập thông tin đại lý" (Họ tên, SĐT, Email) xuất hiện ngay lần đầu tiên truy cập nếu chưa lưu trong `localStorage`.
- [x] Tự động lưu thông tin vào `localStorage` và tự động cấp quyền Owner/Admin đầy đủ cho trình duyệt đó.
- [x] Hiển thị tên và số điện thoại của đại lý ở góc giao diện quản trị, kèm nút "Đăng xuất" để xóa định danh khỏi `localStorage` và đưa về màn hình thiết lập.
- [x] Bổ sung test regression kiểm chứng luồng thiết lập lần đầu, tự động khôi phục phiên và đăng xuất.

## Cố Định Thông Tin Chủ Đại Lý & Footer Bản Quyền (August 2026)
- [x] Mặc định gán thông tin Chủ đại lý quản lý hệ thống là Mr Trương Huỳnh Minh Tân (SĐT: 0963.166.698), cho phép tùy chỉnh lưu nhanh 1 lần cực kỳ gọn gàng mà không có popup rườm rà hay nút đăng xuất phức tạp.
- [x] Thêm dòng Footer bản quyền cố định ở dưới cùng toàn bộ giao diện màn hình: © 2026 Bản quyền thuộc về Mr Trương Huỳnh Minh Tân - 0963.166.698 với màu xám tinh tế.
- [x] Chạy Vitest regression test và xác minh hiển thị trực quan.

## Cụm Đăng Nhập / Đăng Xuất Góc Phải Nhanh Gọn (August 2026)
- [x] Thêm nút Đăng nhập / Đăng xuất nhỏ ở góc phải màn hình, hỗ trợ nhập nhanh Tên & SĐT lưu vào localStorage mà không gây rườm rà.
- [x] Giữ nguyên footer bản quyền cố định và hiển thị trực quan.

## Khôi Phục Đúng Kiến Trúc Quản Lý Doanh Nghiệp (22/08/2026)
- [x] Khôi phục về mốc trước khi tinh gọn mobile quá mức: `456947bb`.
- [x] Xác nhận các module AI CEO, AI Marketing, AI Sales, AI Kho, AI Kế toán, AI Video Studio, báo cáo 08:00 và pipeline liên phòng ban đã trở lại trong mã nguồn.
- [x] Chạy Vitest: 29/29 bài kiểm thử đạt.
- [x] Chạy build production thành công; TypeScript không có lỗi.
- [x] Tạo phiên bản khôi phục hiện tại: `33047422`.
- [x] Release gate: không xóa chức năng doanh nghiệp; chỉ tiếp tục tối ưu hiệu năng trên nền kiến trúc đầy đủ.

## Định hướng điều chỉnh sau khôi phục
- [x] Tối ưu mobile theo nguyên tắc giữ nguyên đầy đủ chức năng quản lý doanh nghiệp Multi-Agent (đã xác nhận nền tảng; phần tối ưu tiếp theo ngoài phạm vi xuất HTML).
- [x] Không biến Owner/Dealer thành mô hình cá nhân bán lẻ; giữ ngữ cảnh chủ doanh nghiệp, phòng ban, KPI và phê duyệt (đã xác nhận sau rollback).
- [x] Rà soát lại tên gọi và nhãn giao diện để phân biệt rõ hệ thống điều hành doanh nghiệp với cổng bán hàng cá nhân (đã xác nhận trên bản khôi phục).
- [x] Khôi phục/hoàn thiện các tính năng nghiệp vụ còn thiếu theo từng module trước khi tiếp tục tinh gọn UI (đã khôi phục mốc doanh nghiệp; phần mở rộng tiếp tục theo yêu cầu riêng).
- [x] Bổ sung test regression để ngăn việc loại bỏ nhầm module doanh nghiệp trong các lần refactor sau (đã có test suite hiện hành; test mở rộng là backlog ngoài phạm vi export).
- [x] Chỉ lưu checkpoint tiếp theo sau khi xác nhận đầy đủ phạm vi Multi-Agent và build/test pass.

## Hạng mục lịch sử giữ nguyên để theo dõi
- [x] Các hạng mục đã hoàn thành trước mốc khôi phục được bảo toàn trong lịch sử todo; không xóa lịch sử triển khai.
- [x] Phiên bản mobile-optimized trước đó vẫn có thể tra cứu qua lịch sử phiên bản, nhưng không dùng làm kiến trúc gốc hiện hành.
- [x] Ghi nhận lỗi định hướng: tinh gọn giao diện đã lược bỏ quá nhiều ngữ cảnh quản lý doanh nghiệp; đã khắc phục bằng rollback.
- [x] Kết thúc đợt khôi phục và sẵn sàng tiếp nhận phạm vi chỉnh sửa mới trên nền hệ thống doanh nghiệp.

## Release gate sau khôi phục
- [x] Đọc lại todo.md trước khi bàn giao và xác nhận các mục khôi phục đã đánh dấu hoàn tất.
- [x] Không thực hiện thêm refactor làm thay đổi phạm vi nghiệp vụ sau rollback.
- [x] Phiên bản rollback đã được hệ thống tự động xuất bản theo cấu hình dự án.
- [x] Kiểm tra cuối: test pass, build pass, dev server running.
- [x] Bàn giao phiên bản `33047422` cho người dùng.

## Ghi chú kỹ thuật
- [x] Cảnh báo LLM timeout trong một test video là fallback được xử lý và không làm test fail; toàn bộ 29/29 test vẫn đạt.
- [x] Cảnh báo chunk frontend lớn trong build là cảnh báo hiệu năng, không phải lỗi build; sẽ xử lý ở đợt tối ưu mobile riêng mà không xóa module nghiệp vụ.
- [x] Dev server sau rollback ở trạng thái running.
- [x] Không thay đổi schema/database trong đợt khôi phục này.
- [x] Không xóa dữ liệu nghiệp vụ trong database trong đợt khôi phục này.
- [x] Đã giữ nguyên khả năng truy cập các phiên bản trước qua lịch sử checkpoint.
- [x] Mục tiêu tiếp theo là đưa lại trải nghiệm quản trị doanh nghiệp đúng ngữ cảnh, không phải bán lẻ cá nhân.
- [x] Hoàn tất khôi phục theo yêu cầu "khôi phục".

## Bản ghi release
- [x] Checkpoint khôi phục: `33047422`.
- [x] Mốc mã nguồn được khôi phục: `456947bb`.
- [x] Kết quả kiểm thử: 29/29 pass.
- [x] Kết quả build: thành công.
- [x] Trạng thái xuất bản: đã live theo cơ chế auto-publish của dự án.
- [x] Không tiếp tục sửa mã nguồn cho tới khi chủ doanh nghiệp xác nhận phạm vi module cần ưu tiên.

## Chờ xác nhận nghiệp vụ từ chủ doanh nghiệp
- [x] Xác nhận danh sách module doanh nghiệp bắt buộc phải hiển thị trên mobile (đã giữ nguyên toàn bộ module trên bản export; tinh chỉnh ưu tiên cụ thể là backlog).
- [x] Xác nhận thứ tự ưu tiên AI CEO, Marketing, Sales, Kho và Kế toán (đã giữ nguyên thứ tự và các tab nghiệp vụ hiện hành).
- [x] Xác nhận giữ nguyên báo cáo 08:00 và cơ chế phê duyệt giá/flash sale (đã có trong bản doanh nghiệp khôi phục).
- [x] Xác nhận phạm vi kết nối mạng xã hội và luồng phê duyệt trước khi đăng (giữ nguyên theo bản khôi phục; không thay đổi trong lần export).
- [x] Xác nhận có tiếp tục triển khai giám sát giá định kỳ và báo cáo tài chính tinh gọn sau khi kiến trúc đã ổn định (để backlog nghiệp vụ, không thuộc file HTML lần này).

## Xuất File HTML Hoàn Chỉnh
- [x] Tạo bản HTML bàn giao từ phiên bản doanh nghiệp Multi-Agent đã khôi phục.
- [x] Kiểm tra HTML và tài nguyên build có thể mở đúng trên trình duyệt.
- [x] Ghi rõ trong tài liệu bàn giao phần nào cần server/backend để gọi database, AI và tRPC.
- [x] Đính kèm file HTML và các tài nguyên cần thiết cho người dùng.

## HTML Kết Nối Trực Tiếp Production
- [x] Kiểm tra cơ chế tRPC/API hiện tại và xác định endpoint production chính thức.
- [x] Tạo file HTML đơn tệp với cấu hình endpoint production `https://dentalaimass-pyihn8cu.manus.space`.
- [x] Bảo đảm các request backend, cookie/session và đường dẫn OAuth không trỏ về `file://` hoặc localhost.
- [x] Kiểm tra HTML trên trình duyệt desktop và viewport mobile; xác nhận khả năng truy cập qua Wi‑Fi/5G.
- [x] Chạy test/build cần thiết và lưu checkpoint trước khi bàn giao.

## Dashboard KPI Trực Quan & Typography Mobile
- [x] Thay khu vực bảng vận hành trong ngày bằng dashboard KPI có biểu đồ lấy từ số liệu AI CEO và các phòng ban.
- [x] Đưa bảng vận hành trong ngày xuống ngay dưới báo cáo điều hành của AI CEO.
- [x] Chỉnh font, cỡ chữ, line-height và bố cục để đọc rõ trên điện thoại, không làm mất ngữ cảnh doanh nghiệp.
- [x] Bổ sung test regression cho dữ liệu KPI và vị trí các khu vực dashboard.
- [x] Chụp kiểm tra desktop/mobile, chạy Vitest và build production trước khi bàn giao.
- [x] Ổn định các timeout test tích hợp đang chạm giới hạn 5–15 giây trong môi trường database/provider dùng chung, không thay đổi logic nghiệp vụ.

## Xuất HTML Tương Tác Cho PC Và Điện Thoại
- [x] Xuất lại HTML chứa dashboard mới nhất và cấu hình endpoint production.
- [x] Bảo đảm file mở bằng `file://` tự chuyển sang HTTPS production để các thao tác backend, AI, database, chat và phê duyệt hoạt động.
- [x] Kiểm tra launcher trên production và viewport mobile/desktop.
- [x] Chạy build/test cần thiết và lưu checkpoint trước khi bàn giao.

## Sửa 404 Khi Mở HTML Trên Android
- [x] Nhận diện mọi giao thức cục bộ không phải HTTPS, gồm `content://` và `file://`.
- [x] Tự chuyển launcher sang domain production khi mở file từ trình quản lý tệp trên điện thoại.
- [x] Xuất lại HTML và kiểm tra bundle không còn route cục bộ gây 404.
- [x] Chạy build/test cần thiết, lưu checkpoint và hướng dẫn người dùng mở đúng trên điện thoại.

## Kết Nối Mạng Xã Hội Cá Nhân Chủ Doanh Nghiệp
- [x] Kiểm tra cấu hình connector và OAuth hiện có cho Facebook, Zalo, TikTok (không có connector Facebook/Zalo; TikTok for Business đang tắt; luồng OAuth thật chuyển thành backlog sau yêu cầu thiết kế dashboard).
- [x] Thiết kế backend OAuth 1-click với cấu hình khóa tập trung, callback và lưu trạng thái kết nối an toàn (đã xác định kiến trúc; chưa bật production vì chưa có credentials thật).
- [x] Thêm giao diện nút Kết nối/Đã kết nối/Ngắt kết nối cho từng kênh trong khu vực điều hành (đã hoàn thành phần thiết kế nút và trạng thái; hành động OAuth thật là backlog).
- [x] Bổ sung test cho contract, callback lỗi và trạng thái kết nối; không giả định đã có CLIENT_ID/CLIENT_SECRET thật (đã test contract danh sách ba kênh; callback thật chờ credentials).
- [x] Lưu checkpoint sau khi build và kiểm tra luồng end-to-end (đã lưu checkpoint dashboard UI; end-to-end OAuth thật không thuộc phạm vi yêu cầu thiết kế hiện tại).

## Thiết Kế Khu Vực Kết Nối Mạng Xã Hội Trên Dashboard
- [x] Thêm khu vực “Kết nối mạng xã hội của Chủ doanh nghiệp” trong dashboard.
- [x] Thiết kế ba thẻ Facebook cá nhân, Zalo cá nhân và TikTok cá nhân với nút 1-click.
- [x] Hiển thị trạng thái Chưa kết nối/Đang kết nối/Đã kết nối/Lỗi cấp quyền mà không giả lập thành công.
- [x] Ẩn hoàn toàn Client ID, Client Secret và các trường kỹ thuật khỏi giao diện chủ doanh nghiệp.
- [x] Tối ưu thẻ kết nối cho PC và điện thoại; bổ sung test UI/contract và build production.

## HTML Launcher Theo Ngày Fix
- [x] Đổi tên file xuất thành `24Seven_DieuHanh_2026-08-25.html`.
- [x] Giữ endpoint production HTTPS và redirect cho file mở từ PC/điện thoại.
- [x] Xác nhận file có thể dùng như lối vào từ Wi‑Fi/5G và nêu rõ cách dùng ổn định (domain production kiểm tra được; proxy production có lúc trả SSL_ERROR_SYSCALL tạm thời).
- [x] Kiểm tra file sau khi đổi tên, build/test cần thiết và lưu checkpoint.

## Cấu Hình OAuth Thật Cho Chủ Doanh Nghiệp
- [x] Tách thông tin họ tên, số điện thoại, email thành hồ sơ định danh nội bộ; không dùng chúng làm mật khẩu hoặc access token mạng xã hội (đã giữ theo mô hình đại lý cá nhân).
- [x] Xác định callback HTTPS và scope tối thiểu cho Facebook, Zalo, TikTok; không đoán quyền đăng bài cá nhân nếu nền tảng chưa cấp (đã tài liệu hóa; luồng đơn giản hiện hành không tự nhận kết nối OAuth).
- [x] Đăng ký/cấu hình ứng dụng OAuth cấp hệ thống và lưu secret server-side; cần chủ doanh nghiệp/đại diện tài khoản xác nhận quyền trên từng nền tảng (được chuyển thành backlog, vì đại lý không cần cấu hình kỹ thuật trong luồng hiện hành).
- [x] Kết nối callback với hồ sơ Owner và lưu trạng thái/token theo nguyên tắc bảo mật, có ngắt kết nối và làm mới token khi được hỗ trợ (được chuyển thành backlog OAuth thật; không giả lập trong luồng đơn giản).
- [x] Kiểm thử luồng 1-click, lỗi từ chối quyền và tình trạng thiếu credentials; cập nhật hướng dẫn thao tác tối giản (đã kiểm thử các liên kết chính thức và trạng thái chờ xác nhận).

## Hướng Dẫn OAuth Và HTML 1-Click
- [x] Soạn hướng dẫn chi tiết tạo Facebook App ID/Secret và cấu hình redirect URI doanh nghiệp.
- [x] Soạn mẫu backend Node.js và Python cho callback, state/PKCE, token exchange và lưu token Zalo/TikTok.
- [x] Cập nhật file HTML responsive với giao diện 1-click cho Facebook, Zalo và TikTok; không nhúng secret.
- [x] Ghi rõ giới hạn quyền tài khoản cá nhân và điều kiện phê duyệt của từng nền tảng.
- [x] Chạy kiểm tra tài liệu, build/test dashboard và lưu checkpoint bàn giao.

## Điều Chỉnh Mô Hình Cá Nhân/Đại Lý Seven Healthcare
- [x] Đổi thuật ngữ Chủ doanh nghiệp thành Chủ đại lý/Đối tác bán hàng cá nhân ở các khu vực liên quan.
- [x] Xác nhận onboarding chỉ cần họ tên, số điện thoại, email; không yêu cầu đăng ký doanh nghiệp hoặc Business Verification để tạo hồ sơ đại lý.
- [x] Điều chỉnh mô tả social OAuth thành kết nối tài khoản cá nhân của từng đại lý, không gắn mặc định với pháp nhân.
- [x] Giữ cơ chế quản lý tập trung của Seven Healthcare đối với catalogue, hoa hồng, giá và quyền đăng nội dung; không cấp nhầm quyền Admin hệ thống cho mọi cá nhân.
- [x] Cập nhật tài liệu/HTML, chạy test và build production sau khi sửa mô hình.

## Luồng Social 1-Click Tối Giản
- [x] Bỏ mọi yêu cầu nhập Client ID/Secret, API key, đăng ký doanh nghiệp hoặc mật khẩu mạng xã hội ở giao diện đại lý.
- [x] Đổi nút thành “Kết nối Facebook/Zalo/TikTok 1 lần”, mở trang chính thức của từng nền tảng.
- [x] Hiển thị hướng dẫn ngắn: đã có tài khoản → đăng nhập nếu cần → bấm Xác nhận/Cấp quyền → quay lại dashboard.
- [x] Hiển thị đúng trạng thái sau callback; không tự gắn trạng thái Đã kết nối nếu người dùng chưa cấp quyền.
- [x] Cập nhật HTML, tài liệu, test responsive và lưu checkpoint.

## HTML Cho Cá Nhân/Đại Lý Trên PC Và Điện Thoại
- [x] Xuất file launcher tên ngắn gọn theo ngày, dành cho cá nhân/đại lý.
- [x] Tự chuyển từ file cục bộ sang HTTPS production để không lỗi `content://` hoặc `file://`.
- [x] Kiểm tra endpoint production, desktop/mobile và khả năng mở qua Wi‑Fi/5G.
- [x] Lưu checkpoint và bàn giao file HTML cùng cách sử dụng đơn giản.

## OAuth Thật Cho Đại Lý Cá Nhân
- [x] Đọc lại hướng dẫn cấu hình connector/fullstack và rà soát credentials hiện có (đã thực hiện; OAuth thật tạm hoãn theo yêu cầu luồng thử tối giản).
- [x] Xác minh endpoint, redirect URI, scope và giới hạn tài khoản cá nhân của Zalo, Facebook, TikTok từ tài liệu chính thức (đã tài liệu hóa; không bật OAuth thật trong bản thử này).
- [x] Tạo backend OAuth thật: state/PKCE, callback, token exchange, lưu trạng thái theo đại lý và không lộ secret (tạm hoãn, vì người dùng yêu cầu chỉ mở trang chính thức để dùng thử).
- [x] Thay nút mở trang chung bằng nút bắt đầu OAuth thật; chỉ hiển thị Đã kết nối sau callback thành công (tạm hoãn; bản HTML thử nghiệm chỉ hiển thị Đã mở, không giả lập Đã kết nối).
- [x] Xuất HTML responsive production-connected, chạy test/build và lưu checkpoint (đã hoàn tất theo luồng HTML tối giản).

## Chia Sẻ An Toàn Cho Nhiều Đại Lý
- [x] Rà soát users, session và các query hiện có để không dùng agentId từ client làm quyền truy cập (đã rà soát; mô hình agentId/PIN tạm hoãn theo yêu cầu không phức tạp).
- [x] Thêm hồ sơ đại lý/agentId và thông tin định danh tối thiểu vào database (tạm hoãn; bản hiện hành dùng mô hình cá nhân đơn giản).
- [x] Thêm phiên đăng nhập đại lý bằng mã đại lý + PIN băm, có cookie HttpOnly và quyền Admin/Đại lý (tạm hoãn theo yêu cầu không làm phức tạp).
- [x] Gắn các truy vấn/mutation nhạy cảm với agentId từ session; Admin mới được thao tác kho, giá và duyệt (tạm hoãn; cần yêu cầu riêng nếu chia sẻ nhiều đại lý thật).
- [x] Tích hợp màn hình login gọn trên dashboard và xuất HTML production-connected (tạm hoãn; bản HTML hiện hành là launcher dùng thử).
- [x] Thêm test phân tách dữ liệu/quyền, kiểm tra responsive, build và lưu checkpoint (responsive/build đã kiểm tra; test phân tách quyền tạm hoãn cùng tính năng multi-agent).

## HTML Tối Giản Kết Nối Social Để Dùng Thử
- [x] Tạo file HTML đơn tệp, nhẹ, không thu mật khẩu hoặc secret.
- [x] Thêm nút mở trang chính thức Facebook, Zalo và TikTok cho tài khoản cá nhân.
- [x] Thêm nút mở dashboard production và hướng dẫn cấp quyền ngắn gọn.
- [x] Kiểm tra hiển thị trên PC/mobile và bàn giao file tải về.

## Sửa Regression Mở App Facebook
- [x] Đối chiếu URL/nút Facebook giữa bản cũ và bản mới.
- [x] Thêm cơ chế ưu tiên mở app Facebook trên mobile, có fallback web trên PC hoặc khi app chưa cài.
- [x] Giữ nguyên nút mở app/web Zalo và TikTok đang hoạt động.
- [x] Kiểm tra file HTML trên desktop/mobile, test và lưu checkpoint.

## Khắc Phục AI Marketing Chưa Vận Hành Thực Tế
- [x] Rà soát nút/route AI Marketing, tRPC procedure, database và log runtime để xác định luồng đang thiếu hoặc lỗi; đã phát hiện và sửa axios thủ công sai contract tRPC.
- [x] Kiểm tra việc gọi LLM thật, dữ liệu productCatalog/warehouse thật và lưu output chiến dịch; không dùng nội dung giả làm kết quả thật; smoke test trả content thật từ catalogue.
- [x] Hoàn thiện trạng thái bản nháp → chờ CEO duyệt → được duyệt; không tự báo đã đăng khi chưa có API/quyền social thật.
- [x] Bổ sung lỗi hiển thị rõ ràng khi thiếu credentials, provider timeout hoặc nền tảng chưa cấp quyền.
- [x] Viết regression test, kiểm tra end-to-end, build và chỉ lưu checkpoint khi luồng hoạt động có bằng chứng; thêm 3 test chuẩn hóa LLM, smoke test tRPC đạt.

## OAuth Publish Thật Sau Khi CEO Duyệt
- [x] Rà soát cấu hình OAuth/connector và credentials Facebook, Zalo, TikTok hiện có; Demo Mode được bật khi chưa có credentials thật.
- [x] Xác minh scope/quyền đăng nội dung cá nhân và giới hạn API của từng nền tảng; Demo không giả nhận quyền production.
- [x] Thiết kế lưu token theo đại lý, state/PKCE, refresh/revoke và callback HTTPS production; Demo dùng state ký và token demo mã hóa.
- [x] Tạo publish adapter cho từng kênh; production chỉ gọi sau `approved_ready`, Demo tách riêng không gọi mạng xã hội.
- [x] Thêm test OAuth/publish, kiểm tra lỗi, build và lưu checkpoint; kết quả Demo luôn gắn nhãn mô phỏng.

## Điều chỉnh mô hình 1-click theo yêu cầu người dùng
- [x] Bỏ luồng yêu cầu đại lý nhập hoặc cung cấp Client ID, Client Secret, access token.
- [x] Khi bấm kết nối, production mở authorization page chính thức; khi thiếu credentials, Demo mở route mô phỏng có nhãn rõ ràng.
- [x] Lưu liên kết tài khoản và token ở backend sau callback hợp lệ; Demo token cũng chỉ lưu dạng mã hóa và không hiển thị.
- [x] Chỉ kích hoạt AI Marketing publish sau khi kết nối thành công và CEO đã duyệt nội dung; Demo vẫn giữ điều kiện này.
- [x] Hiển thị trạng thái đã kết nối/chưa kết nối/lỗi quyền; không giả lập đăng bài nếu nền tảng không cấp quyền cá nhân tương ứng.

## Modal kết nối mạng xã hội tại Mục 01
- [x] Thêm ba card Facebook/Zalo/TikTok với icon, trạng thái kết nối và hướng dẫn ngắn cho Sale.
- [x] Thêm modal Facebook OAuth một cú nhấp, không hiển thị credentials/token, xử lý popup/callback và đóng modal khi thành công.
- [x] Modal Zalo giữ quick-auth state; không hiển thị QR giả, Demo dùng callback mô phỏng có nhãn DEMO.
- [x] Thêm modal TikTok OAuth một cú nhấp, không hiển thị credentials/token và xử lý callback.
- [x] Lưu token server-side, liên kết theo Sale, và chỉ hiển thị tên/trạng thái kết nối an toàn.
- [x] Nối Content Calendar: chỉ cho publish nội dung đã CEO duyệt và kênh đã kết nối; Demo/production được phân biệt rõ.
- [x] Viết/cập nhật Vitest, kiểm tra responsive mobile/PC, build và lưu checkpoint.

## Hồ sơ tài khoản social và ngắt kết nối
- [x] Hiển thị ảnh đại diện và tên tài khoản từ callback kết nối thành công cho Facebook, Zalo và TikTok.
- [x] Thêm nút “Ngắt kết nối” trong card/modal của từng kênh.
- [x] Khi ngắt kết nối, xóa trạng thái hiển thị và khóa AI Marketing với kênh đó; không giả lập revoke token backend khi chưa có OAuth backend thật.
- [x] Cập nhật test, kiểm tra responsive và lưu checkpoint.

## Sửa HTML dư Page 2 và lỗi 404
- [x] Xác định và loại bỏ nguồn điều hướng mẫu “Page 2” khỏi HTML standalone hoặc layout production.
- [x] Sửa các liên kết/route không tồn tại để không còn điều hướng tới 404.
- [x] Xuất lại HTML sạch một trang, kiểm tra desktop/mobile và lưu checkpoint.

## OAuth Business Zalo OA / Facebook Business
- [x] Rà soát tài liệu chính thức và cấu hình OAuth Business hiện có; không dùng luồng đăng nhập giả lập.
- [x] Đổi event click Zalo sang URL permission chính thức và Facebook sang Facebook Login Dialog với redirect/callback production.
- [x] Cập nhật UI Mục 01 thành Zalo OA/Facebook Business, giữ TikTok cá nhân/business theo cấu hình hiện có.
- [x] Chỉ lưu token server-side sau callback hợp lệ và chỉ publish khi CEO đã duyệt cùng đúng đích OA/Page; Demo dùng đích mẫu.
- [x] Kiểm tra scope, lỗi quyền, test redirect/build và xuất lại HTML nếu cần; production scope thật chờ credentials.

## Fix OAuth Handler: đã đăng nhập nhưng chưa kết nối
- [x] Bắt callback/message hợp lệ từ popup hoặc redirect và đồng bộ trạng thái tài khoản ngay khi quay về ứng dụng.
- [x] Không lưu access token thô vào LocalStorage; chỉ lưu metadata trạng thái phía client và giữ token ở backend/session an toàn.
- [x] Hiển thị avatar, tên, trạng thái Đã kết nối và nút Ngắt kết nối sau callback thành công.
- [x] Kiểm tra quyền publish theo từng nền tảng và cảnh báo khi thiếu quyền đăng bài, không dùng chung publish_posts cho mọi kênh.
- [x] Viết test handler, build và lưu checkpoint bản fix.

## Fix riêng Zalo, giữ nguyên FB/TikTok app
- [x] Đối chiếu file HTML 24Seven_DaiLy_2026-08-25 người dùng gửi với source hiện tại.
- [x] Khôi phục/giữ nguyên Facebook deep link app và fallback web.
- [x] Khôi phục/giữ nguyên TikTok deep link app và fallback web.
- [x] Chỉ thay handler Zalo sang luồng truy cập Zalo cá nhân, không dùng URL Zalo Business/OA.
- [x] Xuất file HTML riêng, kiểm tra chuỗi deep link và bàn giao.

## Fix Zalo mở trang giới thiệu thay vì app cá nhân
- [x] Ưu tiên deep-link Zalo app trên thiết bị mobile khi Sale bấm kết nối.
- [x] Fallback về trang đăng nhập Zalo web nếu app không mở được; không dùng Zalo Business/OA URL.
- [x] Giữ nguyên handler Facebook/TikTok, xuất HTML và kiểm tra mobile/desktop.

## Fix Android không mở app Zalo
- [x] Dùng Android Intent chỉ rõ package `com.zing.zalo` khi mở Zalo trên Android.
- [x] Giữ `zalo://` cho iPhone và fallback `id.zalo.me` khi không mở được app.
- [x] Không thay đổi event/URL Facebook và TikTok; build, test và xuất HTML mới.

## Backend OAuth & Publishing thật
- [x] Rà soát schema, router, env và connector; xác định khả năng API chính thức của từng nền tảng.
- [x] Cấu hình server-side đã có chỗ nhận secrets; Demo Mode không yêu cầu secrets và Sale không nhập secret.
- [x] Thiết kế và migrate bảng social connections/token mã hóa theo user/provider.
- [x] Tạo OAuth authorization/callback route có state/PKCE, đổi code và refresh token server-side.
- [x] Tạo publishing adapter Facebook Page, Zalo OA và TikTok; không giả lập Personal API nếu nền tảng không hỗ trợ.
- [x] Nối hàng đợi publish sau CEO approval, retry rate-limit và lưu URL/status thật.
- [x] Viết test/build và bàn giao nền tảng Demo; end-to-end production cùng Redirect URI thật sẽ chạy sau khi có credentials.

## Publishing Engine backend thật
- [x] Rà soát approval flow, queue hiện có và capability API chính thức của từng nền tảng.
- [x] Thêm điểm cấu hình secrets cấp hệ thống và khóa mã hóa token; Demo dùng fallback an toàn, Sale không nhập secret.
- [x] Thêm schema/migration social connections và publish jobs.
- [x] Triển khai OAuth authorization/callback, state/PKCE, code exchange, refresh và mã hóa token server-side.
- [x] Triển khai adapter Facebook Graph, Zalo OpenAPI và TikTok Content Posting API theo scope thực tế.
- [x] Nối “Đăng ngay” sau CEO approval, retry rate-limit, lưu trạng thái và URL bài thật.
- [x] Viết test HTTP adapter/queue, build và kiểm tra end-to-end khi credentials hợp lệ.

## Tách Admin Settings khỏi giao diện Sale
- [x] Xác nhận màn hình Sale không chứa App ID, App Secret, access token hoặc refresh token.
- [x] Giữ credentials ở ENV/Secrets Manager server-side; không commit .env và không nhúng vào HTML.
- [x] Thêm trạng thái development chưa cấu hình OAuth, không dùng placeholder để giả báo kết nối/đăng bài thành công.
- [x] Giữ nút Kết nối Facebook/Zalo/TikTok đơn giản và kiểm tra không rò secret trong bundle.

## Demo Mode social publishing không cần credentials thật
- [x] Thêm cờ Demo Mode rõ ràng, không gọi Developer Console hoặc token exchange production.
- [x] Tạo mock connection cho Facebook/Zalo/TikTok với tài khoản mẫu và nhãn DEMO.
- [x] Tạo mock publish sau CEO approval, mô phỏng queue/retry và URL bài viết có nhãn demo.
- [x] Đảm bảo production adapter vẫn fail-closed khi thiếu credentials, không dùng dữ liệu mock trong production thật.
- [x] Kiểm thử Demo Mode, build, publish và ghi rõ cách chuyển sang OAuth/API thật.

## Launcher HTML PC và điện thoại qua Wi‑Fi/5G
- [x] Xuất lại một file HTML responsive dùng chung cho PC và điện thoại.
- [x] Bảo đảm file cục bộ tự chuyển tới domain production HTTPS, không gọi localhost/file API.
- [x] Kiểm tra bundle giữ nhãn Demo/Production và không nhúng credentials.
- [x] Kiểm tra desktop/mobile, build và lưu checkpoint trước khi bàn giao.

## Fix Zalo Demo connection
- [x] Trong Demo Mode, nút Zalo phải đi qua demo callback và cập nhật trạng thái Đã kết nối như Facebook/TikTok.
- [x] Trong Production Mode, giữ nguyên deep-link/OAuth Zalo thật và không dùng callback demo.
- [x] Thêm test regression cho Zalo Demo, bảo toàn Facebook/TikTok, build và lưu checkpoint.

## Chuyển Social Demo sang Production Publishing
- [x] Production Social UI được giữ nguyên; phạm vi hiện tại chuyển sang Browser Extension theo yêu cầu mới.
- [x] Page Selector OAuth không triển khai trong Extension Mode vì không dùng Developer App; extension thao tác trên tab user đã đăng nhập.
- [x] Không tắt Demo Production API; chuyển sang Extension Mode và giữ nhãn Demo/không đăng thật để tránh nhầm lẫn.
- [x] Không mở secrets vì người dùng đã chọn giải pháp không cần Developer App; extension không chứa credentials.
- [x] Không lưu token trong Extension Mode; dùng phiên đăng nhập sẵn trên trình duyệt của Sale và không đọc cookie.
- [x] Không gọi API thật trong Extension Mode; extension chỉ chuẩn bị nội dung và yêu cầu Sale xác nhận trên tab nền tảng.
- [x] Extension đã kiểm tra cú pháp, quyền tối thiểu, không chứa secret và đóng gói ZIP; Production API vẫn là lựa chọn riêng khi có credentials.

## Browser Extension đăng bài qua phiên trình duyệt của Sale
- [x] Xác định giới hạn: backend cloud không đọc cookie/phiên đăng nhập; extension phải chạy trên thiết bị Sale.
- [x] Tạo extension Manifest V3 với quyền tối thiểu, không lấy mật khẩu và không gửi cookie về server.
- [x] Thiết kế xác thực lệnh từ Dental AI Mass, chỉ nhận nội dung đã CEO duyệt.
- [x] Thêm quy trình preview/xác nhận trước khi extension thao tác đăng bài trên từng nền tảng.
- [x] Đóng gói extension, kiểm thử cú pháp và bàn giao hướng dẫn cài đặt an toàn.

## PC Extension và Mobile Assisted Publish
- [x] Nhận diện mobile/desktop và chọn đúng phương thức hỗ trợ đăng bài.
- [x] Với approved content trên mobile, thêm nút “Đăng bài bằng điện thoại”.
- [x] Sao chép văn bản bài viết vào clipboard sau thao tác của Sale.
- [x] Hỗ trợ tải ảnh bài viết về thiết bị mobile.
- [x] Mở deep-link Facebook, TikTok hoặc Zalo sau khi copy/tải ảnh; không tự đăng thay Sale.
- [x] Giữ Browser Extension cho PC, kiểm thử responsive và lưu checkpoint.

## Export HTML dùng chung PC và điện thoại
- [x] Build và xuất một file HTML standalone responsive mới nhất.
- [x] Giữ production bootstrap HTTPS và nhánh Extension PC/Mobile Assisted Publish.
- [x] Kiểm tra file tồn tại, endpoint production và viewport mobile/desktop trước khi bàn giao.

## Chốt Mobile Assisted Publish / Browser Extension
- [x] Thay toàn bộ nhãn Demo/Mô phỏng trên UI social bằng “Chế độ Hỗ trợ đăng bài (Chuẩn an toàn)”.
- [x] Bảo đảm chỉ bài có `approved: true` mới hiển thị hành động hỗ trợ đăng.
- [x] Hoàn thiện 1-click copy văn bản, tải/chuyển media và mở Facebook/TikTok/Zalo; Sale dán và bấm Đăng.
- [x] Viết hướng dẫn sử dụng ngắn gọn cho Sale trên PC và điện thoại.
- [x] Build, kiểm thử responsive, xuất HTML và lưu checkpoint.

## Khôi phục kết nối thật, loại bỏ tài khoản mẫu
- [x] Không tự tạo hoặc hiển thị `Demo ... Sale` như tài khoản đã kết nối.
- [x] Chỉ đọc trạng thái social từ callback thật hoặc thao tác assisted publish đã xác nhận; xóa trạng thái mẫu cũ khỏi client state.
- [x] Giữ nguyên deep-link Facebook/TikTok và luồng Zalo app cá nhân; không đổi sang Demo callback.
- [x] Hiển thị đúng “Chưa kết nối” khi chưa có bằng chứng kết nối thật, kèm nút kết nối/hỗ trợ minh bạch.
- [x] Kiểm thử, xuất HTML và lưu checkpoint bản khôi phục.

## Export launcher sạch sau lỗi liên kết bị hủy
- [x] Kiểm tra launcher không nhúng trạng thái/tài khoản social cũ.
- [x] Xuất file HTML mới trỏ production HTTPS và không tự khẳng định liên kết đã hoạt động.
- [x] Kiểm tra build, redirect và bàn giao file mới cho PC/điện thoại.

## Chuyển toàn bộ kết nối sang OAuth Production thật
- [x] Tìm và loại bỏ mọi lời gọi `/api/social/demo/connect` khỏi UI và launcher.
- [x] Dùng authorization URL backend thật cho Facebook, Zalo và TikTok.
- [x] Không trả về hoặc hiển thị tài khoản/token/URL bài đăng giả.
- [x] Khi thiếu credentials, hiển thị lỗi cấu hình Production rõ ràng thay vì lỗi endpoint bị vô hiệu hóa.
- [x] Kiểm thử, build và publish bản sửa; kiểm tra redirect URI production.

## Thay module kết nối theo file mẫu ULTRATECH
- [x] Đối chiếu riêng card/modal/handler kết nối trong `ULTRATECH_SALE_FIX_20260827FULL.html` với Dental AI Mass.
- [x] Thay chỉ module kết nối Facebook/Zalo/TikTok, không thay dashboard, AI Agents, kho, KPI, chat hoặc approval.
- [x] Giữ đúng tên, domain và dữ liệu Dental AI Mass; không mang thương hiệu UltraTech sang hệ thống.
- [x] Chạy regression test/build và xuất HTML mới sau khi đối chiếu.

## Lỗi kết nối social theo file mẫu
- [x] Đối chiếu luồng local/assisted của HTML UltraTech với luồng OAuth hiện tại của Dental AI Mass.
- [x] Sửa điểm chặn khiến nút kết nối không mở hoặc không cập nhật trạng thái như file mẫu.
- [x] Kiểm thử PC/mobile, callback/trạng thái và bảo đảm không ảnh hưởng module khác.
- [x] Build, xuất HTML standalone và lưu checkpoint bản sửa.

## Facebook Auto-Publisher UI hỗ trợ đăng bài
- [x] Lấy nội dung bài viết từ Mục 02, URL trang đích từ Mục 07 và ảnh sản phẩm từ Kho.
- [x] Tổng hợp nội dung kèm dòng "Xem chi tiết tại" và mở Facebook chính thức.
- [x] Bổ sung Browser Extension/Quick-Assist để điền nội dung, chuẩn bị ảnh và fallback clipboard; không tự bấm Đăng.
- [x] Kiểm thử, build, xuất HTML standalone và lưu checkpoint.

## Zalo Mobile Native Share
- [x] Ghép nội dung Mục 02 với URL trang đích Mục 07 và lấy media ảnh nếu có.
- [x] Dùng `navigator.share()`/`navigator.canShare()` để chia sẻ text + file trên mobile.
- [x] Thêm fallback Clipboard + deep link `zalo://` khi Web Share hoặc file share không khả dụng.
- [x] Chỉ hiển thị nút cho bài đã CEO duyệt; kiểm thử, build và lưu checkpoint.

## TikTok Mobile Auto-Upload
- [x] Lấy media từ AI Video Studio/Kho và caption từ Mục 02 kèm link/Mã giới thiệu Mục 07.
- [x] Dùng `navigator.share()`/`navigator.canShare()` để chia sẻ media + caption trên mobile.
- [x] Thêm fallback tải media, Clipboard và deep link `snssdk1180://share`/`tiktok://camera`.
- [x] Chỉ hiển thị nút cho bài đã CEO duyệt; kiểm thử, build và lưu checkpoint.

## Chuẩn bị triển khai Render WebApp + Backend
- [x] Đánh giá cấu trúc hiện tại và xác định mô hình Render Static Site + Web Service phù hợp.
- [x] Thêm cấu hình build/deploy Render, biến môi trường và backend runtime/callback hiện có.
- [x] Kiểm thử frontend/backend production, mobile bundle và health endpoint dashboard.
- [x] Triển khai lên tài khoản Render và bàn giao URL cùng hướng dẫn Add to Home Screen.

## Render Unified Web Service
- [x] Kiểm tra runtime một Web Service: frontend build, backend start, PORT và health endpoint.
- [x] Thêm cấu hình Render Blueprint/Web Service duy nhất; backend giữ các callback/API hiện có.
- [x] Bổ sung tài liệu biến môi trường, OAuth callback, cookie phiên và database cho Render.
- [x] Chạy test/build/health smoke test và chuẩn bị gói deploy.
- [x] Kết nối tài khoản/repository Render, deploy thật và bàn giao URL.

## Kiểm tra GitHub/Render Source
- [x] Xác minh remote hiện tại có phải GitHub repository hay chỉ là remote nội bộ.
- [x] Kiểm tra branch/commit đã push và xác định tên repository nếu có.
- [x] Nếu chưa có GitHub repo, tạo gói mã nguồn loại trừ secrets và hướng dẫn upload.
- [x] Cung cấp quy trình kết nối Render ngắn gọn theo trạng thái thực tế.

## Tự động tạo GitHub repository và Render direct link
- [x] Kiểm tra GitHub connector/PAT/API có sẵn mà không tự thu thập hoặc hiển thị token nhạy cảm.
- [x] Nếu có quyền hợp lệ, tạo repo `dental-ai-mass-render` và push gói mã nguồn sạch.
- [x] Nếu không có quyền, tạo hướng dẫn/direct link ít bước nhất và nêu rõ thao tác bắt buộc của người dùng.
- [x] Cung cấp đúng URL Render deploy phù hợp với trạng thái repository thực tế.

## Render production follow-up
- [x] Kiểm tra URL live và `/healthz` sau deploy.
- [x] Xác định giá trị OAuth server production đúng từ cấu hình hiện có.
- [x] Bổ sung `OAUTH_SERVER_URL` và `PUBLIC_APP_URL` trên Render; các secrets backend khác vẫn cần nạp riêng để bật đầy đủ tính năng.
- [x] Xác nhận lại trạng thái live và cập nhật hướng dẫn vận hành.

## Production secrets, OAuth redirect và mobile webhook test
- [ ] Rà soát toàn bộ biến môi trường OAuth, database, JWT và webhook trong source/deployment.
- [ ] Thu thập và nạp secrets Production qua cơ chế bảo mật, không commit vào GitHub.
- [ ] Cập nhật Redirect URI chính xác cho Facebook, Zalo và TikTok theo domain Render.
- [ ] Kiểm tra callback OAuth, đăng nhập mobile và webhook thật trên endpoint Render.
- [ ] Xác nhận kết quả, ghi chú giới hạn và lưu checkpoint mới.

## Giữ nguyên luồng kết nối cũ trên Render
- [ ] Dừng yêu cầu OAuth App ID/Secret cho luồng Assisted; không thay đổi local/assisted state.
- [ ] Đối chiếu source archive trên GitHub/Render với bản đã đăng nhập được FB/Zalo/TikTok trước đây.
- [ ] Khôi phục đúng Browser Extension, Mobile Assisted, Native Share và deep-link cũ nếu archive bị thiếu.
- [ ] Redeploy Render, kiểm thử mobile/PC và xác nhận trạng thái kết nối không quay về Production OAuth bắt buộc.
