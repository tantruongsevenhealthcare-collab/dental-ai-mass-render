# Ghi chú triển khai OAuth mạng xã hội

## Yêu cầu chung
Luồng 1-click của người dùng cần nút kết nối duy nhất, chuyển hướng tới trang cấp quyền chính thức, callback HTTPS về backend, đổi authorization code ở server và lưu token ở server. Client secret không được nhúng vào frontend.

## Facebook Login
Tài liệu Meta mô tả authorize URL `https://www.facebook.com/v26.0/dialog/oauth` với `client_id`, `redirect_uri`, `state` và tùy chọn `scope`; server đổi `code` qua `https://graph.facebook.com/v26.0/oauth/access_token` bằng `client_id`, `redirect_uri`, `client_secret` và `code`. Cần đăng ký redirect URI trong App Dashboard và dùng state chống CSRF.

## TikTok Login Kit
Tài liệu chính thức yêu cầu app đã đăng ký và redirect URI HTTPS tĩnh. Authorize URL là `https://www.tiktok.com/v2/auth/authorize/` với `client_key`, `response_type=code`, `scope`, `redirect_uri`, `state`. Server phải bảo vệ client secret/refresh token, kiểm tra state và quản lý refresh token. Redirect URI phải là HTTPS tuyệt đối, không có query/fragment.

## Zalo
Tài liệu chính thức được truy cập nhưng nội dung endpoint chi tiết bị trang tài liệu động che khuất trong lần trích xuất. Không được đoán endpoint hoặc scope Zalo; cần xác nhận theo tài liệu/API app thực tế trước khi bật token exchange.

## Kết luận kiến trúc
Cấu hình cần tập trung ở environment variables của server: `SOCIAL_OAUTH_PUBLIC_URL`, `FACEBOOK_CLIENT_ID`, `FACEBOOK_CLIENT_SECRET`, `ZALO_CLIENT_ID`, `ZALO_CLIENT_SECRET`, `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`. Giao diện chỉ hiển thị nút kết nối và trạng thái, không hiển thị trường khóa. Nếu chưa có credentials thật, hệ thống phải báo trạng thái chưa cấu hình một cách ngắn gọn và không giả lập kết nối.

## Nguồn
- Meta: https://developers.facebook.com/documentation/facebook-login/guides/advanced/manual-flow
- TikTok: https://developers.tiktok.com/doc/login-kit-web/
- Zalo: https://developers.zalo.me/docs/api/official-account-api/phu-luc/official-account-access-token-post-4307

## Bổ sung sau tra cứu 25/08/2026
Meta xác nhận cần đăng ký làm developer và đăng nhập developer account; tạo app tại `https://developers.facebook.com/apps/creation/`, nhập tên app và email liên hệ, chọn use case, chọn business portfolio (hoặc chưa kết nối), xem yêu cầu App Review rồi vào dashboard. App ID và App Secret được cấp để xác thực và tạo access token. Nguồn: https://developers.facebook.com/documentation/development/create-an-app

Zalo Social API có tài liệu riêng cho User Access Token tại `https://developers.zalo.me/docs/api/social-api/tham-khao/user-access-token-post-4316`; không được dùng nhầm tài liệu Official Account để tuyên bố có thể đăng lên trang cá nhân. Endpoint/scope thực tế cần lấy theo ứng dụng Zalo và quyền được duyệt.

## TikTok Web Login Kit
Tài liệu TikTok cập nhật ngày 04/08/2026 yêu cầu redirect URI được đăng ký trong cấu hình Login Kit. URI phải tuyệt đối và bắt đầu bằng HTTPS, có tối đa 10 URI, dài dưới 512 ký tự, tĩnh, không có query parameters và không có fragment/hash. Nguồn: https://developers.tiktok.com/docs/en/login-kit-web

## Xác minh tài liệu chính thức ngày 25/08/2026

Meta Facebook Login yêu cầu authorize URL có `client_id`, `redirect_uri` và `state`; redirect URI phải được khai báo trong Valid OAuth Redirect URIs của Facebook Login Settings. `state` dùng chống CSRF và callback cần được kiểm tra trước khi đổi code/token. Nguồn: https://developers.facebook.com/documentation/facebook-login/guides/advanced/manual-flow

Zalo Social API có tài liệu User Access Token riêng; đây không phải Zalo Official Account API. Cần dùng đúng loại ứng dụng/quyền Social API, App ID/Secret và callback được nền tảng chấp thuận. Nguồn: https://developers.zalo.me/docs/api/social-api/tham-khao/user-access-token-post-4316

TikTok Login Kit Web yêu cầu đăng ký app và client key/secret trong TikTok Developer Center. Redirect URI phải là HTTPS tuyệt đối, tĩnh, không có query/fragment; tài liệu cũng tách rõ frontend authorize flow, server xử lý authorization grant, quản lý authorization response và user access token. Nguồn: https://developers.tiktok.com/docs/en/login-kit-web
