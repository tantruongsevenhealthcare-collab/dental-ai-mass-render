# Dental AI Mass – Social Assistant

Đây là extension Manifest V3 dành cho Chrome/Edge. Extension nhận lệnh từ domain production chỉ khi payload có `approved: true`, giữ nội dung đã được CEO duyệt trên thiết bị Sale và chuyển nội dung sang tab social đang mở sau khi Sale xác nhận.

Extension không đọc mật khẩu, không lấy hoặc gửi cookie về server, không tự đăng nhập và không tự vượt CAPTCHA. Do giao diện Facebook, TikTok và Zalo có thể thay đổi và chính sách nền tảng có thể giới hạn tự động hóa, extension dùng mô hình **prepare-and-confirm**: với Facebook, extension tìm ô “Bạn đang nghĩ gì thế?”, điền nội dung đã duyệt, thử đính kèm ảnh sản phẩm từ `mediaUrl`, rồi Sale kiểm tra và tự bấm nút Đăng. Nếu không tìm thấy ô soạn thảo hoặc Facebook chặn ảnh, extension sao chép/mở ảnh để Sale thao tác thủ công.

## Cài đặt thử nghiệm

Mở `chrome://extensions`, bật Developer mode, chọn Load unpacked và trỏ tới thư mục `browser-extension`. Đăng nhập sẵn nền tảng trong tab riêng. Khi Dental AI Mass gửi một nội dung đã CEO duyệt, mở popup extension, kiểm tra nền tảng/ nội dung, chọn đúng tab và bấm “Cho phép thao tác trên tab hiện tại”.

## Giao thức dashboard → extension

Dashboard có thể gửi `chrome.runtime.sendMessage(extensionId, { type: "DENTAL_AI_APPROVED_POST", approved: true, platform: "facebook" | "tiktok" | "zalo", content: "...", mediaUrl: "https://...", productName: "...", sourceId: "..." })`. Với Facebook, `content` đã bao gồm dòng `Xem chi tiết tại: [URL trang đích]`. Extension chỉ chấp nhận message có origin đúng `https://dentalaimass-pyihn8cu.manus.space`, platform hợp lệ và nội dung không rỗng.

## Production note

Đăng bài hoàn toàn tự động, không cần Sale bấm thêm, chỉ nên bật khi có API chính thức và quyền hợp lệ của từng nền tảng. Bản extension này không tuyên bố đã đăng bài nếu chưa nhận xác nhận từ nền tảng.
