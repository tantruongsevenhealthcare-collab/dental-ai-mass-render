const statusEl = document.getElementById("status");
const postEl = document.getElementById("post");
const confirmBtn = document.getElementById("confirm");
const clearBtn = document.getElementById("clear");
let pending = null;

function render() {
  if (!pending) {
    statusEl.textContent = "Không có nội dung đã CEO duyệt đang chờ.";
    postEl.hidden = true; confirmBtn.hidden = true; clearBtn.hidden = true; return;
  }
  statusEl.textContent = `Đã nhận nội dung ${pending.platform.toUpperCase()} – cần Sale xác nhận trên tab đang mở.`;
  postEl.textContent = pending.content;
  postEl.hidden = false; confirmBtn.hidden = false; clearBtn.hidden = false;
}

chrome.runtime.sendMessage({ type: "GET_PENDING_POST" }).then((result) => { pending = result.post; render(); });
confirmBtn.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !pending) { statusEl.textContent = "Không tìm thấy tab social đang hoạt động."; return; }
  const host = new URL(tab.url || "").hostname;
  const allowed = pending.platform === "facebook" ? /(^|\.)facebook\.com$/.test(host) : pending.platform === "tiktok" ? /(^|\.)tiktok\.com$/.test(host) : /(^|\.)zalo\.me$/.test(host) || /(^|\.)zalo\.me$/.test(host);
  if (!allowed) { statusEl.textContent = "Hãy mở đúng tab Facebook, TikTok hoặc Zalo trước."; return; }
  const result = await chrome.tabs.sendMessage(tab.id, { type: "PREPARE_APPROVED_POST", post: pending }).catch(() => ({ ok: false, error: "Tab chưa sẵn sàng." }));
  statusEl.textContent = result?.ok ? "Đã chuyển nội dung vào tab. Sale kiểm tra và bấm Đăng trên nền tảng." : (result?.error || "Không thể chuyển nội dung.");
});
clearBtn.addEventListener("click", async () => { await chrome.runtime.sendMessage({ type: "CLEAR_PENDING_POST" }); pending = null; render(); });
