(() => {
  if (window.top !== window) return;

  const composerSelectors = [
    '[contenteditable="true"][role="textbox"]',
    '[contenteditable="true"]',
    'textarea[aria-label*="Bạn đang nghĩ gì"]',
    'textarea[placeholder*="Bạn đang nghĩ gì"]',
    "textarea[aria-label*=\"What's on your mind\"]",
  ];
  const findComposer = () => composerSelectors.map((selector) => document.querySelector(selector)).find(Boolean);

  const fillComposer = (composer, text) => {
    composer.focus();
    if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(composer, text);
    } else {
      composer.textContent = text;
    }
    composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
  };

  const attachImage = async (mediaUrl) => {
    if (!mediaUrl) return { ok: false, reason: "Không có link ảnh sản phẩm." };
    try {
      const response = await fetch(mediaUrl, { credentials: "omit" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      const file = new File([blob], "dental-ai-product.jpg", { type: blob.type || "image/jpeg" });
      const input = [...document.querySelectorAll('input[type="file"]')].find((element) => !element.disabled);
      if (!input) throw new Error("Chưa thấy ô tải ảnh của Facebook.");
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true };
    } catch {
      window.open(mediaUrl, "dental-ai-product-image", "noopener,noreferrer");
      return { ok: false, reason: "Không thể đính kèm tự động; ảnh đã được mở để Sale chọn thủ công." };
    }
  };

  const prepareFacebookPost = async (post) => {
    const composer = findComposer();
    if (!composer) {
      await navigator.clipboard?.writeText(post.content);
      return { ok: false, error: "Chưa tìm thấy ô 'Bạn đang nghĩ gì thế?'. Văn bản đã được sao chép vào Clipboard." };
    }
    fillComposer(composer, post.content);
    const image = await attachImage(post.mediaUrl);
    return { ok: true, warning: image.reason || null };
  };

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "PREPARE_APPROVED_POST" || !message.post?.approved) return;
    const post = message.post;
    const existing = document.getElementById("dental-ai-approved-post");
    existing?.remove();
    const panel = document.createElement("aside");
    panel.id = "dental-ai-approved-post";
    panel.style.cssText = "position:fixed;z-index:2147483647;right:16px;bottom:16px;width:340px;padding:16px;background:#fff;color:#172033;border:2px solid #2563eb;border-radius:12px;box-shadow:0 8px 30px #0003;font:14px system-ui,sans-serif";
    panel.innerHTML = `<strong>Dental AI Mass – Nội dung đã CEO duyệt</strong><p style="white-space:pre-wrap;max-height:180px;overflow:auto;background:#f8fafc;padding:8px;border-radius:8px"></p><button id="dental-ai-prepare" style="width:100%;padding:9px;background:#2563eb;color:#fff;border:0;border-radius:8px;font-weight:700">Điền nội dung & đính kèm ảnh</button><button id="dental-ai-copy" style="width:100%;padding:9px;margin-top:6px;background:#e2e8f0;color:#172033;border:0;border-radius:8px;font-weight:700">Sao chép nội dung</button><button id="dental-ai-close" style="width:100%;padding:9px;margin-top:6px;background:#f1f5f9;border:0;border-radius:8px">Đóng</button><small style="display:block;margin-top:8px;color:#64748b">Sale kiểm tra nội dung, ảnh và tự bấm Đăng. Extension không tự đăng nhập, không đọc cookie và không tự gửi bài.</small>`;
    panel.querySelector("p").textContent = post.content;
    document.body.appendChild(panel);
    panel.querySelector("#dental-ai-prepare").addEventListener("click", async () => {
      const button = panel.querySelector("#dental-ai-prepare");
      button.disabled = true;
      button.textContent = "Đang chuẩn bị…";
      const result = await prepareFacebookPost(post);
      button.disabled = false;
      button.textContent = result.ok ? "Đã điền nội dung; Sale kiểm tra rồi bấm Đăng" : "Thử lại việc điền nội dung";
      if (result.warning) panel.querySelector("small").textContent = result.warning + " Sale kiểm tra rồi tự bấm Đăng.";
      if (result.error) panel.querySelector("small").textContent = result.error;
    });
    panel.querySelector("#dental-ai-copy").addEventListener("click", async () => { await navigator.clipboard.writeText(post.content); panel.querySelector("#dental-ai-copy").textContent = "Đã sao chép"; });
    panel.querySelector("#dental-ai-close").addEventListener("click", () => panel.remove());
    sendResponse({ ok: true });
  });
})();
