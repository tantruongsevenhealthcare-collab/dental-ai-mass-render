const ALLOWED_ORIGIN = "https://dentalaimass-pyihn8cu.manus.space";
const pendingKey = "pendingApprovedPost";

function isApprovedPost(message) {
  return message && message.type === "DENTAL_AI_APPROVED_POST" && message.approved === true &&
    ["facebook", "tiktok", "zalo"].includes(message.platform) &&
    typeof message.content === "string" && message.content.trim().length > 0;
}

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (sender.origin !== ALLOWED_ORIGIN || !isApprovedPost(message)) {
    sendResponse({ ok: false, error: "Lệnh không hợp lệ hoặc chưa được CEO duyệt." });
    return;
  }
  chrome.storage.local.set({ [pendingKey]: { ...message, receivedAt: Date.now() } }).then(() => {
    sendResponse({ ok: true, status: "queued_for_user_confirmation" });
  }).catch(() => sendResponse({ ok: false, error: "Không lưu được lệnh trên thiết bị." }));
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_PENDING_POST") {
    chrome.storage.local.get(pendingKey).then((data) => sendResponse({ ok: true, post: data[pendingKey] || null }));
    return true;
  }
  if (message?.type === "CLEAR_PENDING_POST") {
    chrome.storage.local.remove(pendingKey).then(() => sendResponse({ ok: true }));
    return true;
  }
});
