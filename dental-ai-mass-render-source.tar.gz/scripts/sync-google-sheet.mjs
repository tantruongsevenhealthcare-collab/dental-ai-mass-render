import { getDb } from "../server/db.ts";
import { agentLogs, products } from "../drizzle/schema.ts";
import {
  fetchGoogleSheetProducts,
  GOOGLE_SHEET_URL,
} from "../server/productCatalogSync.ts";

const db = await getDb();
if (!db) throw new Error("Database not available");

const sheetProducts = await fetchGoogleSheetProducts();
const syncedAt = new Date();

await db.update(products).set({ isActive: false });

for (const product of sheetProducts) {
  await db.insert(products).values({
    code: product.code,
    name: product.name,
    category: product.category,
    price: product.vatPrice.toString(),
    unit: product.unit,
    description: product.description,
    stock: 0,
    isActive: true,
    sourceType: "google_sheet",
    sourceUrl: GOOGLE_SHEET_URL,
    sourceRow: product.sourceRow,
    dealerPrice: product.dealerPrice.toString(),
    vatPrice: product.vatPrice.toString(),
    lastSyncedAt: syncedAt,
  }).onDuplicateKeyUpdate({
    set: {
      name: product.name,
      category: product.category,
      price: product.vatPrice.toString(),
      unit: product.unit,
      description: product.description,
      isActive: true,
      sourceType: "google_sheet",
      sourceUrl: GOOGLE_SHEET_URL,
      sourceRow: product.sourceRow,
      dealerPrice: product.dealerPrice.toString(),
      vatPrice: product.vatPrice.toString(),
      lastSyncedAt: syncedAt,
    },
  });
}

await db.insert(agentLogs).values({
  agentName: "AI Sales",
  actionType: "SYNC_PRODUCT_CATALOG",
  content: `Đồng bộ ${sheetProducts.length} sản phẩm từ Google Sheets bằng script vận hành. Nguồn: ${GOOGLE_SHEET_URL}`,
});

console.log(JSON.stringify({
  success: true,
  productCount: sheetProducts.length,
  productNames: sheetProducts.map((product) => product.name),
  syncedAt: syncedAt.toISOString(),
}, null, 2));
