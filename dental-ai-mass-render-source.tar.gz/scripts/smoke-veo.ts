import { generateVeoVideoToStorage } from "../server/routers/zeroTouchRouter";

const result = await generateVeoVideoToStorage({
  storageName: `smoke-test-${Date.now()}`,
  prompt:
    "Create an original 8-second vertical 9:16 Vietnamese dental product video. Show a clean clinical scene with a generic dental collagen plug package and neutral presenter narration. Use only these verified claims: collagen block for bleeding control and post-extraction discomfort support. Do not show a manufacturer logo, exclusivity claim, certification, or unverified clinical outcome. End with the Vietnamese CTA: Liên hệ Zalo 0963166698.",
});

console.log(JSON.stringify(result));
