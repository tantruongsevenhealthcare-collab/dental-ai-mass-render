# Hướng dẫn Admin: OAuth 1-click cho Chủ doanh nghiệp

**Ngày fix:** 25/08/2026  
**Hệ thống:** 24 Seven Health Care Vietnam  
**Production URL:** https://dentalaimass-pyihn8cu.manus.space/

## 1. Nguyên tắc vận hành

Họ tên, số điện thoại và email được nhập một lần trong hồ sơ Chủ doanh nghiệp để định danh Owner nội bộ. Ba thông tin này **không phải** là mật khẩu Facebook, Zalo hoặc TikTok và không thể dùng để tự đăng nhập thay người dùng. Mỗi nền tảng phải có một lần cấp quyền OAuth riêng trên trang chính thức.

Admin cấu hình ứng dụng OAuth và secret ở backend. Chủ doanh nghiệp không nhìn thấy Client Secret, không nhập secret vào HTML, không gửi mật khẩu mạng xã hội cho Admin. Sau khi cấu hình xong, trên dashboard chỉ còn nút **Kết nối 1-click**.

## 2. Tạo Facebook App ID và App Secret

Meta yêu cầu người tạo app đăng ký developer và đăng nhập developer account. Vào [Meta App Creation](https://developers.facebook.com/apps/creation/) và chọn **Create App**. Nhập tên ứng dụng, email liên hệ của doanh nghiệp, chọn use case phù hợp cho Facebook Login, rồi chọn business portfolio đã xác minh nếu doanh nghiệp đã có; nếu chưa, có thể tiếp tục mà chưa kết nối portfolio rồi bổ sung sau.

Sau khi xem yêu cầu và bấm **Go to dashboard**, vào **App settings → Basic**. Ghi lại **App ID**. Bấm **Show** tại **App Secret**, xác thực lại tài khoản Meta nếu được yêu cầu, rồi sao chép secret vào trình quản lý secret của hệ thống; tuyệt đối không commit vào Git, HTML hoặc frontend.

Trong **Facebook Login / Login for Business**, thêm domain production `dentalaimass-pyihn8cu.manus.space` và redirect URI chính xác:

```text
https://dentalaimass-pyihn8cu.manus.space/api/social-oauth/facebook/callback
```

Bật các sản phẩm/quyền đúng nhu cầu tối thiểu, lưu thay đổi, rồi kiểm tra **App Review** và **Business Verification** nếu quyền cần dùng yêu cầu xét duyệt. Không xin quyền đăng bài lên trang cá nhân nếu sản phẩm Meta hiện tại không hỗ trợ quyền đó; khi cần đăng nội dung doanh nghiệp, nên dùng Facebook Page được ủy quyền.

## 3. Tạo ứng dụng Zalo

Đăng nhập [Zalo For Developers](https://developers.zalo.me/), tạo ứng dụng và lấy App ID/App Secret theo loại ứng dụng được Zalo hỗ trợ. Trong cấu hình OAuth, đăng ký callback HTTPS của hệ thống:

```text
https://dentalaimass-pyihn8cu.manus.space/api/social-oauth/zalo/callback
```

Chọn đúng Social API/User Access Token hoặc loại ứng dụng tương ứng. Không dùng nhầm quyền của Zalo Official Account để tuyên bố rằng hệ thống có thể đăng vào Zalo cá nhân. Endpoint, scope và loại tài khoản phải khớp với ứng dụng Zalo thực tế và quyền Zalo phê duyệt.

## 4. Tạo ứng dụng TikTok

Đăng nhập [TikTok for Developers](https://developers.tiktok.com/), tạo app trong **Manage apps**, bật **Login Kit for Web** và ghi lại Client Key/Client Secret. Đăng ký callback tĩnh:

```text
https://dentalaimass-pyihn8cu.manus.space/api/social-oauth/tiktok/callback
```

TikTok yêu cầu redirect URI tuyệt đối bắt đầu bằng HTTPS, tĩnh, không có query string và không có fragment/hash. Chọn scope tối thiểu. Quyền đăng video cần Content Posting API và có thể cần TikTok xét duyệt; Login Kit thành công không đồng nghĩa tài khoản đã được cấp quyền đăng nội dung.

## 5. Biến môi trường backend

Đặt các giá trị thật trong Secret Manager của dự án, không đặt vào file HTML:

```text
SOCIAL_OAUTH_PUBLIC_URL=https://dentalaimass-pyihn8cu.manus.space
FACEBOOK_CLIENT_ID=...
FACEBOOK_CLIENT_SECRET=...
ZALO_CLIENT_ID=...
ZALO_CLIENT_SECRET=...
TIKTOK_CLIENT_KEY=...
TIKTOK_CLIENT_SECRET=...
OAUTH_STATE_SECRET=...
```

Nên lưu token được mã hóa server-side, gắn với `ownerId` và `platform`, lưu thời điểm hết hạn, refresh token nếu nền tảng cấp, và có nút ngắt kết nối. Không ghi access token vào log hoặc gửi về browser.

## 6. Backend Node.js/Express: khung callback

Ví dụ dưới đây minh họa cấu trúc; các hàm `saveEncryptedConnection`, `getOwnerFromState` và `encrypt` phải được triển khai bằng secret manager/database của hệ thống. Không đưa client secret vào frontend.

```js
import crypto from "node:crypto";
import express from "express";

const app = express();
const PUBLIC_URL = process.env.SOCIAL_OAUTH_PUBLIC_URL;
const CALLBACK = (provider) => `${PUBLIC_URL}/api/social-oauth/${provider}/callback`;

function createState(ownerId, provider) {
  const payload = JSON.stringify({ ownerId, provider, nonce: crypto.randomUUID() });
  const signature = crypto.createHmac("sha256", process.env.OAUTH_STATE_SECRET)
    .update(payload).digest("base64url");
  return Buffer.from(JSON.stringify({ payload, signature })).toString("base64url");
}

function verifyState(value) {
  const decoded = JSON.parse(Buffer.from(value, "base64url").toString("utf8"));
  const expected = crypto.createHmac("sha256", process.env.OAUTH_STATE_SECRET)
    .update(decoded.payload).digest("base64url");
  if (!crypto.timingSafeEqual(Buffer.from(decoded.signature), Buffer.from(expected))) {
    throw new Error("Invalid OAuth state");
  }
  return JSON.parse(decoded.payload);
}

app.get("/api/social-oauth/tiktok/start", (req, res) => {
  const state = createState(req.user.id, "tiktok");
  const params = new URLSearchParams({
    client_key: process.env.TIKTOK_CLIENT_KEY,
    response_type: "code",
    scope: "user.info.basic",
    redirect_uri: CALLBACK("tiktok"),
    state,
  });
  res.redirect(`https://www.tiktok.com/v2/auth/authorize/?${params}`);
});

app.get("/api/social-oauth/tiktok/callback", async (req, res) => {
  const state = verifyState(req.query.state);
  const response = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_key: process.env.TIKTOK_CLIENT_KEY,
      client_secret: process.env.TIKTOK_CLIENT_SECRET,
      code: req.query.code,
      grant_type: "authorization_code",
      redirect_uri: CALLBACK("tiktok"),
    }),
  });
  if (!response.ok) return res.redirect("/?oauth=tiktok_error");
  const token = await response.json();
  await saveEncryptedConnection(state.ownerId, "tiktok", token);
  res.redirect("/?oauth=tiktok_connected");
});
```

Với Facebook, tạo URL authorize ở server với `client_id`, `redirect_uri`, `state`, `response_type=code` và scope tối thiểu; callback dùng `https://graph.facebook.com/<GRAPH_API_VERSION>/oauth/access_token` để đổi `code`, `client_id`, `client_secret`, `redirect_uri`. Với Zalo, dùng authorize URL và token endpoint đúng theo loại ứng dụng Social API/User Access Token trong tài liệu Zalo; không suy đoán scope hoặc dùng OA endpoint cho tài khoản cá nhân.

## 7. Backend Python/Flask: khung callback TikTok và Zalo

```python
import os, secrets, requests
from flask import Flask, redirect, request, session, abort

app = Flask(__name__)
app.secret_key = os.environ["OAUTH_STATE_SECRET"]
PUBLIC_URL = os.environ["SOCIAL_OAUTH_PUBLIC_URL"]

def callback(provider):
    return f"{PUBLIC_URL}/api/social-oauth/{provider}/callback"

@app.get("/api/social-oauth/tiktok/start")
def tiktok_start():
    state = secrets.token_urlsafe(32)
    session["oauth_state"] = state
    params = {
        "client_key": os.environ["TIKTOK_CLIENT_KEY"],
        "response_type": "code",
        "scope": "user.info.basic",
        "redirect_uri": callback("tiktok"),
        "state": state,
    }
    return redirect("https://www.tiktok.com/v2/auth/authorize/?" +
                    requests.compat.urlencode(params))

@app.get("/api/social-oauth/tiktok/callback")
def tiktok_callback():
    if request.args.get("state") != session.pop("oauth_state", None):
        abort(400, "Invalid OAuth state")
    response = requests.post("https://open.tiktokapis.com/v2/oauth/token/", data={
        "client_key": os.environ["TIKTOK_CLIENT_KEY"],
        "client_secret": os.environ["TIKTOK_CLIENT_SECRET"],
        "code": request.args["code"],
        "grant_type": "authorization_code",
        "redirect_uri": callback("tiktok"),
    }, timeout=20)
    response.raise_for_status()
    save_encrypted_connection(owner_id=session["owner_id"],
                              platform="tiktok", token=response.json())
    return redirect("/?oauth=tiktok_connected")
```

Zalo callback có cùng nguyên tắc: kiểm tra `state`, gửi authorization code tới endpoint token của Zalo bằng App ID/App Secret ở server, kiểm tra HTTP status và lưu token mã hóa. Endpoint cụ thể phải lấy trong tài liệu User Access Token của ứng dụng Zalo, không copy từ một loại app khác.

## 8. Trải nghiệm của Chủ doanh nghiệp

Chủ doanh nghiệp nhập họ tên, số điện thoại và email vào hồ sơ Owner một lần. Sau đó vào **Cấu hình Prompts → Kết nối mạng xã hội của Chủ doanh nghiệp**, bấm một nút cho từng kênh, đăng nhập trên trang chính thức và bấm **Đồng ý/Cấp quyền**. Dashboard chỉ hiển thị **Chưa kết nối**, **Đang kết nối**, **Đã kết nối** hoặc **Lỗi cấp quyền**; không hiển thị secret/token.

## Tài liệu chính thức

1. [Meta — Create an App](https://developers.facebook.com/documentation/development/create-an-app)
2. [Meta — Basic Settings](https://developers.facebook.com/documentation/development/create-an-app/app-dashboard/basic-settings)
3. [Meta — Facebook Login access tokens](https://developers.facebook.com/documentation/facebook-login/guides/access-tokens)
4. [Zalo — User Access Token](https://developers.zalo.me/docs/api/social-api/tham-khao/user-access-token-post-4316)
5. [TikTok — Login Kit for Web](https://developers.tiktok.com/docs/en/login-kit-web)
6. [TikTok — Manage User Access Tokens](https://developers.tiktok.com/doc/login-kit-manage-user-access-tokens/)

## 9. Mô hình đúng của Seven Healthcare

Hệ thống trung tâm thuộc Seven Healthcare quản lý catalogue, giá, chính sách hoa hồng, AI và quy trình phê duyệt. Người dùng cuối là **cá nhân/Chủ đại lý/Đối tác bán hàng**, có thể sử dụng chương trình mà không cần đăng ký một doanh nghiệp riêng. Họ nhập họ tên, số điện thoại và email để tạo hồ sơ đại lý; sau đó tự cấp quyền cho Facebook, Zalo và TikTok cá nhân của mình.

Không được đồng nhất hồ sơ đại lý với pháp nhân doanh nghiệp. Business Verification, nếu một nền tảng yêu cầu cho một sản phẩm hoặc quyền API cụ thể, là yêu cầu của ứng dụng trung tâm hoặc quyền nền tảng; nó không phải điều kiện để cá nhân trở thành đại lý hoặc sử dụng dashboard. Mọi cá nhân vẫn phải tự đăng nhập và chấp thuận quyền trên từng nền tảng. Hệ thống chỉ lưu mối liên kết giữa `agentId`, `platform`, `providerAccountId` và token đã mã hóa.

Trong dashboard, nên dùng các nhãn **Chủ đại lý**, **Đối tác bán hàng**, **Hoa hồng**, **Tài khoản cá nhân đã kết nối** và **Quyền do Seven Healthcare quản lý**. Không dùng câu chữ khiến người dùng hiểu rằng họ phải có công ty riêng hoặc được cấp quyền Admin hệ thống.

## 10. Luồng tối giản hiện hành cho đại lý cá nhân

Trong giao diện đại lý, không hiển thị App ID, App Secret, Client Key, mật khẩu hay biểu mẫu cấu hình kỹ thuật. Đại lý chọn **Mở trang chính thức** ở thẻ Facebook cá nhân, Zalo cá nhân hoặc TikTok cá nhân. Trình duyệt mở trang của nền tảng; đại lý đăng nhập nếu cần và tự bấm xác nhận trên nền tảng. Sau đó đại lý quay lại dashboard để tiếp tục điều hành. Đây là luồng truy cập/xác nhận tối giản; việc ghi nhận kết nối OAuth vào backend và quyền đăng bài tự động chỉ hoạt động khi ứng dụng trung tâm đã được nền tảng cấp credentials, redirect URI và scope tương ứng.
