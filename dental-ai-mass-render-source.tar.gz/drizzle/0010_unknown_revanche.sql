CREATE TABLE `sale_auth_otps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phone_number` varchar(20) NOT NULL,
	`otp_code` varchar(10) NOT NULL,
	`is_verified` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`expires_at` timestamp NOT NULL,
	CONSTRAINT `sale_auth_otps_id` PRIMARY KEY(`id`)
);
