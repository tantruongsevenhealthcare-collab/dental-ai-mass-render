CREATE TABLE `backorder_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`product_name` varchar(255) NOT NULL,
	`product_code` varchar(50) NOT NULL,
	`requested_quantity` int NOT NULL,
	`dealer_name` varchar(255) NOT NULL,
	`dealer_phone` varchar(50) NOT NULL,
	`status` varchar(30) NOT NULL DEFAULT 'pending_supplier_check',
	`eta_note` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backorder_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `sale_auth_otps`;