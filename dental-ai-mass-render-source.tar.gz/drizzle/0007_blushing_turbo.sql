ALTER TABLE `products` ADD `isActive` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `sourceType` enum('legacy','google_sheet') DEFAULT 'legacy' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `sourceUrl` text;--> statement-breakpoint
ALTER TABLE `products` ADD `sourceRow` int;--> statement-breakpoint
ALTER TABLE `products` ADD `dealerPrice` decimal(12,2);--> statement-breakpoint
ALTER TABLE `products` ADD `vatPrice` decimal(12,2);--> statement-breakpoint
ALTER TABLE `products` ADD `lastSyncedAt` timestamp;