CREATE TABLE `social_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`platform` enum('facebook','zalo','tiktok') NOT NULL,
	`account_type` enum('personal','page','oa','business') NOT NULL DEFAULT 'personal',
	`external_account_id` varchar(255) NOT NULL,
	`display_name` varchar(255),
	`avatar_url` text,
	`access_token_ciphertext` text NOT NULL,
	`refresh_token_ciphertext` text,
	`token_expires_at` timestamp,
	`scopes` json NOT NULL,
	`status` enum('connected','needs_reauth','revoked') NOT NULL DEFAULT 'connected',
	`last_error` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `social_connections_id` PRIMARY KEY(`id`),
	CONSTRAINT `social_connections_user_platform_account_uq` UNIQUE(`user_id`,`platform`,`external_account_id`)
);
--> statement-breakpoint
CREATE TABLE `social_publish_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`source_type` enum('fb_zalo_queue','tiktok_video') NOT NULL,
	`source_id` int NOT NULL,
	`platform` enum('facebook','zalo','tiktok') NOT NULL,
	`content` text NOT NULL,
	`media_url` text,
	`scheduled_at` timestamp,
	`status` enum('queued','publishing','published','failed','needs_reauth') NOT NULL DEFAULT 'queued',
	`retry_count` int NOT NULL DEFAULT 0,
	`next_attempt_at` timestamp,
	`external_post_id` varchar(255),
	`external_url` text,
	`last_error` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `social_publish_jobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `social_publish_jobs_source_platform_uq` UNIQUE(`source_type`,`source_id`,`platform`)
);
--> statement-breakpoint
CREATE INDEX `social_connections_user_platform_idx` ON `social_connections` (`user_id`,`platform`);--> statement-breakpoint
CREATE INDEX `social_publish_jobs_status_attempt_idx` ON `social_publish_jobs` (`status`,`next_attempt_at`);