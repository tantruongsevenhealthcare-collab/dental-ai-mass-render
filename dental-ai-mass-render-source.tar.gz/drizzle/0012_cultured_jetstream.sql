CREATE TABLE `tiktok_videos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`product_name` varchar(255) NOT NULL,
	`video_title` varchar(255) NOT NULL,
	`script` text NOT NULL,
	`avatar_prompt` text NOT NULL,
	`video_url` text NOT NULL,
	`duration_seconds` int NOT NULL DEFAULT 15,
	`approval_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`ceo_review_notes` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tiktok_videos_id` PRIMARY KEY(`id`)
);
