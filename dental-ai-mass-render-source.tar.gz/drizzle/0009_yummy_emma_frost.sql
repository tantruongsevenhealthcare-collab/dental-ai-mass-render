CREATE TABLE `market_intelligence_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`runDate` varchar(32) NOT NULL,
	`trendingTopics` json NOT NULL,
	`competitorActions` json NOT NULL,
	`buyerIntents` json NOT NULL,
	`recommendedProductsToday` json NOT NULL,
	`targetAudience` text NOT NULL,
	`contentToPost` json NOT NULL,
	`tiktokLivestreamTopics` json NOT NULL,
	`optimalPostingTimes` json NOT NULL,
	`yesterdayResultAnalysis` text NOT NULL,
	`rawSignalsCount` int NOT NULL DEFAULT 0,
	`signalsData` json NOT NULL,
	`verificationStatus` enum('verified_real','unverified_simulated','flagged') NOT NULL DEFAULT 'verified_real',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `market_intelligence_reports_id` PRIMARY KEY(`id`)
);
