CREATE TABLE `ceo_decision_rules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ruleKey` varchar(64) NOT NULL,
	`ruleName` varchar(255) NOT NULL,
	`isEnabled` boolean NOT NULL DEFAULT true,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ceo_decision_rules_id` PRIMARY KEY(`id`),
	CONSTRAINT `ceo_decision_rules_ruleKey_unique` UNIQUE(`ruleKey`)
);
--> statement-breakpoint
ALTER TABLE `ceo_morning_reports` ADD `autoApprovalMode` enum('conditional_auto','manual_only') DEFAULT 'conditional_auto' NOT NULL;--> statement-breakpoint
ALTER TABLE `ceo_morning_reports` ADD `decisionLogs` json;