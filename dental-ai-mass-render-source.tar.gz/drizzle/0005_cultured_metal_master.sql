CREATE TABLE `partner_negotiations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`partner_name` varchar(255) NOT NULL,
	`partner_type` varchar(100) NOT NULL,
	`objective` text NOT NULL,
	`status` varchar(50) NOT NULL DEFAULT 'draft',
	`ai_strategy` text,
	`proposed_terms` text,
	`best_benefits` text,
	`negotiation_logs` text,
	`owner_feedback` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `partner_negotiations_id` PRIMARY KEY(`id`)
);
