CREATE TABLE `fb_zalo_queues` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`platform` enum('facebook','zalo') NOT NULL,
	`content` text NOT NULL,
	`scheduledTime` varchar(64) NOT NULL,
	`status` enum('draft','pending_approval','approved_ready','published') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fb_zalo_queues_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `marketing_research_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportDate` varchar(32) NOT NULL,
	`marketTrends` text NOT NULL,
	`competitorInsights` text NOT NULL,
	`strategicProposals` json NOT NULL,
	`status` enum('pending_ceo_approval','approved','revision_requested') NOT NULL DEFAULT 'pending_ceo_approval',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `marketing_research_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tiktok_stream_assets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`assetType` enum('livestream_script','clinical_video_guide','ai_product_video') NOT NULL,
	`productId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`scriptOrDetails` text NOT NULL,
	`mediaUrl` text,
	`status` enum('draft','pending_ceo_approval','approved','broadcasting') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tiktok_stream_assets_id` PRIMARY KEY(`id`)
);
