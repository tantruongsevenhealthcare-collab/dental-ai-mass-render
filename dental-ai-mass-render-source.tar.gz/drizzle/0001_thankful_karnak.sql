CREATE TABLE `agent_configs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agentKey` varchar(64) NOT NULL,
	`name` varchar(128) NOT NULL,
	`roleDescription` text NOT NULL,
	`systemPrompt` text NOT NULL,
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agent_configs_id` PRIMARY KEY(`id`),
	CONSTRAINT `agent_configs_agentKey_unique` UNIQUE(`agentKey`)
);
--> statement-breakpoint
CREATE TABLE `agent_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agentName` varchar(64) NOT NULL,
	`actionType` varchar(64) NOT NULL,
	`content` text NOT NULL,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `agent_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderCode` varchar(64) NOT NULL,
	`customerName` varchar(255) NOT NULL,
	`customerPhone` varchar(32) NOT NULL,
	`customerAddress` text NOT NULL,
	`items` json NOT NULL,
	`totalAmount` decimal(12,2) NOT NULL,
	`materialAmount` decimal(12,2) NOT NULL DEFAULT '0',
	`equipmentAmount` decimal(12,2) NOT NULL DEFAULT '0',
	`status` enum('new','processing','shipping','completed','stuck') NOT NULL DEFAULT 'new',
	`paymentStatus` enum('pending','paid') NOT NULL DEFAULT 'pending',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`completedAt` timestamp,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderCode_unique` UNIQUE(`orderCode`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` enum('material','equipment') NOT NULL,
	`price` decimal(12,2) NOT NULL,
	`unit` varchar(64) NOT NULL,
	`description` text,
	`stock` int NOT NULL DEFAULT 100,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_code_unique` UNIQUE(`code`)
);
