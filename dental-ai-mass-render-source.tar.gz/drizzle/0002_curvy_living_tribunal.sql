CREATE TABLE `ceo_morning_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportDate` varchar(32) NOT NULL,
	`reportContent` text NOT NULL,
	`proposals` json NOT NULL,
	`status` enum('pending_approval','approved','rejected') NOT NULL DEFAULT 'pending_approval',
	`ownerFeedback` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ceo_morning_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `ceo_morning_reports_reportDate_unique` UNIQUE(`reportDate`)
);
--> statement-breakpoint
ALTER TABLE `orders` ADD `isRealData` boolean DEFAULT false NOT NULL;