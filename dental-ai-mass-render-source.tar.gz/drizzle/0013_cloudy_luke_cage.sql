ALTER TABLE `tiktok_videos` ADD `generation_mode` varchar(50) DEFAULT 'self_generated' NOT NULL;--> statement-breakpoint
ALTER TABLE `tiktok_videos` ADD `reference_video_url` text;