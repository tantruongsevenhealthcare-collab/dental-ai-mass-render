ALTER TABLE `tiktok_videos` MODIFY COLUMN `video_url` text;--> statement-breakpoint
ALTER TABLE `tiktok_videos` ADD `generation_status` varchar(40) DEFAULT 'storyboard_ready' NOT NULL;--> statement-breakpoint
ALTER TABLE `tiktok_videos` ADD `creative_brief` text;--> statement-breakpoint
ALTER TABLE `tiktok_videos` ADD `reference_search_keyword` varchar(255);