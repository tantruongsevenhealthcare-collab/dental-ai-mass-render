CREATE TABLE `order_drafts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` varchar(128) NOT NULL,
	`customerName` varchar(255),
	`customerPhone` varchar(32),
	`customerAddress` text,
	`items` json,
	`totalAmount` decimal(12,2) NOT NULL DEFAULT '0',
	`status` enum('collecting_info','awaiting_confirmation','confirmed','cancelled') NOT NULL DEFAULT 'collecting_info',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `order_drafts_id` PRIMARY KEY(`id`),
	CONSTRAINT `order_drafts_sessionId_unique` UNIQUE(`sessionId`)
);
