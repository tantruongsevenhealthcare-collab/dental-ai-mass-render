import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json, boolean, uniqueIndex, index } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// 12 sản phẩm cố định nha khoa
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 255 }).notNull().default("Sản phẩm HOT - Khuyến mãi"),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 64 }).notNull(),
  description: text("description"),
  stock: int("stock").default(100).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  sourceType: mysqlEnum("sourceType", ["legacy", "google_sheet"]).default("legacy").notNull(),
  verificationStatus: mysqlEnum("verificationStatus", ["verified_real", "unverified_simulated", "flagged"]).default("unverified_simulated").notNull(),
  sourceUrl: text("sourceUrl"),
  sourceRow: int("sourceRow"),
  dealerPrice: decimal("dealerPrice", { precision: 12, scale: 2 }),
  vatPrice: decimal("vatPrice", { precision: 12, scale: 2 }),
  lastSyncedAt: timestamp("lastSyncedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

// Đơn hàng quản lý theo pipeline Zero-Touch, phân biệt dữ liệu thật (real) và mô phỏng (demo)
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderCode: varchar("orderCode", { length: 64 }).notNull().unique(),
  customerName: varchar("customerName", { length: 255 }).notNull(),
  customerPhone: varchar("customerPhone", { length: 32 }).notNull(),
  customerAddress: text("customerAddress").notNull(),
  items: json("items").notNull(),
  totalAmount: decimal("totalAmount", { precision: 12, scale: 2 }).notNull(),
  materialAmount: decimal("materialAmount", { precision: 12, scale: 2 }).default("0").notNull(),
  equipmentAmount: decimal("equipmentAmount", { precision: 12, scale: 2 }).default("0").notNull(),
  status: mysqlEnum("status", ["new", "processing", "shipping", "completed", "stuck"]).default("new").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid"]).default("pending").notNull(),
  isRealData: boolean("isRealData").default(false).notNull(), // Phân biệt đơn thật và đơn demo
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// Bảng lưu trữ nháp đơn hàng (Order Drafts) cho quy trình AI Sales chốt đơn từng bước
export const orderDrafts = mysqlTable("order_drafts", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("sessionId", { length: 128 }).notNull().unique(),
  customerName: varchar("customerName", { length: 255 }),
  customerPhone: varchar("customerPhone", { length: 32 }),
  customerAddress: text("customerAddress"),
  items: json("items"), // [{ productId, code, name, category, price, quantity }]
  totalAmount: decimal("totalAmount", { precision: 12, scale: 2 }).default("0").notNull(),
  status: mysqlEnum("status", ["collecting_info", "awaiting_confirmation", "confirmed", "cancelled"]).default("collecting_info").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OrderDraft = typeof orderDrafts.$inferSelect;
export type InsertOrderDraft = typeof orderDrafts.$inferInsert;

// Báo cáo 08:00 sáng và đề xuất kiểm duyệt từ AI CEO (Nâng cấp hỗ trợ tự phê duyệt có điều kiện và nhật ký quyết định)
export const ceoMorningReports = mysqlTable("ceo_morning_reports", {
  id: int("id").autoincrement().primaryKey(),
  reportDate: varchar("reportDate", { length: 32 }).notNull().unique(), // YYYY-MM-DD
  reportContent: text("reportContent").notNull(),
  proposals: json("proposals").notNull(), // Danh sách các đề xuất cần AI CEO hoặc chủ sở hữu kiểm duyệt
  status: mysqlEnum("status", ["pending_approval", "approved", "rejected"]).default("pending_approval").notNull(),
  autoApprovalMode: mysqlEnum("autoApprovalMode", ["conditional_auto", "manual_only"]).default("conditional_auto").notNull(), // Chế độ vận hành: Tự động có điều kiện / Chỉ thủ công
  decisionLogs: json("decisionLogs"), // Nhật ký quyết định tự động của AI CEO
  ownerFeedback: text("ownerFeedback"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CeoMorningReport = typeof ceoMorningReports.$inferSelect;
export type InsertCeoMorningReport = typeof ceoMorningReports.$inferInsert;

// Bảng cấu hình bộ quy tắc quyết định (Decision Rules) của AI CEO
export const ceoDecisionRules = mysqlTable("ceo_decision_rules", {
  id: int("id").autoincrement().primaryKey(),
  ruleKey: varchar("ruleKey", { length: 64 }).notNull().unique(),
  ruleName: varchar("ruleName", { length: 255 }).notNull(),
  isEnabled: boolean("isEnabled").default(true).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CeoDecisionRule = typeof ceoDecisionRules.$inferSelect;
export type InsertCeoDecisionRule = typeof ceoDecisionRules.$inferInsert;

// Nhật ký hoạt động của các AI Agent
export const agentLogs = mysqlTable("agent_logs", {
  id: int("id").autoincrement().primaryKey(),
  agentName: varchar("agentName", { length: 64 }).notNull(), // CEO, Marketing, Sales, Warehouse, Accountant
  actionType: varchar("actionType", { length: 64 }).notNull(),
  content: text("content").notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AgentLog = typeof agentLogs.$inferSelect;
export type InsertAgentLog = typeof agentLogs.$inferInsert;

// Cấu hình AI Agents & System Prompts
export const agentConfigs = mysqlTable("agent_configs", {
  id: int("id").autoincrement().primaryKey(),
  agentKey: varchar("agentKey", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  roleDescription: text("roleDescription").notNull(),
  systemPrompt: text("systemPrompt").notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AgentConfig = typeof agentConfigs.$inferSelect;
export type InsertAgentConfig = typeof agentConfigs.$inferInsert;

// Bảng nghiên cứu thị trường và đề xuất nội dung marketing hằng ngày cho CEO
export const marketingResearchReports = mysqlTable("marketing_research_reports", {
  id: int("id").autoincrement().primaryKey(),
  reportDate: varchar("reportDate", { length: 32 }).notNull(),
  marketTrends: text("marketTrends").notNull(),
  competitorInsights: text("competitorInsights").notNull(),
  strategicProposals: json("strategicProposals").notNull(),
  // Trường chống ảo hóa dữ liệu (Evidence-First)
  evidenceSources: json("evidenceSources").notNull(), // Danh sách nguồn: [{ title, url, scrapedAt, snippet, verificationStatus }]
  verificationStatus: mysqlEnum("verificationStatus", ["verified_real", "unverified_simulated", "flagged"]).default("unverified_simulated").notNull(),
  status: mysqlEnum("status", ["pending_ceo_approval", "approved", "revision_requested"]).default("pending_ceo_approval").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MarketingResearchReport = typeof marketingResearchReports.$inferSelect;
export type InsertMarketingResearchReport = typeof marketingResearchReports.$inferInsert;

// Hàng đợi nội dung đăng Facebook / Zalo
export const fbZaloQueues = mysqlTable("fb_zalo_queues", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  platform: mysqlEnum("platform", ["facebook", "zalo"]).notNull(),
  content: text("content").notNull(),
  scheduledTime: varchar("scheduledTime", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["draft", "pending_approval", "approved_ready", "published"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FbZaloQueue = typeof fbZaloQueues.$inferSelect;
export type InsertFbZaloQueue = typeof fbZaloQueues.$inferInsert;

// Thư viện video / ứng dụng lâm sàng và Kế hoạch Livestream TikTok
export const tiktokStreamAssets = mysqlTable("tiktok_stream_assets", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  assetType: mysqlEnum("assetType", ["livestream_script", "clinical_video_guide", "ai_product_video"]).notNull(),
  productId: int("productId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  scriptOrDetails: text("scriptOrDetails").notNull(),
  mediaUrl: text("mediaUrl"), // Link video hoặc asset minh họa
  status: mysqlEnum("status", ["draft", "pending_ceo_approval", "approved", "broadcasting"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TiktokStreamAsset = typeof tiktokStreamAssets.$inferSelect;
export type InsertTiktokStreamAsset = typeof tiktokStreamAssets.$inferInsert;

// Bảng quản lý đàm phán đối tác cho AI CEO (Partner Negotiations)
export const partnerNegotiations = mysqlTable("partner_negotiations", {
  id: int("id").autoincrement().primaryKey(),
  partnerName: varchar("partner_name", { length: 255 }).notNull(), // Tên phòng khám / đối tác
  partnerType: varchar("partner_type", { length: 100 }).notNull(), // Chuỗi nha khoa, Phòng khám, Nhà cung cấp
  objective: text("objective").notNull(), // Mục tiêu đàm phán (Ví dụ: Độc quyền phân phối Biofilling, chiết khấu sỉ 25%)
  status: varchar("status", { length: 50 }).default("draft").notNull(), // draft, negotiating, pending_owner_approval, approved, rejected, signed
  aiStrategy: text("ai_strategy"), // Chiến lược đàm phán tối đa hóa quyền lợi do AI CEO lập
  proposedTerms: text("proposed_terms"), // Các điều khoản đề xuất (JSON hoặc text)
  bestBenefits: text("best_benefits"), // Các quyền lợi cao nhất đạt được cho 24 Seven Health Care Vietnam
  negotiationLogs: text("negotiation_logs"), // Nhật ký các vòng đàm phán (JSON)
  ownerFeedback: text("owner_feedback"), // Phản hồi / Yêu cầu chỉnh sửa từ chủ sở hữu
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type PartnerNegotiation = typeof partnerNegotiations.$inferSelect;
export type InsertPartnerNegotiation = typeof partnerNegotiations.$inferInsert;

// Bảng Market Intelligence Engine đa nguồn cho CEO và Marketing
export const marketIntelligenceReports = mysqlTable("market_intelligence_reports", {
  id: int("id").autoincrement().primaryKey(),
  runDate: varchar("runDate", { length: 32 }).notNull(),
  trendingTopics: json("trendingTopics").notNull(),
  competitorActions: json("competitorActions").notNull(),
  buyerIntents: json("buyerIntents").notNull(),
  recommendedProductsToday: json("recommendedProductsToday").notNull(),
  targetAudience: text("targetAudience").notNull(),
  contentToPost: json("contentToPost").notNull(),
  tiktokLivestreamTopics: json("tiktokLivestreamTopics").notNull(),
  optimalPostingTimes: json("optimalPostingTimes").notNull(),
  yesterdayResultAnalysis: text("yesterdayResultAnalysis").notNull(),
  rawSignalsCount: int("rawSignalsCount").notNull().default(0),
  signalsData: json("signalsData").notNull(),
  verificationStatus: mysqlEnum("verificationStatus", ["verified_real", "unverified_simulated", "flagged"]).default("verified_real").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MarketIntelligenceReport = typeof marketIntelligenceReports.$inferSelect;


export type InsertMarketIntelligenceReport = typeof marketIntelligenceReports.$inferInsert;

export const backorderRequests = mysqlTable("backorder_requests", {
  id: int("id").autoincrement().primaryKey(),
  productName: varchar("product_name", { length: 255 }).notNull(),
  productCode: varchar("product_code", { length: 50 }).notNull(),
  requestedQuantity: int("requested_quantity").notNull(),
  dealerName: varchar("dealer_name", { length: 255 }).notNull(),
  dealerPhone: varchar("dealer_phone", { length: 50 }).notNull(),
  status: varchar("status", { length: 30 }).notNull().default("pending_supplier_check"), // pending_supplier_check, confirmed_eta, resolved
  etaNote: text("eta_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type BackorderRequest = typeof backorderRequests.$inferSelect;
export type InsertBackorderRequest = typeof backorderRequests.$inferInsert;

// Bảng quản lý video MP4 sản phẩm TikTok/Reels do AI Video Generation tạo ra
export const tiktokVideos = mysqlTable("tiktok_videos", {
  id: int("id").autoincrement().primaryKey(),
  productName: varchar("product_name", { length: 255 }).notNull(),
  generationMode: varchar("generation_mode", { length: 50 }).notNull().default("self_generated"), // self_generated | reference_adapted
  generationStatus: varchar("generation_status", { length: 40 }).notNull().default("provider_pending"), // provider_pending | completed | failed
  creativeBrief: text("creative_brief"),
  referenceSearchKeyword: varchar("reference_search_keyword", { length: 255 }),
  referenceVideoUrl: text("reference_video_url"),
  adaptationChecklist: text("adaptation_checklist"), // JSON checklist: hook mới, CTA mới, cảnh mới, câu chữ/giọng đọc mới
  videoTitle: varchar("video_title", { length: 255 }).notNull(),
  script: text("script").notNull(),
  avatarPrompt: text("avatar_prompt").notNull(),
  videoUrl: text("video_url"),
  durationSeconds: int("duration_seconds").default(15).notNull(),
  approvalStatus: mysqlEnum("approval_status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  ceoReviewNotes: text("ceo_review_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type TiktokVideo = typeof tiktokVideos.$inferSelect;
export type InsertTiktokVideo = typeof tiktokVideos.$inferInsert;

// Kết nối OAuth social của từng tài khoản đại lý; token chỉ lưu dạng mã hóa server-side.
export const socialConnections = mysqlTable("social_connections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  platform: mysqlEnum("platform", ["facebook", "zalo", "tiktok"]).notNull(),
  accountType: mysqlEnum("account_type", ["personal", "page", "oa", "business"]).default("personal").notNull(),
  externalAccountId: varchar("external_account_id", { length: 255 }).notNull(),
  displayName: varchar("display_name", { length: 255 }),
  avatarUrl: text("avatar_url"),
  accessTokenCiphertext: text("access_token_ciphertext").notNull(),
  refreshTokenCiphertext: text("refresh_token_ciphertext"),
  tokenExpiresAt: timestamp("token_expires_at"),
  scopes: json("scopes").notNull(),
  status: mysqlEnum("status", ["connected", "needs_reauth", "revoked"]).default("connected").notNull(),
  lastError: text("last_error"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userPlatformAccountUnique: uniqueIndex("social_connections_user_platform_account_uq").on(table.userId, table.platform, table.externalAccountId),
  userPlatformIndex: index("social_connections_user_platform_idx").on(table.userId, table.platform),
}));

export type SocialConnection = typeof socialConnections.$inferSelect;
export type InsertSocialConnection = typeof socialConnections.$inferInsert;

// Hàng đợi đăng bài thật, chỉ chuyển published sau khi API nền tảng trả thành công.
export const socialPublishJobs = mysqlTable("social_publish_jobs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  sourceType: mysqlEnum("source_type", ["fb_zalo_queue", "tiktok_video"]).notNull(),
  sourceId: int("source_id").notNull(),
  platform: mysqlEnum("platform", ["facebook", "zalo", "tiktok"]).notNull(),
  content: text("content").notNull(),
  mediaUrl: text("media_url"),
  scheduledAt: timestamp("scheduled_at"),
  status: mysqlEnum("status", ["queued", "publishing", "published", "failed", "needs_reauth"]).default("queued").notNull(),
  retryCount: int("retry_count").default(0).notNull(),
  nextAttemptAt: timestamp("next_attempt_at"),
  externalPostId: varchar("external_post_id", { length: 255 }),
  externalUrl: text("external_url"),
  lastError: text("last_error"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  sourcePlatformUnique: uniqueIndex("social_publish_jobs_source_platform_uq").on(table.sourceType, table.sourceId, table.platform),
  statusAttemptIndex: index("social_publish_jobs_status_attempt_idx").on(table.status, table.nextAttemptAt),
}));

export type SocialPublishJob = typeof socialPublishJobs.$inferSelect;
export type InsertSocialPublishJob = typeof socialPublishJobs.$inferInsert;
