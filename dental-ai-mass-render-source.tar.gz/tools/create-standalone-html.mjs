import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, "..");
const distDir = resolve(root, "dist/public");
const sourcePath = resolve(distDir, "index.html");
const outputPath = resolve(root, "24Seven_2026-08-27.html");
const productionOrigin = "https://dentalaimass-pyihn8cu.manus.space";

let html = await readFile(sourcePath, "utf8");

// Remove the platform runtime by stable DOM boundary markers. The runtime bundle
// itself contains literal </script> text in React warning strings, so a regex that
// stops at the first closing token would corrupt the exported document.
const runtimeStart = html.indexOf('<script id="manus-runtime">');
const rootMarker = runtimeStart >= 0 ? html.indexOf('<div id="root">', runtimeStart) : -1;
if (runtimeStart >= 0 && rootMarker >= 0) {
  html = html.slice(0, runtimeStart) + html.slice(rootMarker);
}

const cssMatches = [...html.matchAll(/<link[^>]+href="([^\"]+\.css)"[^>]*>/g)];
for (const match of cssMatches) {
  const cssPath = resolve(distDir, match[1].replace(/^\//, ""));
  const css = (await readFile(cssPath, "utf8")).replaceAll('</style', '<\\/style');
  html = html.replace(match[0], () => `<style data-exported-from="${match[1]}">\n${css}\n</style>`);
}

const jsMatches = [...html.matchAll(/<script[^>]+src="([^\"]+\.js)"[^>]*><\/script>/g)];
for (const match of jsMatches) {
  const jsPath = resolve(distDir, match[1].replace(/^\//, ""));
  const js = await readFile(jsPath, "utf8");
  const productionJs = js
    .replaceAll('</script', '<\\/script')
    .replaceAll('"/api/trpc"', `"${productionOrigin}/api/trpc"`)
    .replaceAll("'/api/trpc'", `'${productionOrigin}/api/trpc'`)
    .replaceAll('"/api/oauth/callback"', `"${productionOrigin}/api/oauth/callback"`)
    .replaceAll("'/api/oauth/callback'", `'${productionOrigin}/api/oauth/callback'`)
    .replaceAll('`${window.location.origin}/api/oauth/callback`', `\`${productionOrigin}/api/oauth/callback\``);
  html = html.replace(match[0], () => `<script type="module" data-exported-from="${match[1]}" data-api-origin="${productionOrigin}">\n${productionJs}\n</script>`);
}

html = html
  .replace(/<link rel="preconnect"[^>]*>\s*/g, "")
  .replace(/<link href="https:\/\/fonts\.googleapis\.com[^>]*>\s*/g, "")
  .replace(/<script\s+defer\s+src="https:\/\/manus-analytics\.com\/umami"[^>]*><\/script>\s*/g, "")
  .replace(/<script src="\/__manus__\/debug-collector\.js"[^>]*><\/script>\s*/g, "")
  .replace(/<title>[^<]*<\/title>/, "<title>24 Seven Health Care Vietnam - Enterprise Multi-Agent System</title>");

const productionBootstrap = `<script data-production-bootstrap>\n  (() => {\n    const productionUrl = "${productionOrigin}/";\n    // Android mở file tải xuống bằng content://; desktop thường dùng file://.
    // Cả hai đều không có same-origin HTTPS cho cookie/session và tRPC.
    if (!/^https?:$/.test(window.location.protocol)) {
      window.location.replace(productionUrl);
    }\n  })();\n</script>\n`;
html = html.replace("<head>", `<head>\n${productionBootstrap}`);

const note = `<!--\n  Bản HTML launcher cho đại lý cá nhân xuất ngày 27/08/2026 từ phiên bản quản lý doanh nghiệp Multi-Agent đã khôi phục.\n  File đã nhúng CSS và JavaScript frontend, đồng thời trỏ API tRPC/OAuth tới production:\n  https://dentalaimass-pyihn8cu.manus.space. Có thể mở qua Wi‑Fi/5G; trình duyệt vẫn cần\n  cho phép cookie/đăng nhập của domain production để duy trì phiên điều hành.\n-->\n`;
html = html.replace(/<!doctype html>/i, `<!doctype html>\n${note}`);
await writeFile(outputPath, html, "utf8");
console.log(`Created ${outputPath}`);
console.log(`Size ${Buffer.byteLength(html, "utf8")} bytes`);
