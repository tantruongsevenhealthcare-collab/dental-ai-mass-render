# Preview verification — Owner default and copyright footer

- Preview route `/` rendered successfully after restarting the dev server.
- The dashboard is visible; the initial skeleton is transient and does not remain after the Owner session restoration completes.
- The sidebar displays `Trương Huỳnh Minh Tân` and `0963.166.698` without a dropdown or logout control.
- A fixed bottom footer is visible across the viewport with the requested text: `© 2026 Bản quyền thuộc về Mr Trương Huỳnh Minh Tân - 0963.166.698`.
- Current server health reports running, TypeScript has no errors, and the production build plus 29 Vitest tests passed in the release check.
- The old pre-restart Vite syntax-error lines remain only as historical console-log entries; the restarted server output has no current syntax or TypeScript error.
