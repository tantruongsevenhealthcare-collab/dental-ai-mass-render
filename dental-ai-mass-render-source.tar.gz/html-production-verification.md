# Kiểm tra HTML production-connected

Ngày kiểm tra: 24/08/2026.

File `24-seven-enterprise-multi-agent-production.html` đã nhúng CSS/JavaScript frontend và bundle đã thực thi được trong Chromium. Endpoint tRPC và OAuth trong bundle đã được chuyển sang `https://dentalaimass-pyihn8cu.manus.space/api/trpc` và `https://dentalaimass-pyihn8cu.manus.space/api/oauth/callback`.

Khi mở trực tiếp bằng `file://`, router phía frontend nhận pathname vật lý `/home/ubuntu/dental-zero-touch-agent/24-seven-enterprise-multi-agent-production.html` nên hiển thị màn hình 404. Cần thêm bootstrap chuyển pathname về `/` khi giao thức là `file:`. Ngoài ra, phiên đăng nhập/cookie production có thể bị giới hạn khi mở từ `file://`; phương án đáng tin cậy cho vận hành thật là truy cập trực tiếp domain production qua HTTPS.

## Kiểm tra sau bootstrap

Sau khi thêm bootstrap production, mở file bằng `file://` đã tự chuyển sang `https://dentalaimass-pyihn8cu.manus.space/`. Domain production phản hồi HTTP 200 và hiển thị ứng dụng thay vì màn hình 404. Việc này giúp người dùng mở file từ máy tính/điện thoại rồi tiếp tục vận hành trên cùng domain HTTPS, nơi cookie, OAuth và API backend được xử lý đúng hơn.

## Kiểm tra domain và mobile

Domain `https://dentalaimass-pyihn8cu.manus.space/` phản hồi HTTP 200 và browser render được giao diện quản trị doanh nghiệp với tab KPI & CEO 08:00, Form Chat 5 Agents, Pipeline Đơn Hàng, Kho Sản Phẩm, AI Marketing và Cấu hình Prompts.

Viewport mobile 375x812 vẫn hiển thị được hệ thống và footer cố định. Một số khu vực header/tab còn dày và có thể bị cắt ngang ở màn hình rất hẹp; đây là hạng mục responsive UI riêng, không ảnh hưởng đến việc file production-connected tự chuyển sang domain live.

## Android content:// launcher fix

Ngày 24/08/2026, launcher đã được sửa để nhận diện mọi giao thức không phải HTTP(S), bao gồm `content://` của Android và `file://` trên PC. Kiểm tra mở file local trong Chromium đã chuyển sang `https://dentalaimass-pyihn8cu.manus.space/` thay vì giữ pathname cục bộ gây 404. HTML production-connected đã được tạo lại với endpoint tRPC/OAuth production.
