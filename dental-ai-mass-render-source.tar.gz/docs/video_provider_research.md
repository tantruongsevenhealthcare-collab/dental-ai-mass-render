# Video provider research

## Google Gemini Video API

Source: https://ai.google.dev/gemini-api/docs/video

Retrieved: 2026-08-21.

The official documentation states that the Gemini API exposes video generation models including Gemini Omni Flash and Veo 3.1. Gemini Omni Flash is described as a multimodal video generation and editing model supporting text, images, audio, and video inputs; Veo 3.1 supports video generation with native audio through the generateContent API. The page itself links to the official API-key flow at https://aistudio.google.com/apikey. A real integration therefore requires an authorized Google/Gemini credential and a billable/provider-enabled account; the project cannot invent or silently obtain that credential.

## Current Manus connector state

The session config contains a built-in connector named Google Gemini (UID `4157dedf-1326-4be8-9295-51416c7dba62`), currently disabled. The connector search did not expose a usable video-generation credential. It should not be enabled or changed speculatively because the requested deployed backend needs an authorized server-side video API path, not only a general multimodal connector.

## Product implication

The project currently has an internal image-generation helper only (`server/_core/imageGeneration.ts`), not a documented internal text-to-video helper. Until an authorized video provider credential/connector is available, the honest backend state is `provider_pending` with no MP4 URL. The UI must not claim that an MP4 exists.

## Veo implementation check

The official Veo page is https://ai.google.dev/gemini-api/docs/veo. Browser navigation confirmed the page has a `Text to video generation` section and a `Dialogue & sound effects` section, but the second browser view returned `about:blank`; implementation details still need to be obtained through stateless extraction or the official SDK documentation before writing provider code. Do not assume endpoint fields until verified.

## Verified Veo 3.1 API details

Source: https://ai.google.dev/gemini-api/docs/veo

The official page says Veo 3.1 generates 8-second videos at 720p, 1080p, or 4K, supports portrait `9:16`, and uses the model `veo-3.1-generate-preview`. The official JavaScript example uses `@google/genai`: create `new GoogleGenAI({})`, call `ai.models.generateVideos({ model: "veo-3.1-generate-preview", prompt })`, poll with `ai.operations.getVideosOperation({ operation })` until `operation.done`, then call `ai.files.download({ file: operation.response.generatedVideos[0].video, downloadPath })`. The REST example uses `POST https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-generate-preview:predictLongRunning` with `x-goog-api-key: $GEMINI_API_KEY`, polls the returned operation name, extracts `.response.generateVideoResponse.generatedSamples[0].video.uri`, and downloads the URI with the same API key. The source explicitly confirms portrait 9:16 and does not permit us to invent fields beyond the documented request shape.
