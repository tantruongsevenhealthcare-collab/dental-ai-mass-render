
## Zalo deep-link

Kết quả tìm kiếm có một mục cộng đồng trên miền Zalo for Developers về “URL scheme để mở Zalo”, nhưng kết quả không cung cấp nội dung scheme đầy đủ trong phần trích xuất. Vì vậy không nên hardcode một scheme chưa xác minh. Handler sẽ thử `zalo://` ở mobile rồi fallback có kiểm soát về `https://id.zalo.me/`; nếu thiết bị chặn scheme, người dùng vẫn nhận được trang web thay thế.

Nguồn tham khảo: https://developers.zalo.me/community/detail/14fef113cd5624087d47
