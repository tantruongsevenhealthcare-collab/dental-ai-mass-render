# Hướng dẫn Sale – Chế độ Hỗ trợ đăng bài (Chuẩn an toàn)

## Mục đích

Dental AI Mass chuẩn bị nội dung đã được AI Marketing tạo và CEO phê duyệt. Hệ thống không nhận mật khẩu, không đọc cookie và không tự đăng nhập thay Sale. Sale thực hiện bước cuối trên tài khoản Facebook, TikTok hoặc Zalo đang đăng nhập.

## Dùng trên điện thoại

Mở Dental AI Mass bằng Wi‑Fi hoặc 4G/5G. Trong Content Calendar, chỉ những bài đã có trạng thái `approved` hoặc **Đã sẵn sàng đăng** mới có nút **Đăng bài bằng điện thoại**.

Bấm nút này một lần. Hệ thống sẽ sao chép toàn bộ văn bản vào clipboard, tải hình ảnh/video nếu bài có media và mở ứng dụng hoặc trang tương ứng. Chuyển sang màn hình đăng bài của nền tảng, dán nội dung, chọn media đã tải và bấm **Đăng**. Nếu ứng dụng không mở, trình duyệt sẽ mở trang web chính thức để Sale tiếp tục.

## Dùng trên PC/laptop

Cài Browser Extension Dental AI Mass trên Chrome hoặc Edge bằng Developer mode → Load unpacked → chọn thư mục extension. Đăng nhập sẵn Facebook, TikTok hoặc Zalo trong tab tương ứng.

Khi có nội dung đã CEO duyệt, mở popup extension, kiểm tra nền tảng và nội dung, chọn đúng tab social rồi bấm **Cho phép thao tác trên tab hiện tại**. Extension chuyển nội dung vào tab để Sale kiểm tra, dán nếu cần và bấm **Đăng** trên nền tảng.

## Quy tắc an toàn

Không nhập mật khẩu, mã OTP, App ID, App Secret hoặc access token vào Dental AI Mass hay extension. Không bấm đăng nếu sai nền tảng, sai tài khoản hoặc nội dung chưa được CEO duyệt. URL bài đăng chỉ được xem là bài thật khi Sale hoàn tất nút Đăng và nền tảng hiển thị bài trên tài khoản.

## Xử lý nhanh khi không hoạt động

Nếu clipboard không được cấp quyền, hãy giữ nội dung bài viết và chọn Sao chép thủ công. Nếu app không mở, chọn liên kết web chính thức. Nếu không thấy nút hỗ trợ, kiểm tra trạng thái bài có phải **Đã sẵn sàng đăng** hay chưa; bài nháp hoặc bài chờ duyệt chưa được phép đăng.
