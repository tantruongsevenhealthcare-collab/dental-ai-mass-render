import React, { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { 
  Building2, 
  TrendingUp,
  Search,
  Share2,
  Video, 
  Package, 
  ShoppingCart, 
  Bot, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  Truck, 
  AlertTriangle, 
  Send, 
  RefreshCw, 
  Settings, 
  BarChart3, 
  FileText, 
  Users, 
  PhoneCall, 
  MapPin, 
  Sparkles,
  ChevronRight,
  Globe,
  Target,
  DollarSign,
  Calendar,
  Trash2,
  Check,
  X,
  ShieldCheck,
  CheckCircle,
  XCircle,
  Briefcase,
  Plus,
  Play,
  Smartphone,
  Copy,
  Download
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { summarizeAgentActivity, summarizeOrderStatuses, summarizeProposalStatuses } from "@/lib/kpiDashboard";
import { getAssistedSocialUrl, getMissingPublishScopes, socialPlatforms } from "@/lib/socialPlatforms";
import { composeFacebookPost, createFacebookPublisherPayload } from "@/lib/facebookPublisher";
import { createTikTokPublisherPayload } from "@/lib/tiktokPublisher";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const MOBILE_UA = /Android|iPhone|iPad|iPod/i;
const isMobileDevice = () => typeof navigator !== "undefined" && MOBILE_UA.test(navigator.userAgent);

async function prepareFacebookBrowserPublish(input: { content: string; landingUrl?: string | null; mediaUrl?: string | null; productName?: string | null; sourceId?: number | string }) {
  const payload = createFacebookPublisherPayload(input);
  await navigator.clipboard?.writeText(payload.content);
  if (payload.mediaUrl) {
    const imageLink = document.createElement("a");
    imageLink.href = payload.mediaUrl;
    imageLink.download = `dental-ai-${(payload.productName || "san-pham").replace(/[^a-z0-9\u00C0-\u024F]+/gi, "-")}.jpg`;
    imageLink.target = "_blank";
    imageLink.rel = "noreferrer";
    document.body.appendChild(imageLink);
    imageLink.click();
    imageLink.remove();
  }
  const facebookTab = window.open("https://www.facebook.com/", "dental-ai-facebook", "popup,width=1100,height=820");
  if (!facebookTab) throw new Error("Trình duyệt đang chặn cửa sổ Facebook.");
  return payload;
}

async function shareToZaloNative(input: { content: string; landingUrl?: string | null; mediaUrl?: string | null; productName?: string | null }) {
  const text = composeFacebookPost({ content: input.content, landingUrl: input.landingUrl });
  let imageFile: File | null = null;
  if (input.mediaUrl) {
    try {
      const response = await fetch(input.mediaUrl, { credentials: "omit" });
      if (!response.ok) throw new Error("Không tải được ảnh sản phẩm");
      const blob = await response.blob();
      imageFile = new File([blob], `${(input.productName || "san-pham").replace(/[^a-z0-9\\u00C0-\\u024F]+/gi, "-")}.jpg`, { type: blob.type || "image/jpeg" });
    } catch {
      imageFile = null;
    }
  }
  const canShareFiles = Boolean(imageFile && navigator.canShare?.({ files: [imageFile] }));
  if (typeof navigator.share === "function" && (!imageFile || canShareFiles)) {
    await navigator.share({ title: input.productName || "Dental AI Mass", text, ...(imageFile && canShareFiles ? { files: [imageFile] } : {}) });
    return "native" as const;
  }
  await navigator.clipboard?.writeText(text);
  if (input.mediaUrl) {
    const link = document.createElement("a");
    link.href = input.mediaUrl;
    link.download = `${(input.productName || "san-pham").replace(/[^a-z0-9\\u00C0-\\u024F]+/gi, "-")}.jpg`;
    link.target = "_blank";
    link.rel = "noreferrer";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  window.location.href = "zalo://";
  window.setTimeout(() => {
    if (document.visibilityState === "visible") window.location.href = "https://id.zalo.me/";
  }, 1400);
  return "fallback" as const;
}

async function shareToTikTokNative(input: { script: string; landingUrl?: string | null; mediaUrl?: string | null; productName?: string | null; sourceId?: number | string }) {
  const payload = createTikTokPublisherPayload(input);
  let mediaFile: File | null = null;
  if (payload.mediaUrl) {
    try {
      const response = await fetch(payload.mediaUrl, { credentials: "omit" });
      if (!response.ok) throw new Error("Không tải được media TikTok");
      const blob = await response.blob();
      const extension = blob.type.includes("video") ? "mp4" : "jpg";
      mediaFile = new File([blob], `dental-ai-tiktok-${payload.sourceId || "media"}.${extension}`, { type: blob.type || (extension === "mp4" ? "video/mp4" : "image/jpeg") });
    } catch {
      mediaFile = null;
    }
  }
  const canShareMedia = Boolean(mediaFile && navigator.canShare?.({ files: [mediaFile] }));
  if (typeof navigator.share === "function" && (!mediaFile || canShareMedia)) {
    await navigator.share({ title: payload.productName || "Dental AI Mass", text: payload.content, ...(mediaFile && canShareMedia ? { files: [mediaFile] } : {}) });
    return "native" as const;
  }
  await navigator.clipboard?.writeText(payload.content);
  if (payload.mediaUrl) {
    const link = document.createElement("a");
    link.href = payload.mediaUrl;
    link.download = `dental-ai-tiktok-${payload.sourceId || "media"}`;
    link.target = "_blank";
    link.rel = "noreferrer";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  window.location.href = "snssdk1180://share";
  window.setTimeout(() => {
    if (document.visibilityState === "visible") window.location.href = "tiktok://camera";
  }, 900);
  window.setTimeout(() => {
    if (document.visibilityState === "visible") window.location.href = "https://www.tiktok.com/";
  }, 1800);
  return "fallback" as const;
}

async function mobileAssistedPublish(platform: string, content: string, mediaUrl?: string | null) {
  await navigator.clipboard?.writeText(content);
  if (mediaUrl) {
    const link = document.createElement("a");
    link.href = mediaUrl;
    link.download = `dental-ai-${platform}-media`;
    link.target = "_blank";
    link.rel = "noreferrer";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  const deepLinks: Record<string, string> = {
    facebook: "fb://page",
    tiktok: "snssdk1233://",
    zalo: "zalo://",
  };
  const fallback: Record<string, string> = {
    facebook: "https://www.facebook.com/",
    tiktok: "https://www.tiktok.com/",
    zalo: "https://id.zalo.me/",
  };
  const target = deepLinks[platform] || fallback[platform];
  let returned = false;
  const onVisibility = () => { returned = true; };
  document.addEventListener("visibilitychange", onVisibility, { once: true });
  window.location.href = target;
  window.setTimeout(() => {
    document.removeEventListener("visibilitychange", onVisibility);
    if (!returned && document.visibilityState === "visible") window.location.href = fallback[platform];
  }, 1500);
}

export default function Home() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [includeDemo, setIncludeDemo] = useState(false); // Mặc định chỉ xem dữ liệu thật hoặc tách bạch
  const [dealerOrderCodeInput, setDealerOrderCodeInput] = useState("");
  const [trackedOrderResult, setTrackedOrderResult] = useState<any>(null);
  const [dealerTrackLoading, setDealerTrackLoading] = useState(false);
  const [videoGenerationMode, setVideoGenerationMode] = useState<"self_generated" | "reference_adapted">("self_generated");
  const [videoCreativeBrief, setVideoCreativeBrief] = useState("");
  const [videoReferenceUrl, setVideoReferenceUrl] = useState("");
  const [videoSearchKeyword, setVideoSearchKeyword] = useState("");



  // Queries
  const { data: kpiData, refetch: refetchKPI } = trpc.zeroTouch.getKPIDashboard.useQuery({ includeDemo });
  const { data: products = [], refetch: refetchProducts } = trpc.zeroTouch.getProducts.useQuery({ includeInactive: true });
  const operationalProducts = products.filter((product) => product.isActive !== false && product.verificationStatus === "verified_real");
  const catalogSourceQuery = trpc.zeroTouch.getProductCatalogSource.useQuery();
  const syncProductsMutation = trpc.zeroTouch.syncProductsFromSheet.useMutation({
    onSuccess: (res) => {
      toast.success(`Đã đồng bộ ${res.productCount} sản phẩm từ Website 24sevenhc.com.vn.`);
      refetchProducts();
      catalogSourceQuery.refetch();
      orderDraftQuery.refetch();
    },
    onError: (error) => toast.error(`Không thể đồng bộ catalogue: ${error.message}`),
  });
  const { data: agents = [], refetch: refetchAgents } = trpc.zeroTouch.getAgents.useQuery();
  const { data: orders = [], refetch: refetchOrders } = trpc.zeroTouch.getOrders.useQuery({ includeDemo });
  const { data: agentLogs = [], refetch: refetchLogs } = trpc.zeroTouch.getAgentLogs.useQuery();
  const { data: morningReport, refetch: refetchMorningReport } = trpc.zeroTouch.getCeoMorningReport.useQuery();
  const marketIntelQuery = trpc.zeroTouch.getLatestMarketIntelligence.useQuery();
  const socialRuntimeQuery = trpc.zeroTouch.getSocialRuntimeMode.useQuery();
  const runMarketIntelMutation = trpc.zeroTouch.runMarketIntelligence.useMutation({
    onSuccess: (res: any) => {
      toast.success(res.message);
      marketIntelQuery.refetch();
    }
  });

  // Mutations
  const initMutation = trpc.zeroTouch.initData.useMutation({
    onSuccess: (res) => {
      toast.success(res.message);
      refetchAll();
    }
  });

  const resetDemoMutation = trpc.zeroTouch.resetDemoData.useMutation({
    onSuccess: (res) => {
      toast.success(res.message);
      refetchAll();
    },
    onError: (err) => {
      toast.error("Lỗi reset: " + err.message);
    }
  });

  const createOrderMutation = trpc.zeroTouch.createOrder.useMutation({
    onSuccess: () => {
      toast.success("Đã tạo đơn hàng thực tế thành công qua AI Sales Pipeline!");
      refetchAll();
      setNewOrderModal(false);
    }
  });

  const updateStatusMutation = trpc.zeroTouch.updateOrderStatus.useMutation({
    onSuccess: () => {
      toast.success("Đã cập nhật trạng thái đơn hàng thành công!");
      refetchAll();
    }
  });

  const approveProposalMutation = trpc.zeroTouch.approveCeoProposal.useMutation({
    onSuccess: () => {
      toast.success("Đã ghi nhận phản hồi kiểm duyệt đề xuất của AI CEO!");
      refetchMorningReport();
      refetchLogs();
    }
  });

  const updateAutoApprovalModeMutation = trpc.zeroTouch.updateCeoAutoApprovalMode.useMutation({
    onSuccess: () => {
      refetchMorningReport();
      refetchLogs();
    }
  });

  const runDecisionEngineMutation = trpc.zeroTouch.runCeoDecisionEngine.useMutation({
    onSuccess: () => {
      refetchMorningReport();
      refetchLogs();
    }
  });

  const autonomousRoutineMutation = trpc.zeroTouch.triggerAutonomousCeoRoutine.useMutation({
    onSuccess: (res) => {
      toast.success(res.message);
      refetchMorningReport();
      refetchLogs();
    },
    onError: (err) => {
      toast.error("Lỗi chạy tự động: " + err.message);
    }
  });

  const ceoRulesQuery = trpc.zeroTouch.getCeoRules.useQuery();
  const updateRuleMutation = trpc.zeroTouch.updateCeoRuleStatus.useMutation({
    onSuccess: () => {
      toast.success("Đã cập nhật trạng thái bộ quy tắc AI CEO!");
      ceoRulesQuery.refetch();
    }
  });

  // AI Sales Close Order Draft Hooks
  const [salesSessionId] = useState(() => `session-${Date.now()}`);
  const orderDraftQuery = trpc.zeroTouch.getOrCreateOrderDraft.useQuery({ sessionId: salesSessionId });
  const updateDraftMutation = trpc.zeroTouch.updateOrderDraft.useMutation({
    onSuccess: () => {
      orderDraftQuery.refetch();
    }
  });
  const confirmDraftMutation = trpc.zeroTouch.confirmAndCommitSalesOrder.useMutation({
    onSuccess: (res) => {
      toast.success(`Đã chốt thành công đơn hàng ${res.orderCode}! Tự động chuyển sang Kho và Kế toán.`);
      refetchAll();
      orderDraftQuery.refetch();
    }
  });

  const updateRuleDetailsMutation = trpc.zeroTouch.updateCeoRuleDetails.useMutation({
    onSuccess: () => {
      toast.success("Đã cập nhật nội dung quy tắc AI CEO!");
      ceoRulesQuery.refetch();
    }
  });

  const chatMutation = trpc.zeroTouch.chatWithAgent.useMutation();
  const marketingMutation = trpc.zeroTouch.generateMarketingContent.useMutation();
  const updatePromptMutation = trpc.zeroTouch.updateAgentPrompt.useMutation({
    onSuccess: () => {
      toast.success("Đã cập nhật System Prompt cho Agent thành công!");
      refetchAgents();
    }
  });

  // Partner Negotiation Queries & Mutations
  const partnerNegQuery = trpc.zeroTouch.getPartnerNegotiations.useQuery();
  const startNegMutation = trpc.zeroTouch.startPartnerNegotiation.useMutation({
    onSuccess: () => {
      toast.success("AI CEO đã khởi tạo phiên đàm phán thành công!");
      partnerNegQuery.refetch();
    }
  });
  const advanceNegMutation = trpc.zeroTouch.advanceNegotiationRound.useMutation({
    onSuccess: (res: any) => {
      toast.success(res.message);
      partnerNegQuery.refetch();
    }
  });
  const approveNegMutation = trpc.zeroTouch.approvePartnerNegotiation.useMutation({
    onSuccess: (res: any) => {
      toast.success(res.message);
      partnerNegQuery.refetch();
    }
  });

  // AI Video Cleanup Mutation & Product Sync/Toggle
  const cleanupAiVideosMutation = trpc.zeroTouch.cleanupAiVideos.useMutation();
  const syncSheetMutation = trpc.zeroTouch.syncProductsFromSheet.useMutation();
  const toggleProductMutation = trpc.zeroTouch.toggleProductStatus.useMutation();
  const updatePriceMutation = trpc.zeroTouch.updateProductPrice.useMutation();
  const approveProductPriceMutation = trpc.zeroTouch.approveProductPrice.useMutation();

  // Marketing Queries & Mutations
  const utils = trpc.useUtils();
  const marketingResearchQuery = trpc.zeroTouch.getMarketingResearch.useQuery();
  const generateResearchMutation = trpc.zeroTouch.generateMarketingResearch.useMutation();
  const fbZaloQueuesQuery = trpc.zeroTouch.getFbZaloQueues.useQuery();
  const createQueueMutation = trpc.zeroTouch.createFbZaloQueue.useMutation();
  const updateQueueStatusMutation = trpc.zeroTouch.updateFbZaloStatus.useMutation();
  const startSocialOAuthMutation = trpc.zeroTouch.startSocialOAuth.useMutation();
  const publishApprovedContentMutation = trpc.zeroTouch.publishApprovedContent.useMutation({
    onSuccess: (result) => {
      toast.success(`Đã đăng bài thành công: ${result.externalUrl}`);
      utils.zeroTouch.getFbZaloQueues.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });
  const tiktokAssetsQuery = trpc.zeroTouch.getTiktokAssets.useQuery();
  const createTiktokAssetMutation = trpc.zeroTouch.createTiktokAsset.useMutation();
  const updateTiktokAssetStatusMutation = trpc.zeroTouch.updateTiktokAssetStatus.useMutation();
  const tiktokVideosQuery = trpc.zeroTouch.getTiktokVideos.useQuery();
  const generateTiktokVideoMutation = trpc.zeroTouch.generateTiktokVideo.useMutation();

  // State for Individual Agent Chats (Mỗi Agent có form chat riêng biệt)
  const [agentInputs, setAgentInputs] = useState<Record<string, string>>({
    ceo: "",
    marketing: "",
    sales: "",
    warehouse: "",
    accountant: ""
  });

  const [agentHistories, setAgentHistories] = useState<Record<string, Array<{role: 'user' | 'assistant', content: string}>>>({
    ceo: [{ role: 'assistant', content: 'Kính chào Chủ đại lý! Tôi là AI CEO. Vào lúc 08:00 sáng mỗi ngày, tôi luôn sẵn sàng báo cáo tình hình và đưa ra đề xuất để anh/chị kiểm duyệt.' }],
    marketing: [{ role: 'assistant', content: 'Xin chào! Tôi là AI Marketing. Tôi luôn sẵn sàng nhận yêu cầu từ ngài để sinh nội dung quảng cáo Facebook, Zalo, TikTok cho 12 sản phẩm nha khoa.' }],
    sales: [{ role: 'assistant', content: 'Xin chào! Tôi là AI Sales. Hãy giao khách hàng hoặc yêu cầu tư vấn kỹ thuật, tôi sẽ hỗ trợ chốt đơn và chuyển sang Kho Hệ Thống Tự Động.' }],
    warehouse: [{ role: 'assistant', content: 'Xin chào! Tôi là AI Kho phụ trách trung tâm Hệ Thống Tự Động. Tôi giám sát tồn kho 12 sản phẩm và tiến độ xuất đơn.' }],
    accountant: [{ role: 'assistant', content: 'Xin chào! Tôi là AI Kế toán. Tôi ghi nhận doanh số thực tế từng ngày, phân tách Vật tư / Thiết bị và tính hoa hồng minh bạch.' }],
  });

  // State for Partner Negotiation Modal & Input
  const [newNegModal, setNewNegModal] = useState(false);
  const [negPartnerName, setNegPartnerName] = useState("");
  const [negPartnerType, setNegPartnerType] = useState("Nhà cung cấp vật tư");
  const [negObjective, setNegObjective] = useState("");
  const [partnerInputs, setPartnerInputs] = useState<Record<number, string>>({});

  // State for New Order Modal
  const [newOrderModal, setNewOrderModal] = useState(false);
  const [orderCustName, setOrderCustName] = useState("");
  const [orderCustPhone, setOrderCustPhone] = useState("");
  const [orderCustAddress, setOrderCustAddress] = useState("");
  const [orderNotes, setOrderNotes] = useState("");
  const [selectedProdId, setSelectedProdId] = useState<string>("");
  const [orderQuantity, setOrderQuantity] = useState("1");
  const [cartItems, setCartItems] = useState<Array<{productId: number, code: string, name: string, category: 'material' | 'equipment', price: number, quantity: number}>>([]);
  const [isRealOrder, setIsRealOrder] = useState(true);

  // State for Prompt Editor
  const [editingAgentKey, setEditingAgentKey] = useState("ceo");
  const [promptText, setPromptText] = useState("");

  // State for Marketing Generator
  const [marketingProduct, setMarketingProduct] = useState("");
  const [marketingPlatform, setMarketingPlatform] = useState<"facebook" | "tiktok" | "zalo">("facebook");
  const [marketingResult, setMarketingResult] = useState("");
  const [landingPageUrl, setLandingPageUrl] = useState(() => localStorage.getItem("24seven-landing-page-url") || "https://www.24sevenhc.com.vn/");
  const [socialConnectOpen, setSocialConnectOpen] = useState<string | null>(null);
  const [socialStatus, setSocialStatus] = useState<Record<string, { connected: boolean; externalAccountId?: string; displayName?: string; avatarUrl?: string; scopes?: string[]; missingScopes?: string[] }>>(() => {
    try {
      const parsed = JSON.parse(localStorage.getItem("24seven-social-status") || "{}") as Record<string, { connected: boolean; externalAccountId?: string; displayName?: string; avatarUrl?: string; scopes?: string[]; missingScopes?: string[] }>;
      return Object.fromEntries(Object.entries(parsed).filter(([, value]) => {
        const displayName = typeof value?.displayName === "string" ? value.displayName : "";
        const accountId = typeof value?.externalAccountId === "string" ? value.externalAccountId : "";
        return !displayName.startsWith("Demo ") && !accountId.startsWith("demo-");
      }));
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem("24seven-social-status", JSON.stringify(socialStatus));
  }, [socialStatus]);

  useEffect(() => {
    const applyOAuthResult = (payload: any) => {
      const platform = String(payload?.platform || "");
      if (!socialPlatforms.some(item => item.key === platform)) return;
      if (payload?.success !== true) {
        toast.error(payload?.message || "Nền tảng chưa xác nhận quyền kết nối.");
        return;
      }
      const scopes = Array.isArray(payload.scopes) ? payload.scopes.filter((scope: unknown): scope is string => typeof scope === "string") : [];
      const externalAccountId = typeof payload.externalAccountId === "string" ? payload.externalAccountId : undefined;
      const displayName = typeof payload.displayName === "string" ? payload.displayName : undefined;
      const avatarUrl = typeof payload.avatarUrl === "string" && /^https:\/\//.test(payload.avatarUrl) ? payload.avatarUrl : undefined;
      const missingScopes = getMissingPublishScopes(platform, scopes);
      setSocialStatus(previous => ({ ...previous, [platform]: { connected: true, externalAccountId, displayName, avatarUrl, scopes, missingScopes } }));
      toast.success(`Đã kết nối ${socialPlatforms.find(item => item.key === platform)?.name || platform}.`);
      if (missingScopes.length > 0) toast.warning(`Đã kết nối nhưng còn thiếu quyền đăng bài: ${missingScopes.join(", ")}.`);
      setSocialConnectOpen(null);
    };
    const receiveOAuthResult = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.data?.type !== "social-oauth-result") return;
      applyOAuthResult(event.data);
    };
    window.addEventListener("message", receiveOAuthResult);
    const params = new URLSearchParams(window.location.search);
    if (params.get("social_connected") === "1") {
      applyOAuthResult({
        platform: params.get("social_platform"),
        success: true,
        displayName: params.get("display_name") || undefined,
        avatarUrl: params.get("avatar_url") || undefined,
        scopes: (params.get("scopes") || "").split(",").map(scope => scope.trim()).filter(Boolean),
      });
      window.history.replaceState({}, document.title, `${window.location.pathname}${window.location.hash}`);
    }
    if (params.get("social_error")) toast.error(params.get("social_error"));
    return () => window.removeEventListener("message", receiveOAuthResult);
  }, []);

  useEffect(() => {
    if (products.length === 0) {
      initMutation.mutate();
    }
  }, []);

  const refetchAll = () => {
    refetchKPI();
    refetchProducts();
    refetchAgents();
    refetchOrders();
    refetchLogs();
    refetchMorningReport();
  };

  const handleSendAgentMessage = async (agentKey: string) => {
    const userMsg = agentInputs[agentKey];
    if (!userMsg || !userMsg.trim()) return;

    setAgentInputs({ ...agentInputs, [agentKey]: "" });
    const currentHistory = agentHistories[agentKey] || [];
    const newHistory = [...currentHistory, { role: 'user' as const, content: userMsg }];

    setAgentHistories({
      ...agentHistories,
      [agentKey]: newHistory
    });

    try {
      const res = await chatMutation.mutateAsync({
        agentKey,
        message: userMsg,
        history: currentHistory.map(h => ({ role: h.role, content: h.content }))
      });

      setAgentHistories({
        ...agentHistories,
        [agentKey]: [...newHistory, { role: 'assistant' as const, content: String(res.response) }]
      });
      refetchLogs();
    } catch (err: any) {
      toast.error("Lỗi khi trò chuyện với Agent: " + err.message);
    }
  };

  const handleAddToCart = () => {
    if (!selectedProdId) return;
    const prod = operationalProducts.find(p => p.id.toString() === selectedProdId);
    if (!prod) return;

    const qty = parseInt(orderQuantity) || 1;
    const existingIndex = cartItems.findIndex(i => i.productId === prod.id);

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += qty;
      setCartItems(updated);
    } else {
      setCartItems([...cartItems, {
        productId: prod.id,
        code: prod.code,
        name: prod.name,
        category: prod.category as 'material' | 'equipment',
        price: Number(prod.price),
        quantity: qty
      }]);
    }
    toast.success(`Đã thêm ${prod.name} vào giỏ hàng`);
  };

  const handleSubmitOrder = () => {
    if (!orderCustName || !orderCustPhone || !orderCustAddress || cartItems.length === 0) {
      toast.error("Vui lòng điền đầy đủ thông tin khách hàng và chọn ít nhất 1 sản phẩm!");
      return;
    }

    createOrderMutation.mutate({
      customerName: orderCustName,
      customerPhone: orderCustPhone,
      customerAddress: orderCustAddress,
      items: cartItems,
      notes: orderNotes,
      isRealData: isRealOrder
    });
  };

  const handleGenerateMarketing = async () => {
    if (!marketingProduct) {
      toast.error("Vui lòng chọn sản phẩm cần làm marketing!");
      return;
    }
    const toastId = toast.loading("AI Marketing đang sáng tạo nội dung...");
    try {
      const res = await marketingMutation.mutateAsync({
        productName: marketingProduct,
        platform: marketingPlatform
      });
      setMarketingResult(String(res.content));
      toast.dismiss(toastId);
      toast.success("Đã sinh nội dung marketing thành công!");
    } catch (err: any) {
      toast.dismiss(toastId);
      toast.error("Lỗi sinh nội dung: " + err.message);
    }
  };

  const handleSavePrompt = () => {
    updatePromptMutation.mutate({
      agentKey: editingAgentKey,
      systemPrompt: promptText
    });
  };

  const monthlyRevenue = Number(kpiData?.totalRevenue || 0);
  const todayRevenue = Number(kpiData?.todayRevenue || 0);
  const materialRatio = Number(kpiData?.materialRatio || 0);
  const equipmentRatio = Number(kpiData?.equipmentRatio || 0);
  const revenueTargetData = [
    { name: "Tháng", actual: monthlyRevenue, target: 300000000 },
    { name: "Hôm nay", actual: todayRevenue, target: 10000000 },
  ];
  const revenueMixData = [
    { name: "Vật tư", value: materialRatio, fill: "#2563eb" },
    { name: "Thiết bị", value: equipmentRatio, fill: "#9333ea" },
  ].filter((item) => item.value > 0);
  const orderStatusLabels: Record<string, string> = {
    processing: "Đang xử lý",
    shipping: "Đang giao",
    completed: "Hoàn thành",
    stuck: "Kẹt đơn",
  };
  const orderStatusData = summarizeOrderStatuses(orders as any[]).map(({ status, value }) => ({ name: orderStatusLabels[status] || status, value }));
  const agentActivityData = summarizeAgentActivity(agents as any[], agentLogs as any[]);
  const proposalData = summarizeProposalStatuses((Array.isArray(morningReport?.proposals) ? morningReport.proposals : []) as any[]);


  return (
    <DashboardLayout>
      <div className="space-y-6 pb-12">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-6 rounded-2xl shadow-xl flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Badge className="bg-emerald-500 text-white px-3 py-1 text-xs uppercase tracking-wider font-semibold">Chế độ Hỗ trợ đăng bài (Chuẩn an toàn)</Badge>
              <Badge className="bg-blue-500 text-white px-3 py-1 text-xs">Kho Tổng Đã Đồng Bộ</Badge>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">24 Seven Health Care Vietnam</h1>
            <p className="text-slate-300 text-sm mt-1">Hệ thống Đa tác nhân AI với Lịch báo cáo 08:00 sáng & Form chat độc lập cho từng phòng ban</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700 text-xs">
              <span>Bộ lọc dữ liệu:</span>
              <Switch checked={includeDemo} onCheckedChange={setIncludeDemo} />
            </div>
            <Button onClick={() => initMutation.mutate()} variant="outline" className="border-slate-700 bg-slate-800 text-white hover:bg-slate-700 text-xs">
              <RefreshCw className="w-3.5 h-3.5 mr-1" /> Khởi tạo DB
            </Button>
            <Button onClick={() => {
              if (confirm("⚠️ CẢNH BÁO: Thao tác này sẽ xóa toàn bộ dữ liệu giao dịch tạm, đơn hàng thử, nhật ký đàm phán và báo cáo thử nghiệm để làm sạch hệ thống vận hành. Catalogue 12 sản phẩm và cấu hình Agent vẫn được giữ nguyên. Bạn có chắc chắn muốn RESET?")) {
                resetDemoMutation.mutate();
              }
            }} variant="destructive" className="bg-rose-700 hover:bg-rose-600 text-white font-bold shadow-lg text-xs">
              <Trash2 className="w-3.5 h-3.5 mr-1" /> Reset Vận Hành Thật
            </Button>
            <Button onClick={() => setNewOrderModal(true)} className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-lg text-xs">
              <ShoppingCart className="w-3.5 h-3.5 mr-1" /> Tạo Đơn Thật
            </Button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-2 md:grid-cols-6 h-auto p-1 bg-slate-100 dark:bg-slate-900 rounded-xl">
            <TabsTrigger value="dashboard" className="py-2.5 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 font-medium text-xs">
              <BarChart3 className="w-4 h-4 mr-1 text-blue-600" /> KPI & CEO 08:00
            </TabsTrigger>
            <TabsTrigger value="agents" className="py-2.5 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 font-medium text-xs">
              <Bot className="w-4 h-4 mr-1 text-indigo-600" /> Form Chat 5 Agents
            </TabsTrigger>
            <TabsTrigger value="pipeline" className="py-2.5 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 font-medium text-xs">
              <Truck className="w-4 h-4 mr-1 text-emerald-600" /> Pipeline Đơn Hàng
            </TabsTrigger>
            <TabsTrigger value="warehouse" className="py-2.5 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 font-medium text-xs">
              <Package className="w-4 h-4 mr-1 text-amber-600" /> Kho Sản Phẩm (Đã Đồng Bộ)
            </TabsTrigger>
            <TabsTrigger value="marketing" className="py-2.5 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 font-medium text-xs">
              <Sparkles className="w-4 h-4 mr-1 text-purple-600" /> AI Marketing
            </TabsTrigger>
            <TabsTrigger value="config" className="py-2.5 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800 font-medium text-xs">
              <Settings className="w-4 h-4 mr-1 text-slate-600" /> Cấu hình Prompts
            </TabsTrigger>
          </TabsList>

          {/* TAB 1: DASHBOARD KPI & BÁO CÁO 08:00 SÁNG CỦA CEO */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* TRUNG TÂM ĐIỀU HÀNH & RA QUYẾT ĐỊNH AI CEO (Decision Engine & Tự phê duyệt có điều kiện) */}
            <Card className="border-2 border-indigo-500/30 bg-gradient-to-br from-indigo-50/50 via-white to-blue-50/30 dark:from-slate-900 dark:to-indigo-950/30 shadow-md">
              <CardHeader className="pb-3">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-indigo-600 text-white rounded-xl">
                      <Bot className="w-5 h-5" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">Trung Tâm Điều Hành & Ra Quyết Định AI CEO</CardTitle>
                      <CardDescription>Báo cáo 08:00, Decision Engine tự phê duyệt có điều kiện, nhật ký quyết định và kiểm soát rủi ro</CardDescription>
                    </div>
                  </div>
                  <Badge className={morningReport?.status === 'approved' ? 'bg-emerald-600' : morningReport?.status === 'rejected' ? 'bg-red-600' : 'bg-amber-600'}>
                    {morningReport?.status === 'approved' ? 'Đã phê duyệt' : morningReport?.status === 'rejected' ? 'Đã từ chối' : 'Chờ kiểm duyệt'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* THANH ĐIỀU KHIỂN CHẾ ĐỘ VẬN HÀNH CEO & DECISION ENGINE */}
                <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                      <span>Chế Độ Vận Hành AI CEO:</span>
                      <span className={`px-2.5 py-0.5 rounded text-[11px] font-bold ${morningReport?.autoApprovalMode === 'conditional_auto' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'}`}>
                        {morningReport?.autoApprovalMode === 'conditional_auto' ? '⚡ Tự Động Có Điều Kiện (Conditional Auto)' : '🛡️ Chỉ Thủ Công (Manual Only)'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {morningReport?.autoApprovalMode === 'conditional_auto' 
                        ? 'AI CEO tự động kiểm tra tồn kho Hệ Thống Tự Động, giá niêm yết, chính sách y khoa và tự phê duyệt đề xuất đạt chuẩn.'
                        : 'Mọi đề xuất chiến lược & marketing bắt buộc phải do Chủ đại lý bấm duyệt thủ công (An toàn tuyệt đối).'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Button 
                      size="sm" 
                      className="text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow"
                      onClick={() => {
                        autonomousRoutineMutation.mutate();
                      }}
                    >
                      <Clock className="w-3.5 h-3.5 mr-1" /> Chạy Tác Vụ 08:00 (Autonomous)
                    </Button>
                    <Button size="sm" variant={morningReport?.autoApprovalMode === 'conditional_auto' ? 'default' : 'outline'} className="text-xs font-semibold" onClick={() => {
                      if (!morningReport) return;
                      const newMode = morningReport.autoApprovalMode === 'conditional_auto' ? 'manual_only' : 'conditional_auto';
                      updateAutoApprovalModeMutation.mutate({ reportId: morningReport.id, autoApprovalMode: newMode }, {
                        onSuccess: () => { toast.success(`Đã chuyển chế độ sang: ${newMode === 'conditional_auto' ? 'Tự động có điều kiện' : 'Chỉ thủ công'}`); refetchMorningReport(); }
                      });
                    }}>
                      {morningReport?.autoApprovalMode === 'conditional_auto' ? '🛡️ Chuyển về Thủ Công' : '⚡ Bật Tự Động Có Điều Kiện'}
                    </Button>
                    {morningReport?.autoApprovalMode === 'conditional_auto' && (
                      <Button size="sm" className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow" onClick={() => {
                        if (!morningReport) return;
                        runDecisionEngineMutation.mutate({ reportId: morningReport.id }, {
                          onSuccess: (res: any) => {
                            toast.success(res.message);
                            refetchMorningReport();
                          }
                        });
                      }}>
                        <Sparkles className="w-3.5 h-3.5 mr-1.5" /> Chạy Decision Engine
                      </Button>
                    )}
                  </div>
                </div>

                {/* NỘI DUNG BÁO CÁO 08:00 & NHẬT KÝ QUYẾT ĐỊNH */}
                <div className="space-y-4">
                  <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-2">
                    <h4 className="font-bold text-sm uppercase text-indigo-600 tracking-wide flex items-center gap-1.5">
                      <FileText className="w-4 h-4" /> Tóm Tắt Báo Cáo Điều Hành 08:00 (AI CEO)
                    </h4>
                    <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-7">
                      {morningReport?.reportContent || "Đang tải báo cáo sáng..."}
                    </p>
                  </div>

                  <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-2">
                    <h4 className="font-bold text-sm uppercase text-emerald-600 tracking-wide flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4" /> Nhật Ký Quyết Định Tự Động Của AI CEO
                    </h4>
                    <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                      {Array.isArray(morningReport?.decisionLogs) && morningReport.decisionLogs.length > 0 ? (
                        (morningReport.decisionLogs as any[]).map((log, idx) => (
                          <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                            <div className="flex flex-wrap justify-between gap-2 font-bold text-indigo-600">
                              <span>{log.action}</span>
                              <span className="text-slate-400 font-normal">{log.time}</span>
                            </div>
                            <p className="text-slate-600 dark:text-slate-400 leading-5">{log.reason}</p>
                          </div>
                        ))
                      ) : (
                        <div className="text-xs text-slate-400 italic p-4 bg-slate-50 dark:bg-slate-900 rounded text-center border border-dashed border-slate-200 dark:border-slate-800">
                          Chưa có quyết định tự động nào. Bấm <strong>"Chạy Decision Engine"</strong> để AI CEO thẩm định.
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3 pt-2 border-t border-indigo-100 dark:border-indigo-900">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <h4 className="font-bold text-sm uppercase text-slate-700 dark:text-slate-300 tracking-wide">Bảng vận hành trong ngày</h4>
                      <span className="text-xs text-slate-500">Các đề xuất cần Chủ đại lý kiểm duyệt</span>
                    </div>
                    <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                      {Array.isArray(morningReport?.proposals) && morningReport.proposals.map((prop: any, idx: number) => (
                        <div key={idx} className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-3 shadow-sm text-sm">
                          <span className="font-medium text-slate-800 dark:text-slate-200 leading-6">{prop.title}</span>
                          <div className="flex flex-wrap justify-between items-center gap-2">
                            <span className={`text-xs px-2.5 py-1 rounded font-bold ${prop.status === 'auto_approved' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300' : prop.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                              {prop.status === 'auto_approved' ? '⚡ CEO Đã Tự Duyệt' : prop.status === 'approved' ? '✓ Đã Phê Duyệt' : 'Chờ Kiểm Duyệt'}
                            </span>
                            {prop.status !== 'auto_approved' && prop.status !== 'approved' && (
                              <Button size="sm" className="min-h-9 text-xs bg-emerald-600 hover:bg-emerald-500 text-white" onClick={() => {
                                if (!morningReport) return;
                                approveProposalMutation.mutate({ reportId: morningReport.id, action: 'approve', feedback: `Đã duyệt: ${prop.title}` }, {
                                  onSuccess: () => { toast.success("Đã phê duyệt đề xuất!"); refetchMorningReport(); }
                                });
                              }}>
                                <Check className="w-3.5 h-3.5 mr-1" /> Phê duyệt
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex flex-col sm:flex-row sm:justify-end gap-2 pt-2">
                      <Button onClick={() => {
                        if (!morningReport) return;
                        approveProposalMutation.mutate({ reportId: morningReport.id, action: 'approve', feedback: "Đã phê duyệt toàn bộ đề xuất sáng 08:00." }, {
                          onSuccess: () => { toast.success("Đã phê duyệt toàn bộ!"); refetchMorningReport(); }
                        });
                      }} className="min-h-10 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold">
                        <Check className="w-4 h-4 mr-1" /> Phê Duyệt Toàn Bộ Đề Xuất
                      </Button>
                      <Button variant="outline" onClick={() => {
                        if (!morningReport) return;
                        approveProposalMutation.mutate({ reportId: morningReport.id, action: 'reject', feedback: "Yêu cầu chỉnh sửa lại các đề xuất." }, {
                          onSuccess: () => { toast.success("Đã gửi yêu cầu chỉnh sửa!"); refetchMorningReport(); }
                        });
                      }} className="min-h-10 border-red-200 text-red-600 hover:bg-red-50 text-sm font-bold">
                        <X className="w-4 h-4 mr-1" /> Yêu Cầu Chỉnh Sửa
                      </Button>
                    </div>
                  </div>
                </div>

                {/* GIAO DIỆN QUẢN LÝ BỘ QUY TẮC PHÊ DUYỆT TỰ ĐỘNG (RULE BUILDER CHO AI CEO) */}
                <div className="mt-6 pt-6 border-t border-indigo-100 dark:border-indigo-900 space-y-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        <Settings className="w-4 h-4 text-indigo-600" /> Quản Lý Bộ Quy Tắc Phê Duyệt Tự Động (Decision Engine Rule Builder)
                      </h4>
                      <p className="text-xs text-slate-500">Bật/tắt hoặc điều chỉnh các tiêu chí kiểm duyệt để AI CEO Decision Engine áp dụng khi tự động thẩm định đề xuất.</p>
                    </div>
                    <Badge className="bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 font-bold">
                      {Array.isArray(ceoRulesQuery.data) ? ceoRulesQuery.data.filter((r: any) => r.isEnabled).length : 0} / {Array.isArray(ceoRulesQuery.data) ? ceoRulesQuery.data.length : 0} Quy Tắc Đang Bật
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {Array.isArray(ceoRulesQuery.data) && ceoRulesQuery.data.map((rule: any) => (
                      <div key={rule.id} className="p-3.5 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm flex flex-col justify-between gap-3">
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between gap-2">
                            <input 
                              type="text" 
                              className="font-bold text-xs text-slate-800 dark:text-slate-200 bg-transparent border-b border-transparent hover:border-indigo-300 focus:border-indigo-600 focus:outline-none w-full py-0.5"
                              defaultValue={rule.ruleName}
                              onBlur={(e) => {
                                const newName = e.target.value;
                                if (newName !== rule.ruleName) {
                                  updateRuleDetailsMutation.mutate({ ruleId: rule.id, ruleName: newName, description: rule.description });
                                }
                              }}
                            />
                            <span className={`text-[10px] px-2 py-0.5 rounded font-semibold whitespace-nowrap ${rule.isEnabled ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-900 dark:text-slate-400'}`}>
                              {rule.isEnabled ? 'Đang áp dụng' : 'Đã tắt'}
                            </span>
                          </div>
                          <textarea 
                            className="text-[11px] text-slate-500 dark:text-slate-400 bg-transparent border border-transparent hover:border-indigo-200 focus:border-indigo-600 focus:outline-none w-full rounded p-1 resize-none"
                            rows={2}
                            defaultValue={rule.description}
                            onBlur={(e) => {
                              const newDesc = e.target.value;
                              if (newDesc !== rule.description) {
                                updateRuleDetailsMutation.mutate({ ruleId: rule.id, ruleName: rule.ruleName, description: newDesc });
                              }
                            }}
                          />
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700 text-[10px] text-slate-400">
                          <span>Chỉnh sửa trực tiếp tên/mô tả</span>
                          <Button 
                            size="sm" 
                            variant={rule.isEnabled ? "default" : "outline"}
                            className={`h-6 text-[11px] font-bold px-3 ${rule.isEnabled ? 'bg-indigo-600 hover:bg-indigo-500 text-white' : 'border-slate-300 text-slate-600'}`}
                            onClick={() => {
                              updateRuleMutation.mutate({ ruleId: rule.id, isEnabled: !rule.isEnabled });
                            }}
                          >
                            {rule.isEnabled ? 'Bật' : 'Tắt'}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* DASHBOARD KPI TRỰC QUAN: số liệu thực từ AI CEO và các phòng ban */}
            <section className="space-y-4" aria-labelledby="kpi-dashboard-title">
              <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2">
                <div>
                  <h3 id="kpi-dashboard-title" className="text-xl font-bold text-slate-900 dark:text-slate-100">Dashboard điều hành KPI</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Tổng hợp doanh số, đơn hàng, hoạt động AI và trạng thái phê duyệt theo dữ liệu hệ thống.</p>
                </div>
                <Badge variant="outline" className="w-fit text-xs">Cập nhật theo dữ liệu thực tế</Badge>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
                <Card className="border-l-4 border-l-blue-600 shadow-sm">
                  <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-slate-600">Doanh số tháng</CardTitle></CardHeader>
                  <CardContent><p className="text-2xl font-bold text-blue-700">{monthlyRevenue.toLocaleString("vi-VN")} đ</p><p className="text-sm text-slate-500 mt-1">Mục tiêu 300.000.000 đ</p></CardContent>
                </Card>
                <Card className="border-l-4 border-l-emerald-600 shadow-sm">
                  <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-slate-600">Doanh số hôm nay</CardTitle></CardHeader>
                  <CardContent><p className="text-2xl font-bold text-emerald-700">{todayRevenue.toLocaleString("vi-VN")} đ</p><p className="text-sm text-slate-500 mt-1">KPI ngày 10.000.000 đ</p></CardContent>
                </Card>
                <Card className="border-l-4 border-l-amber-500 shadow-sm">
                  <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-slate-600">Đơn cần xử lý</CardTitle></CardHeader>
                  <CardContent><p className="text-2xl font-bold text-amber-700">{orders.filter((order) => order.status !== "completed").length}</p><p className="text-sm text-slate-500 mt-1">Kẹt trên 24 giờ: {kpiData?.stuckOrdersCount || 0}</p></CardContent>
                </Card>
                <Card className="border-l-4 border-l-purple-600 shadow-sm">
                  <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-slate-600">Agent đang quản lý</CardTitle></CardHeader>
                  <CardContent><p className="text-2xl font-bold text-purple-700">{agents.length}</p><p className="text-sm text-slate-500 mt-1">Lượt tương tác: {agentLogs.length}</p></CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <Card className="shadow-sm min-w-0">
                  <CardHeader><CardTitle className="text-base">Doanh số thực tế so với mục tiêu</CardTitle><CardDescription className="text-sm">AI CEO theo dõi KPI tháng và KPI ngày.</CardDescription></CardHeader>
                  <CardContent className="h-[270px] px-2 sm:px-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={revenueTargetData} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 11 }} tickFormatter={(value) => `${Math.round(Number(value) / 1000000)}tr`} />
                        <Tooltip formatter={(value: any) => [`${Number(value).toLocaleString("vi-VN")} đ`, ""]} />
                        <Legend wrapperStyle={{ fontSize: 12 }} />
                        <Bar dataKey="actual" name="Thực tế" fill="#2563eb" radius={[5, 5, 0, 0]} />
                        <Bar dataKey="target" name="Mục tiêu" fill="#cbd5e1" radius={[5, 5, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="shadow-sm min-w-0">
                  <CardHeader><CardTitle className="text-base">Cơ cấu doanh số</CardTitle><CardDescription className="text-sm">Tỷ trọng vật tư và thiết bị theo đơn hoàn thành.</CardDescription></CardHeader>
                  <CardContent className="h-[270px] px-2 sm:px-6">
                    {revenueMixData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={revenueMixData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={58} outerRadius={88} paddingAngle={3} label={({ name, value }) => `${name}: ${value}%`}>
                            {revenueMixData.map((entry) => <Cell key={entry.name} fill={entry.fill} />)}
                          </Pie>
                          <Tooltip formatter={(value: any) => [`${value}%`, "Tỷ trọng"]} />
                          <Legend wrapperStyle={{ fontSize: 12 }} />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : <div className="h-full flex items-center justify-center text-sm text-slate-500">Chưa có doanh số hoàn thành để phân tích cơ cấu.</div>}
                  </CardContent>
                </Card>

                <Card className="shadow-sm min-w-0">
                  <CardHeader><CardTitle className="text-base">Trạng thái pipeline đơn hàng</CardTitle><CardDescription className="text-sm">Theo dõi liên thông Sales → Kho → Kế toán.</CardDescription></CardHeader>
                  <CardContent className="h-[270px] px-2 sm:px-6">
                    {orderStatusData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={orderStatusData} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
                          <defs><linearGradient id="orderStatusFill" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#10b981" stopOpacity={0.7} /><stop offset="95%" stopColor="#10b981" stopOpacity={0.08} /></linearGradient></defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-12} textAnchor="end" height={48} />
                          <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Area type="monotone" dataKey="value" name="Số đơn" stroke="#059669" fill="url(#orderStatusFill)" strokeWidth={3} />
                        </AreaChart>
                      </ResponsiveContainer>
                    ) : <div className="h-full flex items-center justify-center text-sm text-slate-500">Chưa có đơn hàng để hiển thị.</div>}
                  </CardContent>
                </Card>

                <Card className="shadow-sm min-w-0">
                  <CardHeader><CardTitle className="text-base">Hoạt động các phòng ban AI</CardTitle><CardDescription className="text-sm">Số lượt tương tác đã ghi nhận trong nhật ký hệ thống.</CardDescription></CardHeader>
                  <CardContent className="h-[270px] px-2 sm:px-6">
                    {agentActivityData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={agentActivityData} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
                          <defs><linearGradient id="agentActivityFill" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#7c3aed" stopOpacity={0.7} /><stop offset="95%" stopColor="#7c3aed" stopOpacity={0.08} /></linearGradient></defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={52} />
                          <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                          <Tooltip />
                          <Area type="monotone" dataKey="interactions" name="Lượt tương tác" stroke="#7c3aed" fill="url(#agentActivityFill)" strokeWidth={3} />
                        </AreaChart>
                      </ResponsiveContainer>
                    ) : <div className="h-full flex items-center justify-center text-sm text-slate-500">Chưa có nhật ký tương tác agent.</div>}
                  </CardContent>
                </Card>
              </div>

              <Card className="shadow-sm border-indigo-100 dark:border-indigo-900 min-w-0">
                <CardHeader><CardTitle className="text-base">Tiến độ phê duyệt của AI CEO</CardTitle><CardDescription className="text-sm">Theo dõi đề xuất vận hành trong ngày trước khi xem chi tiết bên dưới.</CardDescription></CardHeader>
                <CardContent className="h-[230px] px-2 sm:px-6">
                  {proposalData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={proposalData} layout="vertical" margin={{ top: 8, right: 20, left: 12, bottom: 8 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                        <YAxis type="category" dataKey="name" width={76} tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="value" name="Số đề xuất" radius={[0, 5, 5, 0]}>{proposalData.map((entry) => <Cell key={entry.name} fill={entry.fill} />)}</Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : <div className="h-full flex items-center justify-center text-sm text-slate-500">Chưa có đề xuất vận hành trong ngày.</div>}
                </CardContent>
              </Card>
            </section>

            {/* AI CEO PARTNER NEGOTIATION ENGINE (Đàm phán đối tác & Tối ưu quyền lợi đại lý) */}
            <Card className="border-2 border-emerald-500/30 bg-gradient-to-br from-emerald-50/40 via-white to-teal-50/20 dark:from-slate-900 dark:to-emerald-950/20 shadow-md mt-6">
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-emerald-600 text-white rounded-xl">
                      <Briefcase className="w-5 h-5" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">AI CEO - Đại Diện Đàm Phán Đối Tác & Tối Ưu Quyền Lợi Đại Lý</CardTitle>
                      <CardDescription>AI CEO phối hợp với Seven Healthcare đàm phán nhà cung cấp/đối tác nha khoa, tối ưu quyền lợi đại lý và trình người dùng phê duyệt</CardDescription>
                    </div>
                  </div>
                  <Button onClick={() => setNewNegModal(true)} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow">
                    <Plus className="w-4 h-4 mr-1.5" /> Khởi Tạo Phiên Đàm Phán Mới
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Array.isArray(partnerNegQuery.data) && partnerNegQuery.data.length > 0 ? (
                    partnerNegQuery.data.map((neg: any) => {
                      let terms: string[] = [];
                      try { terms = JSON.parse(neg.proposedTerms || "[]"); } catch(e) { terms = []; }
                      let logs: any[] = [];
                      try { logs = JSON.parse(neg.negotiationLogs || "[]"); } catch(e) { logs = []; }
                      const inputVal = partnerInputs[neg.id] || "";

                      return (
                        <div key={neg.id} className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-emerald-200 dark:border-emerald-900 shadow-sm space-y-3 flex flex-col justify-between">
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">{neg.partnerName}</h4>
                                <span className="text-[11px] text-slate-500">Loại: {neg.partnerType} | Mục tiêu: {neg.objective}</span>
                              </div>
                              <Badge className={neg.status === 'approved' ? 'bg-emerald-600' : neg.status === 'pending_owner_approval' ? 'bg-amber-600' : 'bg-blue-600'}>
                                {neg.status === 'approved' ? 'Đã Chốt & Phê Duyệt' : neg.status === 'pending_owner_approval' ? 'Chờ Bạn Phê Duyệt' : 'Đang Đàm Phán'}
                              </Badge>
                            </div>

                            <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                              <span className="font-bold text-emerald-600 uppercase text-[10px]">Chiến lược AI CEO:</span>
                              <p className="text-slate-700 dark:text-slate-300">{neg.aiStrategy}</p>
                            </div>

                            <div className="space-y-1">
                              <span className="font-bold text-slate-700 dark:text-slate-300 text-xs">Các điều khoản đề xuất tối ưu:</span>
                              <div className="flex flex-wrap gap-1">
                                {terms.map((t: string, idx: number) => (
                                  <Badge key={idx} variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300">
                                    {t}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>

                          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                            {neg.status === 'pending_owner_approval' && (
                              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-lg border border-amber-200 dark:border-amber-800 space-y-2">
                                <span className="font-bold text-xs text-amber-700 dark:text-amber-300 flex items-center gap-1">
                                  <ShieldCheck className="w-3.5 h-3.5" /> Bản chốt quyền lợi cao nhất chờ phê duyệt:
                                </span>
                                <p className="text-xs text-slate-700 dark:text-slate-300">{neg.bestBenefits}</p>
                                <div className="flex gap-2 pt-1">
                                  <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs h-7 flex-1" onClick={() => {
                                    approveNegMutation.mutate({ negotiationId: neg.id, action: 'approve', feedback: "Phê duyệt điều khoản chốt lợi ích cao nhất." });
                                  }}>
                                    <Check className="w-3 h-3 mr-1" /> Phê Duyệt Bản Chốt
                                  </Button>
                                  <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50 text-xs h-7" onClick={() => {
                                    approveNegMutation.mutate({ negotiationId: neg.id, action: 'request_revision', feedback: "Yêu cầu đàm phán thêm chiết khấu." });
                                  }}>
                                    <X className="w-3 h-3 mr-1" /> Yêu Cầu Sửa
                                  </Button>
                                </div>
                              </div>
                            )}

                            {neg.status === 'negotiating' && (
                              <div className="space-y-2">
                                <div className="flex gap-1.5">
                                  <Input 
                                    className="text-xs h-8"
                                    placeholder="Nhập phản hồi của đối tác (VD: Đối tác đồng ý chiết khấu 22%)..."
                                    value={inputVal}
                                    onChange={(e) => setPartnerInputs({ ...partnerInputs, [neg.id]: e.target.value })}
                                  />
                                  <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500 text-xs h-8 px-3" onClick={() => {
                                    if (!inputVal.trim()) return;
                                    advanceNegMutation.mutate({ negotiationId: neg.id, partnerResponse: inputVal });
                                    setPartnerInputs({ ...partnerInputs, [neg.id]: "" });
                                  }}>
                                    <Send className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                            )}

                            <div className="text-[11px] text-slate-500 max-h-[80px] overflow-y-auto space-y-1">
                              <span className="font-semibold text-slate-600">Nhật ký đàm phán:</span>
                              {logs.map((l: any, i: number) => (
                                <div key={i} className="text-[10px] text-slate-500">
                                  <strong className="text-slate-700">{l.actor}</strong> ({l.time}): {l.action}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="col-span-2 text-center py-8 text-xs text-slate-400 italic bg-white dark:bg-slate-800 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                      Chưa có phiên đàm phán đối tác nào. Bấm <strong>"Khởi Tạo Phiên Đàm Phán Mới"</strong> để AI CEO phối hợp cùng Seven Healthcare làm việc với đối tác.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TAB 2: FORM CHAT RIÊNG BIỆT CHO TỪNG AGENT */}
          <TabsContent value="agents" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              {[
                { key: 'ceo', name: 'AI CEO', icon: Building2, desc: 'Báo cáo 08:00 sáng & Kiểm duyệt' },
                { key: 'marketing', name: 'AI Marketing', icon: Sparkles, desc: 'Sáng tạo content 12 sản phẩm' },
                { key: 'warehouse', name: 'AI Kho', icon: Package, desc: 'Kho Hệ Thống Tự Động & xuất đơn' },
                { key: 'accountant', name: 'AI Kế toán', icon: FileText, desc: 'Doanh số thực tế & hoa hồng' },
              ].map((ag) => {
                const Icon = ag.icon;
                const history = agentHistories[ag.key] || [];
                const inputValue = agentInputs[ag.key] || "";

                return (
                  <Card key={ag.key} className="shadow-sm flex flex-col justify-between border-slate-200 dark:border-slate-800">
                    <CardHeader className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                      <div className="flex items-center gap-2">
                        <div className="p-2 bg-blue-600 text-white rounded-lg">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <CardTitle className="text-sm font-bold">{ag.name}</CardTitle>
                          <CardDescription className="text-[11px]">{ag.desc}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-3 flex-1 flex flex-col justify-between space-y-3">
                      <div className="bg-slate-50 dark:bg-slate-900 p-2.5 rounded-xl h-64 overflow-y-auto space-y-2 text-xs">
                        {history.map((m, idx) => (
                          <div key={idx} className={`p-2 rounded-lg ${m.role === 'user' ? 'bg-blue-600 text-white ml-4' : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 mr-4 border border-slate-200 dark:border-slate-700'}`}>
                            {m.content}
                          </div>
                        ))}
                      </div>

                      <div className="flex gap-1.5 pt-2">
                        <Input 
                          placeholder={`Nhập yêu cầu cho ${ag.name}...`} 
                          value={inputValue}
                          onChange={(e) => setAgentInputs({ ...agentInputs, [ag.key]: e.target.value })}
                          onKeyDown={(e) => e.key === 'Enter' && handleSendAgentMessage(ag.key)}
                          className="text-xs h-9"
                        />
                        <Button onClick={() => handleSendAgentMessage(ag.key)} className="bg-blue-600 hover:bg-blue-500 h-9 px-3">
                          <Send className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {/* AI Sales Chuyên biệt quy trình chốt đơn thực tế */}
              <Card className="shadow-sm flex flex-col justify-between border-2 border-blue-500 dark:border-blue-600 bg-blue-50/20">
                <CardHeader className="p-4 border-b border-blue-100 dark:border-blue-900 bg-blue-600 text-white rounded-t-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-white text-blue-600 rounded-lg">
                        <PhoneCall className="w-4 h-4" />
                      </div>
                      <div>
                        <CardTitle className="text-sm font-bold">AI Sales (Quy Trình Chốt Đơn)</CardTitle>
                        <CardDescription className="text-[11px] text-blue-100">Tư vấn catalogue & tạo đơn nháp</CardDescription>
                      </div>
                    </div>
                    <Badge className="bg-emerald-500 text-white text-[10px]">Active Pipeline</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-3 flex-1 flex flex-col justify-between space-y-3">
                  <div className="rounded-xl border border-blue-200 bg-blue-50/70 dark:border-blue-900 dark:bg-blue-950/30 p-2.5 text-[10px]">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-semibold text-blue-900 dark:text-blue-100">Nguồn catalogue AI Sales</div>
                        <div className="truncate text-blue-700/80 dark:text-blue-200/80">Website 24sevenhc.com.vn · {catalogSourceQuery.data?.productCount || 0} sản phẩm · {catalogSourceQuery.data?.lastSyncedAt ? new Date(catalogSourceQuery.data.lastSyncedAt).toLocaleString('vi-VN') : 'chưa đồng bộ'}</div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 shrink-0 border-blue-300 bg-white text-[10px] text-blue-700 hover:bg-blue-100 dark:bg-slate-900 dark:text-blue-200"
                        disabled={syncProductsMutation.isPending}
                        onClick={() => syncProductsMutation.mutate()}
                      >
                        <RefreshCw className={`mr-1 h-3 w-3 ${syncProductsMutation.isPending ? 'animate-spin' : ''}`} />
                        {syncProductsMutation.isPending ? 'Đang đồng bộ' : 'Đồng bộ Sheet'}
                      </Button>
                    </div>
                    <a href={catalogSourceQuery.data?.sourceUrl || 'https://docs.google.com/spreadsheets/d/19WB-7Lf8rzG9vYcqW_1-ZN0SB_VT0AlT0QP8H1pRzgE/edit?usp=sharing'} target="_blank" rel="noreferrer" className="mt-1 inline-block text-blue-600 underline underline-offset-2 dark:text-blue-300">Mở bảng sản phẩm gốc</a>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-3 rounded-xl h-64 overflow-y-auto space-y-3 text-xs border border-blue-100 dark:border-slate-800">
                    <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200 border border-blue-200 dark:border-blue-900">
                      <strong>AI Sales:</strong> Chào bác sĩ/phòng khám! Tôi là AI Sales của 24 Seven Health Care. Hãy chọn sản phẩm từ catalogue Website 24sevenhc.com.vn đang hoạt động, kiểm tra đặc tính và giá, điền đủ thông tin khách hàng rồi bấm <strong>"Xác Nhận Chốt Đơn"</strong> sau khi đã xác nhận tổng tiền để chuyển sang Kho Sản Phẩm (Đã Đồng Bộ) và Kế toán.
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                      <div className="font-semibold text-slate-700 dark:text-slate-300">1. Thông tin khách hàng:</div>
                      <Input 
                        placeholder="Tên phòng khám / Bác sĩ..."
                        value={orderDraftQuery.data?.customerName || ""}
                        onChange={(e) => updateDraftMutation.mutate({ sessionId: salesSessionId, customerName: e.target.value })}
                        className="text-xs h-8"
                      />
                      <Input 
                        placeholder="Số điện thoại liên hệ..."
                        value={orderDraftQuery.data?.customerPhone || ""}
                        onChange={(e) => updateDraftMutation.mutate({ sessionId: salesSessionId, customerPhone: e.target.value })}
                        className="text-xs h-8"
                      />
                      <Input 
                        placeholder="Địa chỉ giao hàng (mặc định Hệ Thống Tự Động xuất đi)..."
                        value={orderDraftQuery.data?.customerAddress || ""}
                        onChange={(e) => updateDraftMutation.mutate({ sessionId: salesSessionId, customerAddress: e.target.value })}
                        className="text-xs h-8"
                      />
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                      <div className="font-semibold text-slate-700 dark:text-slate-300">2. Chọn sản phẩm từ catalogue ({operationalProducts.length} sản phẩm hợp lệ):</div>
                      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                        {operationalProducts.map((p) => {
                          const currentItems = (orderDraftQuery.data?.items as any[]) || [];
                          const existing = currentItems.find(i => i.productId === p.id);
                          const qty = existing ? existing.quantity : 0;

                          return (
                            <div key={p.id} className="flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-1.5 rounded border border-slate-200 dark:border-slate-700 text-[11px]">
                              <div className="truncate flex-1 pr-2">
                                <div className="font-medium truncate">{p.name}</div>
                                <div className="text-[10px] text-slate-500">{Number(p.price).toLocaleString()} đ ({p.category === 'material' ? 'Vật tư' : 'Thiết bị'}) · Sẵn sàng / Theo đơn</div>
                                <div className="text-[10px] text-slate-400 line-clamp-2" title={p.description || undefined}>{p.description || 'Chưa có đặc tính trong catalogue'}</div>
                              </div>
                              <div className="flex items-center gap-1">
                                {qty > 0 ? (
                                  <>
                                    <span className="font-bold text-blue-600 px-1">{qty}</span>
                                    <Button 
                                      size="sm" 
                                      variant="outline" 
                                      className="h-6 w-6 p-0 text-xs"
                                      onClick={() => {
                                        const updated = currentItems.map(i => i.productId === p.id ? { ...i, quantity: Math.max(0, i.quantity - 1) } : i).filter(i => i.quantity > 0);
                                        updateDraftMutation.mutate({ sessionId: salesSessionId, items: updated });
                                      }}
                                    >-</Button>
                                    <Button 
                                      size="sm" 
                                      variant="outline" 
                                      className="h-6 w-6 p-0 text-xs"
                                      onClick={() => {
                                        const updated = currentItems.map(i => i.productId === p.id ? { ...i, quantity: i.quantity + 1 } : i);
                                        updateDraftMutation.mutate({ sessionId: salesSessionId, items: updated });
                                      }}
                                    >+</Button>
                                  </>
                                ) : (
                                  <Button 
                                    size="sm" 
                                    className="h-6 px-2 text-[10px] bg-blue-600 hover:bg-blue-500 text-white"
                                    onClick={() => {
                                      const newItem = {
                                        productId: p.id,
                                        code: p.code,
                                        name: p.name,
                                        category: p.category,
                                        price: Number(p.price),
                                        quantity: 1
                                      };
                                      const updated = [...currentItems, newItem];
                                      updateDraftMutation.mutate({ sessionId: salesSessionId, items: updated });
                                    }}
                                  >Thêm</Button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                    <div className="flex justify-between items-center text-xs font-bold">
                      <span>Tổng tiền đơn nháp:</span>
                      <span className="text-blue-600 text-sm">{Number(orderDraftQuery.data?.totalAmount || 0).toLocaleString()} VNĐ</span>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs h-9 font-semibold"
                        disabled={confirmDraftMutation.isPending || !orderDraftQuery.data?.customerName || !orderDraftQuery.data?.customerPhone || !orderDraftQuery.data?.customerAddress || !orderDraftQuery.data?.items || (orderDraftQuery.data.items as any[]).length === 0}
                        onClick={() => confirmDraftMutation.mutate({ sessionId: salesSessionId })}
                      >
                        {confirmDraftMutation.isPending ? "Đang chốt đơn..." : "Xác Nhận Chốt Đơn (Tự Động Đẩy Kho & Kế Toán)"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* TAB 3: PIPELINE ĐƠN HÀNG */}
          <TabsContent value="pipeline" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold">Pipeline Đơn Hàng (Thật & Nội Bộ)</h3>
                <p className="text-xs text-slate-500">Sales → Kho Sản Phẩm (Đã Đồng Bộ) → Kế toán | Phân biệt dữ liệu thực tế và dữ liệu nội bộ</p>
              </div>
              <Button onClick={() => setNewOrderModal(true)} className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs">
                <ShoppingCart className="w-3.5 h-3.5 mr-1" /> Tạo Đơn Hàng Thật
              </Button>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
              <Table>
                <TableHeader className="bg-slate-50 dark:bg-slate-800/50">
                  <TableRow>
                    <TableHead>Mã Đơn</TableHead>
                    <TableHead>Phân Loại</TableHead>
                    <TableHead>Khách Hàng</TableHead>
                    <TableHead>Sản Phẩm</TableHead>
                    <TableHead>Tổng Tiền (VNĐ)</TableHead>
                    <TableHead>Trạng Thái</TableHead>
                    <TableHead>Thời Gian</TableHead>
                    <TableHead className="text-right">Thao Tác</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                        Chưa có đơn hàng nào. Hãy bấm "Tạo Đơn Hàng Thật" để kiểm tra pipeline.
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((o) => (
                      <TableRow key={o.id}>
                        <TableCell className="font-bold text-blue-600">{o.orderCode}</TableCell>
                        <TableCell>
                          {o.isRealData ? (
                            <Badge className="bg-emerald-600 text-white text-[10px]">Đơn Thật</Badge>
                          ) : (
                            <Badge variant="outline" className="text-slate-500 text-[10px]">Nội bộ</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{o.customerName}</div>
                          <div className="text-xs text-slate-500">{o.customerPhone}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-xs max-w-xs truncate">
                            {Array.isArray(o.items) && o.items.map((i: any, idx: number) => (
                              <div key={idx}>{i.name} (x{i.quantity})</div>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="font-bold text-emerald-600">{Number(o.totalAmount).toLocaleString()} đ</TableCell>
                        <TableCell>
                          {o.status === 'processing' && <Badge variant="secondary" className="bg-amber-100 text-amber-700">Đang xử lý (Kho 17 PV)</Badge>}
                          {o.status === 'shipping' && <Badge variant="secondary" className="bg-purple-100 text-purple-700">Đang giao</Badge>}
                          {o.status === 'completed' && <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">Hoàn thành</Badge>}
                          {o.status === 'stuck' && <Badge variant="destructive">Kẹt đơn</Badge>}
                        </TableCell>
                        <TableCell className="text-xs text-slate-500">
                          {new Date(o.createdAt).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-right space-x-1">
                          {o.status !== 'completed' && (
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => updateStatusMutation.mutate({ orderId: o.id, status: 'completed', paymentStatus: 'paid' })}
                              className="text-[11px] h-7 text-emerald-600 border-emerald-300 hover:bg-emerald-50"
                            >
                              Duyệt Xong
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          {/* TAB 4: KHO 17 PHẠM VẤN & QUẢN LÝ DANH MỤC SẢN PHẨM */}
          <TabsContent value="warehouse" className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-blue-50 dark:bg-slate-900 p-4 rounded-xl border border-blue-100 dark:border-blue-900">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Kho Sản Phẩm Tổng Hợp & Danh Mục Website</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">Đồng bộ trực tiếp từ website 24sevenhc, quản lý trạng thái bật/tắt kinh doanh cho AI Sales & AI Marketing.</p>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  onClick={() => {
                    syncProductsMutation.mutate(undefined);
                  }}
                  disabled={syncProductsMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm"
                >
                  <RefreshCw className={`w-4 h-4 mr-1.5 ${syncProductsMutation.isPending ? "animate-spin" : ""}`} />
                  {syncProductsMutation.isPending ? "Đang cập nhật từ trang chủ..." : "Cập nhật / Đồng bộ sản phẩm từ trang chủ"}
                </Button>
                <Badge className="bg-blue-600 text-white text-xs py-1.5 px-3">Hệ Thống Tự Động</Badge>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {products.map((p) => (
                <Card key={p.id} className={`shadow-sm flex flex-col justify-between border-slate-200 dark:border-slate-800 transition-all ${p.isActive === false ? 'opacity-60 bg-slate-50 dark:bg-slate-900/50' : ''}`}>
                  <CardHeader className="p-4 pb-2">
                    <div className="flex justify-between items-start">
                      <Badge variant="outline" className="text-xs font-mono">{p.code}</Badge>
                      <div className="flex items-center gap-2">
                        <Badge className={p.category === 'material' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}>
                          {p.category === 'material' ? 'Vật tư' : 'Thiết bị'}
                        </Badge>
                        <Badge variant="outline" className={p.verificationStatus === "verified_real" ? "text-emerald-700 border-emerald-300" : "text-amber-700 border-amber-300"}>
                          {p.verificationStatus === "verified_real" ? "Đã xác minh" : "Chưa xác minh"}
                        </Badge>
                      </div>
                    </div>
                    <CardTitle className="text-base font-bold mt-2 line-clamp-2">{p.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0 space-y-3">
                    <p className="text-xs text-slate-500 line-clamp-2">{p.description}</p>
                    <div className="flex justify-between items-center pt-2 border-t border-slate-100 dark:border-slate-800">
                      <div>
                        <div className="text-xs text-slate-400">Đơn giá (Sửa trực tiếp & Enter/Blur để lưu)</div>
                        <div className="flex items-center gap-1 mt-0.5">
                          <input
                            type="text"
                            defaultValue={Number(p.price || 0).toLocaleString('vi-VN')}
                            onFocus={(e) => {
                              // Khi bấm vào ô nhập, hiển thị số thô để dễ sửa
                              e.target.value = p.price || "";
                            }}
                            onBlur={(e) => {
                              const rawVal = e.target.value;
                              const cleanPrice = rawVal.replace(/[^0-9]/g, "");
                              // Hiển thị lại định dạng chuẩn ngay lập tức trên input
                              e.target.value = cleanPrice ? Number(cleanPrice).toLocaleString('vi-VN') : "0";
                              if (cleanPrice && cleanPrice !== p.price) {
                                updatePriceMutation.mutate({ productId: p.id, price: cleanPrice }, {
                                  onSuccess: () => {
                                    toast.success(`Đã tự động lưu giá mới: ${Number(cleanPrice).toLocaleString('vi-VN')} đ`);
                                    refetchProducts();
                                  },
                                  onError: (err: any) => {
                                    toast.error("Lỗi lưu giá: " + err.message);
                                  }
                                });
                              }
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                (e.target as HTMLInputElement).blur();
                              }
                            }}
                            className="w-36 px-2 py-1 text-sm font-extrabold text-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800 rounded focus:outline-none focus:ring-2 focus:ring-emerald-500"
                            title="Nhập giá mới và nhấn Enter hoặc bấm ra ngoài để tự động lưu ngay lập tức"
                          />
                          <span className="text-xs font-semibold text-slate-500">đ</span>
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className="mt-1 h-6 px-2 text-[10px] border-emerald-300 text-emerald-700"
                          disabled={approveProductPriceMutation.isPending || Number(p.price || 0) <= 0}
                          onClick={() => approveProductPriceMutation.mutate({ productId: p.id, approvedPrice: String(p.price || 0) }, {
                            onSuccess: () => toast.success(`Chủ đại lý đã duyệt giá ${Number(p.price || 0).toLocaleString('vi-VN')} đ cho ${p.name}.`),
                            onError: (err: any) => toast.error("Lỗi duyệt giá: " + err.message),
                          })}
                        >
                          {approveProductPriceMutation.isPending ? "Đang duyệt..." : "Chủ đại lý duyệt giá"}
                        </Button>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <div className="text-right">
                          <div className="text-xs text-slate-400">Trạng thái</div>
                          <div className={`text-xs font-semibold ${p.isActive !== false ? 'text-emerald-600' : 'text-amber-600'}`}>
                            {p.isActive !== false ? 'Đang kinh doanh' : 'Tạm ngưng'}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-600 dark:text-slate-400">Kinh doanh (AI Bật/Tắt)</span>
                      <Switch
                        checked={p.isActive !== false}
                        onCheckedChange={(checked) => {
                          toggleProductMutation.mutate({ id: p.id, isActive: checked }, {
                            onSuccess: () => {
                              toast.success(`Đã cập nhật trạng thái sản phẩm ${p.name}!`);
                              refetchProducts();
                            },
                            onError: (err: any) => {
                              toast.error("Lỗi cập nhật: " + err.message);
                            }
                          });
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* TAB 5: AI MARKETING & ĐIỀU PHỐI ĐA KÊNH CÓ KIỂM DUYỆT */}
          <TabsContent value="marketing" className="space-y-6">
            {/* MARKET INTELLIGENCE ENGINE (DÙNG CHUNG CHO CEO & MARKETING) */}
            <Card className="shadow-sm border-indigo-200 dark:border-indigo-900 bg-gradient-to-r from-indigo-50/50 via-purple-50/50 to-blue-50/50 dark:from-slate-900 dark:to-slate-900">
              <CardHeader className="pb-3">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <CardTitle className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                      <Globe className="w-5 h-5 text-indigo-600" /> Market Intelligence Engine (Thu Thập Đa Nguồn & Phân Tích Chiến Lược)
                    </CardTitle>
                    <CardDescription className="text-xs text-slate-600 dark:text-slate-400">
                      Tự động đọc productCatalog, tạo keyword, quét Google, Facebook, TikTok, đối thủ & marketplace, chấm điểm và phân tích chiến lược.
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => {
                      runMarketIntelMutation.mutate(undefined, {
                        onSuccess: (res: any) => {
                          toast.success(res.message);
                          utils.zeroTouch.getLatestMarketIntelligence.invalidate();
                        }
                      });
                    }}
                    disabled={runMarketIntelMutation.isPending}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shrink-0"
                  >
                    <Sparkles className="w-4 h-4 mr-1.5" /> {runMarketIntelMutation.isPending ? "Đang Quét & Phân Tích..." : "Chạy Market Intelligence Ngay"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4 pt-0">
                {marketIntelQuery.isLoading ? (
                  <div className="text-center py-6 text-xs text-slate-500">Đang tải dữ liệu Market Intelligence...</div>
                ) : !marketIntelQuery.data ? (
                  <div className="p-6 bg-white dark:bg-slate-800 rounded-xl border border-dashed border-indigo-200 dark:border-indigo-800 text-center space-y-2">
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">Chưa có báo cáo Market Intelligence nào được chạy hôm nay.</p>
                    <p className="text-[11px] text-slate-400">Bấm nút "Chạy Market Intelligence Ngay" để hệ thống tự động quét tín hiệu thị trường thực tế.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-1">
                        <div className="font-bold text-indigo-600 flex items-center gap-1">🔥 Chủ Đề Đang Tăng</div>
                        <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-600 dark:text-slate-300">
                          {Array.isArray(marketIntelQuery.data.trendingTopics) && marketIntelQuery.data.trendingTopics.map((t: string, idx: number) => (
                            <li key={idx}>{t}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-1">
                        <div className="font-bold text-purple-600 flex items-center gap-1">🏆 Đối Thủ Đang Đẩy</div>
                        <div className="space-y-1 text-[11px] text-slate-600 dark:text-slate-300">
                          {Array.isArray(marketIntelQuery.data.competitorActions) && marketIntelQuery.data.competitorActions.map((c: any, idx: number) => (
                            <div key={idx} className="border-b border-slate-100 dark:border-slate-700 pb-1">
                              <strong>{c.competitor}</strong>: {c.action} ({c.product})
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-1">
                        <div className="font-bold text-blue-600 flex items-center gap-1">📈 Ý Định Mua Nổi Bật</div>
                        <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-600 dark:text-slate-300">
                          {Array.isArray(marketIntelQuery.data.buyerIntents) && marketIntelQuery.data.buyerIntents.map((b: string, idx: number) => (
                            <li key={idx}>{b}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-1">
                        <div className="font-bold text-emerald-600 flex items-center gap-1">💡 Sản Phẩm Đẩy Hôm Nay</div>
                        <div className="space-y-1 text-[11px] text-slate-600 dark:text-slate-300">
                          {Array.isArray(marketIntelQuery.data.recommendedProductsToday) && marketIntelQuery.data.recommendedProductsToday.map((p: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-center bg-emerald-50 dark:bg-emerald-950/40 p-1 rounded">
                              <span className="font-bold text-emerald-700 dark:text-emerald-300 truncate max-w-[130px]">{p.productName}</span>
                              <span className="bg-emerald-600 text-white px-1.5 py-0.2 rounded text-[10px]">Score {p.score}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* CHI TIẾT KẾ HOẠCH HÔM NAY & PHÂN TÍCH KẾT QUẢ HÔM QUA */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      <div className="p-3.5 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 space-y-2">
                        <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                          <Target className="w-4 h-4 text-indigo-600" /> Kế Hoạch Nội Dung & Khung Giờ Đăng Đề Xuất
                        </div>
                        <div className="space-y-1 text-slate-600 dark:text-slate-300 text-[11px]">
                          <div><strong>Khách hàng mục tiêu:</strong> {marketIntelQuery.data.targetAudience}</div>
                          <div><strong>Phân tích kết quả hôm qua:</strong> {marketIntelQuery.data.yesterdayResultAnalysis}</div>
                        </div>
                      </div>

                      <div className="p-3.5 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-indigo-900 space-y-2">
                        <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                          <Video className="w-4 h-4 text-purple-600" /> Chủ Đề TikTok Livestream & Khung Giờ Vàng
                        </div>
                        <div className="space-y-1 text-[11px]">
                          <div className="flex flex-wrap gap-1">
                            {Array.isArray(marketIntelQuery.data.tiktokLivestreamTopics) && marketIntelQuery.data.tiktokLivestreamTopics.map((top: string, idx: number) => (
                              <span key={idx} className="bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded-full font-medium">🎥 {top}</span>
                            ))}
                          </div>
                          <div className="pt-1 text-slate-500">
                            <strong>Khung giờ vàng:</strong> {Array.isArray(marketIntelQuery.data.optimalPostingTimes) && marketIntelQuery.data.optimalPostingTimes.map((t: any) => `${t.platform} (${t.timeSlot})`).join(" | ")}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* HIỂN THỊ NGUỒN TÍN HIỆU ĐÃ THU THẬP (100% LIVE DATA, KHÔNG CÒN HIỂN THỊ TRẠNG THÁI GIẢ) */}
                    <div className="pt-2 border-t border-indigo-100 dark:border-indigo-900 text-xs space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Nguồn Tín Hiệu Đã Thu Thập & Xác Thực Đa Nguồn ({marketIntelQuery.data.rawSignalsCount} nguồn)
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                          ✅ Đã xác thực thực tế (Verified Real-Time)
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {Array.isArray(marketIntelQuery.data.signalsData) && marketIntelQuery.data.signalsData.map((sig: any, idx: number) => (
                          <div key={idx} className="p-2 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 space-y-1">
                            <div className="flex justify-between items-center text-[11px]">
                              <span className="font-bold text-indigo-600">📌 {sig.source}</span>
                              <span className="text-[9px] text-slate-400">{new Date(sig.timestamp).toLocaleTimeString()}</span>
                            </div>
                            <a href={sig.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline font-medium text-[11px] block truncate">
                              🔗 {sig.title}
                            </a>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 italic line-clamp-1">{sig.snippet}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* CỘT 1: NGHIÊN CỨU THỊ TRƯỜNG & ĐỀ XUẤT CEO */}
              <Card className="shadow-sm border-purple-200 dark:border-purple-900">
                <CardHeader className="bg-purple-50 dark:bg-purple-950/30">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Search className="w-4 h-4 text-purple-600" /> Nghiên Cứu Thị Trường & Đề Xuất CEO
                  </CardTitle>
                  <CardDescription className="text-xs">Phân tích xu hướng nha khoa & trình AI CEO phê duyệt</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-4">
                  <Button onClick={() => {
                    generateResearchMutation.mutate(undefined, {
                      onSuccess: (res: any) => {
                        toast.success(res.message);
                        utils.zeroTouch.getMarketingResearch.invalidate();
                      }
                    });
                  }} className="w-full bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold py-2.5">
                    <Sparkles className="w-3.5 h-3.5 mr-1.5" /> Chạy Nghiên Cứu Thị Trường Trong Ngày
                  </Button>

                  <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                    {marketingResearchQuery.data?.map((rep: any) => (
                      <div key={rep.id} className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                        <div className="flex justify-between items-center text-[10px] text-slate-400">
                          <span>Ngày: {rep.reportDate}</span>
                          <span className={`px-1.5 py-0.5 rounded font-bold ${rep.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                            {rep.status === 'approved' ? 'CEO Đã Duyệt' : 'Chờ CEO Duyệt'}
                          </span>
                        </div>
                        <div><strong className="text-slate-700 dark:text-slate-300">Xu hướng:</strong> {rep.marketTrends}</div>
                        <div><strong className="text-slate-700 dark:text-slate-300">Đối thủ:</strong> {rep.competitorInsights}</div>
                        <div>
                          <strong className="text-slate-700 dark:text-slate-300">Đề xuất chiến lược:</strong>
                          <ul className="list-disc pl-4 mt-1 space-y-1">
                            {Array.isArray(rep.strategicProposals) && rep.strategicProposals.map((prop: any, idx: number) => (
                              <li key={idx}><strong>{prop.title}</strong> ({prop.platform}): {prop.contentSnippet}</li>
                            ))}
                          </ul>
                        </div>
                        {/* HIỂN THỊ NGUỒN BẰNG CHỨNG (EVIDENCE-FIRST) CHỐNG ẢO HÓA */}
                        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 space-y-1">
                          <div className="flex items-center justify-between font-semibold text-slate-600 dark:text-slate-400">
                            <span>Nguồn bằng chứng xác thực:</span>
                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                              ⚠️ Phân tích chưa xác minh (Chưa quét web thực)
                            </span>
                          </div>
                          {Array.isArray(rep.evidenceSources) && rep.evidenceSources.map((src: any, sIdx: number) => (
                            <div key={sIdx} className="p-1.5 bg-white dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700 space-y-0.5">
                              <div className="flex justify-between items-center">
                                <a href={src.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline font-medium truncate max-w-[200px]">
                                  🔗 {src.title}
                                </a>
                                <span className="text-[9px] text-slate-400">Thu thập: {new Date(src.scrapedAt).toLocaleDateString()}</span>
                              </div>
                              <p className="text-[10px] text-slate-600 dark:text-slate-300 italic">{src.snippet}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* CỘT 2: HÀNG ĐỢI ĐĂNG BÀI FACEBOOK & ZALO */}
              <Card className="shadow-sm border-blue-200 dark:border-blue-900">
                <CardHeader className="bg-blue-50 dark:bg-blue-950/30">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Share2 className="w-4 h-4 text-blue-600" /> Hàng Đợi Facebook & Zalo OA
                  </CardTitle>
                  <CardDescription className="text-xs">Tạo lịch đăng content cho 12 sản phẩm cố định</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 pt-4">
                  <div className="space-y-2">
                    <label className="text-[11px] font-medium">Sản phẩm:</label>
                    <Select value={marketingProduct} onValueChange={setMarketingProduct}>
                      <SelectTrigger className="text-xs"><SelectValue placeholder="Chọn sản phẩm" /></SelectTrigger>
                      <SelectContent>
                        {operationalProducts.map(p => (<SelectItem key={p.id} value={p.name} className="text-xs">{p.name}</SelectItem>))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium">Trang đích Mục 07:</label>
                    <Input value={landingPageUrl} onChange={(event) => { setLandingPageUrl(event.target.value); localStorage.setItem("24seven-landing-page-url", event.target.value); }} placeholder="https://..." className="text-xs h-8" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium">Nền tảng:</label>
                      <Select value={marketingPlatform} onValueChange={(v: any) => setMarketingPlatform(v)}>
                        <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="facebook" className="text-xs">Facebook</SelectItem>
                          <SelectItem value="zalo" className="text-xs">Zalo OA</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium">Giờ đăng:</label>
                      <Input placeholder="09:00 Sáng" className="text-xs h-8" id="queue-time" defaultValue="09:00 Hằng ngày" />
                    </div>
                  </div>
                  <Button onClick={async () => {
                    if (!socialStatus[marketingPlatform]?.connected) {
                      toast.error(`Chưa kết nối ${marketingPlatform.toUpperCase()}. Hãy kết nối tài khoản trước khi đưa nội dung vào lịch đăng.`);
                      setSocialConnectOpen(marketingPlatform);
                      return;
                    }
                    const timeInput = (document.getElementById('queue-time') as HTMLInputElement)?.value || "09:00";
                    const targetProd = operationalProducts.find(p => p.name === marketingProduct) || operationalProducts[0];
                    if (!targetProd) {
                      toast.error("Chưa có sản phẩm hợp lệ để tạo nội dung.");
                      return;
                    }

                    const toastId = toast.loading("AI Marketing đang tạo nội dung từ catalogue thực...");
                    try {
                      const generated = await marketingMutation.mutateAsync({
                        productName: targetProd.name,
                        platform: marketingPlatform,
                      });
                      const content = generated.content?.trim();
                      if (!content || content.startsWith("Lỗi sinh nội dung:")) {
                        throw new Error(content || "AI chưa trả về nội dung hợp lệ.");
                      }
                      await createQueueMutation.mutateAsync({
                        productId: targetProd.id,
                        productName: targetProd.name,
                        platform: marketingPlatform as any,
                        content,
                        scheduledTime: timeInput,
                      });
                      toast.dismiss(toastId);
                      toast.success("Đã tạo nội dung thật và đưa vào hàng đợi chờ CEO duyệt.");
                      utils.zeroTouch.getFbZaloQueues.invalidate();
                    } catch (err: any) {
                      toast.dismiss(toastId);
                      toast.error(err?.message || "AI Marketing chưa tạo được nội dung.");
                    }
                  }} disabled={marketingMutation.isPending || createQueueMutation.isPending} className="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold py-2">
                    {marketingMutation.isPending ? "AI Marketing đang viết..." : "Sinh Content & Đưa Vào Hàng Đợi"}
                  </Button>

                  <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                    {fbZaloQueuesQuery.data?.map((q: any) => (
                      <div key={q.id} className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                        <div className="flex justify-between font-bold">
                          <span>{q.productName} ({q.platform.toUpperCase()})</span>
                          <span className="text-[10px] text-blue-600">{q.scheduledTime}</span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-400 line-clamp-2 text-[11px]">{q.content}</p>
                        <div className="flex justify-between items-center pt-1 text-[10px]">
                          <span className="text-amber-600 font-semibold">{q.status}</span>
                          <div className="flex gap-1">
                            {q.status === 'approved_ready' && q.platform === 'facebook' && <Button size="sm" variant="ghost" className="h-7 text-[10px] text-indigo-700" onClick={async () => {
                              try {
                                await prepareFacebookBrowserPublish({ content: q.content, landingUrl: landingPageUrl, mediaUrl: q.mediaUrl || q.imageUrl || null, productName: q.productName, sourceId: q.id });
                                toast.success("Đã sao chép nội dung + link và mở Facebook. Hãy dán, kiểm tra ảnh rồi bấm Đăng.");
                              } catch (error: any) {
                                toast.error(error?.message || "Không thể mở Facebook hoặc sao chép nội dung.");
                              }
                            }}><Share2 className="w-3 h-3 mr-1" />Đăng lên Facebook</Button>}
                            {q.status === 'approved_ready' && q.platform === 'zalo' && isMobileDevice() && <Button size="sm" variant="ghost" className="h-7 text-[10px] text-sky-700" onClick={async () => {
                              try {
                                const method = await shareToZaloNative({ content: q.content, landingUrl: landingPageUrl, mediaUrl: q.mediaUrl || q.imageUrl || null, productName: q.productName });
                                toast.success(method === "native" ? "Đã mở menu chia sẻ hệ thống. Chọn Zalo → Đăng lên Nhật ký, kiểm tra rồi bấm Đăng." : "Đã sao chép nội dung + link và mở Zalo. Sale dán nội dung, chọn ảnh rồi bấm Đăng.");
                              } catch (error: any) {
                                if (error?.name !== "AbortError") toast.error(error?.message || "Không thể chia sẻ sang Zalo trên thiết bị này.");
                              }
                            }}><Share2 className="w-3 h-3 mr-1" />Đăng lên Zalo</Button>}
                            {q.status === 'approved_ready' && q.platform !== 'zalo' && isMobileDevice() && <Button size="sm" variant="ghost" className="h-7 text-[10px] text-emerald-700" onClick={async () => {
                              try {
                                await mobileAssistedPublish(q.platform, q.content, q.mediaUrl || q.imageUrl || q.videoUrl);
                                toast.success("Đã sao chép nội dung và mở ứng dụng. Sale kiểm tra, dán/tải ảnh rồi bấm Đăng.");
                              } catch {
                                toast.error("Không thể sao chép nội dung trên thiết bị này.");
                              }
                            }}><Smartphone className="w-3 h-3 mr-1" />Đăng bằng điện thoại</Button>}
                            {q.status === 'approved_ready' && <Button size="sm" variant="ghost" className="h-6 text-[10px] text-blue-700" disabled={publishApprovedContentMutation.isPending} onClick={() => {
                              const targetId = socialStatus[q.platform]?.externalAccountId;
                              if (!targetId) { toast.error(`Chưa có tài khoản ${q.platform} Business hợp lệ để đăng.`); return; }
                              publishApprovedContentMutation.mutate({ sourceType: 'fb_zalo_queue', sourceId: q.id, platform: q.platform, content: q.content, targetId });
                            }}>Đăng ngay</Button>}
                            {q.status !== 'approved_ready' && <Button size="sm" variant="ghost" className="h-6 text-[10px]" onClick={() => {
                              updateQueueStatusMutation.mutate({ id: q.id, status: 'approved_ready' }, {
                                onSuccess: () => { toast.success("Đã duyệt sẵn sàng đăng!"); utils.zeroTouch.getFbZaloQueues.invalidate(); }
                              });
                            }}>Duyệt Đăng</Button>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* CỘT 3: AI VIDEO STUDIO - HAI CHẾ ĐỘ TẠO NỘI DUNG */}
              <Card className="shadow-sm border-rose-200 dark:border-rose-900">
                <CardHeader className="bg-rose-50 dark:bg-rose-950/30">
                  <CardTitle className="text-sm flex items-center justify-between">
                    <span className="flex items-center gap-2"><Video className="w-4 h-4 text-rose-600" /> AI Video Studio (TikTok & Reels)</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-2 py-0.5 rounded-full font-medium">Dịch vụ AI Tự động quản lý</span>
                  </CardTitle>
                  <CardDescription className="text-xs">AI Agent tự động kết nối dịch vụ Veo/Provider, tạo nội dung chuẩn catalogue; chủ đại lý không cần cấu hình API.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 pt-4">
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium">Sản phẩm:</label>
                    <Select value={marketingProduct} onValueChange={setMarketingProduct}>
                      <SelectTrigger className="text-xs"><SelectValue placeholder="Chọn sản phẩm" /></SelectTrigger>
                      <SelectContent>
                        {operationalProducts.map(p => (<SelectItem key={p.id} value={p.name} className="text-xs">{p.name}</SelectItem>))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button type="button" variant={videoGenerationMode === "self_generated" ? "default" : "outline"} className={`h-auto min-h-14 px-2 text-[11px] leading-tight ${videoGenerationMode === "self_generated" ? "bg-rose-600 hover:bg-rose-500 text-white" : "border-rose-200 text-rose-700"}`} onClick={() => setVideoGenerationMode("self_generated")}>
                      <Sparkles className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                      <span className="text-left"><strong className="block">Tự tạo video mới</strong><span className="opacity-80">Từ thông tin sản phẩm</span></span>
                    </Button>
                    <Button type="button" variant={videoGenerationMode === "reference_adapted" ? "default" : "outline"} className={`h-auto min-h-14 px-2 text-[11px] leading-tight ${videoGenerationMode === "reference_adapted" ? "bg-rose-600 hover:bg-rose-500 text-white" : "border-rose-200 text-rose-700"}`} onClick={() => setVideoGenerationMode("reference_adapted")}>
                      <RefreshCw className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                      <span className="text-left"><strong className="block">Chỉnh lại từ tham khảo</strong><span className="opacity-80">Không sao chép nguyên bản</span></span>
                    </Button>
                  </div>

                  {videoGenerationMode === "reference_adapted" && (
                    <div className="space-y-2 rounded-lg border border-amber-200 bg-amber-50/70 p-2.5 dark:border-amber-900 dark:bg-amber-950/20">
                      <p className="text-[11px] text-amber-800 dark:text-amber-200">Tìm video công khai phù hợp, chọn một video rồi dán link vào ô dưới. AI chỉ học ý tưởng và tạo lại cảnh, câu chữ, giọng đọc cùng nhận diện riêng của sản phẩm và đơn vị phân phối.</p>
                      <div className="flex gap-2">
                        <Input value={videoSearchKeyword} onChange={(e) => setVideoSearchKeyword(e.target.value)} placeholder="Từ khóa, ví dụ: dental collagen plug" className="h-8 text-xs" />
                        <Button type="button" variant="outline" className="h-8 shrink-0 text-xs border-amber-300" onClick={() => {
                          const keyword = videoSearchKeyword.trim() || marketingProduct || "dental product";
                          window.open(`https://www.tiktok.com/search?q=${encodeURIComponent(keyword)}`, "_blank", "noopener,noreferrer");
                        }}><Search className="w-3.5 h-3.5 mr-1" /> Tìm video</Button>
                      </div>
                      <Input value={videoReferenceUrl} onChange={(e) => setVideoReferenceUrl(e.target.value)} placeholder="Dán link TikTok/video công khai làm tham khảo" className="h-8 text-xs" />
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-[11px] font-medium">Yêu cầu riêng cho video (không bắt buộc):</label>
                    <Textarea value={videoCreativeBrief} onChange={(e) => setVideoCreativeBrief(e.target.value)} placeholder="Ví dụ: hook 3 giây đầu, nhấn mạnh ứng dụng lâm sàng, CTA Zalo..." className="min-h-16 text-xs" />
                  </div>

                  <Button onClick={() => {
                    const targetProd = operationalProducts.find(p => p.name === marketingProduct) || operationalProducts[0];
                    if (!targetProd) return;
                    generateTiktokVideoMutation.mutate({
                      productId: targetProd.id,
                      generationMode: videoGenerationMode,
                      creativeBrief: videoCreativeBrief.trim() || undefined,
                      referenceVideoUrl: videoGenerationMode === "reference_adapted" ? videoReferenceUrl.trim() || undefined : undefined,
                      searchKeyword: videoGenerationMode === "reference_adapted" ? videoSearchKeyword.trim() || undefined : undefined,
                    }, {
                      onSuccess: (res: any) => {
                        toast.success(res.message || "AI Agent đã tự động tạo nội dung video!");
                        utils.zeroTouch.getTiktokVideos.invalidate();
                      },
                      onError: (err: any) => toast.error(err.message || "Lỗi tạo nội dung video"),
                    });
                  }} disabled={generateTiktokVideoMutation.isPending} className="w-full bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold py-2">
                    {generateTiktokVideoMutation.isPending ? "AI Agent đang tạo video MP4..." : videoGenerationMode === "reference_adapted" ? "Tạo video mới từ tham khảo" : "Tự tạo video mới từ sản phẩm"}
                  </Button>

                  <div className="flex justify-between items-center gap-2 pt-1 pb-1">
                      <span className="text-[11px] text-slate-500">Lưu trữ video tự động</span>
                      <Button variant="outline" size="sm" className="h-7 text-[11px] border-rose-300 text-rose-700 hover:bg-rose-50" onClick={() => {
                        if (window.confirm("Bạn có chắc muốn dọn dẹp các video AI cũ hơn 7 ngày để giải phóng dung lượng lưu trữ không?")) {
                          cleanupAiVideosMutation.mutate({ retentionDays: 7 }, {
                            onSuccess: (res: any) => {
                              toast.success(res.message);
                              utils.zeroTouch.getTiktokVideos.invalidate();
                            },
                            onError: (err: any) => toast.error(err.message || "Lỗi dọn dẹp video"),
                          });
                        }
                      }}>
                        <Trash2 className="w-3.5 h-3.5 mr-1" /> Dọn dẹp video cũ (&gt;7 ngày)
                      </Button>
                    </div>

                    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                      {tiktokVideosQuery.data?.map((vid: any) => (
                      <div key={vid.id} className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded border border-rose-200 dark:border-rose-900 text-xs space-y-1.5">
                        <div className="flex justify-between items-center gap-2 font-bold">
                          <span className="text-rose-700 dark:text-rose-400">{vid.productName}</span>
                          <span className="px-1.5 py-0.5 rounded text-[9px] bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                            {vid.generationMode === "reference_adapted" ? "Tham khảo → tạo mới" : "Tự tạo mới"}
                          </span>
                        </div>
                        <div className="flex justify-between items-center gap-2">
                          <div className="font-semibold text-slate-800 dark:text-slate-200">{vid.videoTitle}</div>
                          <span className={`px-1.5 py-0.5 rounded text-[9px] ${vid.videoUrl ? 'bg-emerald-100 text-emerald-700' : vid.generationStatus === 'reference_review_required' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>
                            {vid.videoUrl ? 'Video AI đã sẵn sàng' : vid.generationStatus === 'provider_pending' ? 'AI đang tạo file MP4' : vid.generationStatus === 'reference_review_required' ? 'Đang rà soát tham khảo' : 'AI đang tự động xử lý'}
                          </span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-400 text-[11px] line-clamp-3 bg-white dark:bg-slate-800 p-1.5 rounded border whitespace-pre-line">{vid.script}</p>
                        <div className="space-y-2 pt-1">
                          {vid.videoUrl ? (
                            <div className="space-y-1.5 rounded-lg overflow-hidden border border-rose-200 bg-black/5 p-1">
                              <video src={vid.videoUrl} controls preload="metadata" className="w-full max-h-40 rounded object-cover" />
                              <div className="flex justify-between items-center px-1 text-[10px] text-slate-600 dark:text-slate-300 font-semibold">
                                <span>Video MP4 do AI Agent tạo</span>
                                <a href={vid.videoUrl} target="_blank" rel="noreferrer" className="text-rose-600 hover:underline flex items-center gap-1">Mở rộng <Play className="w-2.5 h-2.5" /></a>
                              </div>
                            </div>
                          ) : (
                            <span className="text-slate-500 flex items-center gap-1 text-[11px]"><FileText className="w-3 h-3" /> {vid.generationStatus === "provider_pending" ? "AI Agent đang tạo file MP4; chủ đại lý không cần duyệt storyboard" : vid.generationStatus === "reference_review_required" ? "AI đang hoàn thiện biến đổi độc lập từ video tham khảo" : "AI Agent đang tự động tạo video; chưa có file MP4 để phát"}</span>
                          )}
                          {vid.referenceVideoUrl && <div className="text-right"><a href={vid.referenceVideoUrl} target="_blank" rel="noreferrer" className="text-amber-700 hover:underline text-[11px]">🔗 Mở video tham khảo</a></div>}
                          {vid.videoUrl && vid.approvalStatus === "approved" && isMobileDevice() && <Button size="sm" variant="outline" className="w-full h-8 text-[10px] border-sky-300 text-sky-700" onClick={async () => {
                            try {
                              const method = await shareToTikTokNative({ script: vid.script, landingUrl: landingPageUrl, mediaUrl: vid.videoUrl, productName: vid.productName, sourceId: vid.id });
                              toast.success(method === "native" ? "Đã mở menu chia sẻ. Chọn TikTok → tải video, kiểm tra Caption rồi bấm Đăng." : "Đã tải Video & copy Caption! TikTok đã mở màn hình (+), bạn chỉ cần chọn Video vừa tải và bấm dán Caption.");
                            } catch (error: any) {
                              if (error?.name !== "AbortError") toast.error(error?.message || "Không thể chia sẻ video sang TikTok trên thiết bị này.");
                            }
                          }}><Share2 className="w-3 h-3 mr-1" />Đăng lên TikTok</Button>}
                        </div>
                        {!vid.videoUrl && vid.generationStatus !== 'reference_review_required' && (
                          <p className="rounded border border-blue-200 bg-blue-50 px-2 py-1 text-[10px] text-blue-700 dark:border-blue-900 dark:bg-blue-950/30 dark:text-blue-300">AI Agent đã tự động xử lý nội dung theo catalogue; không cần duyệt storyboard trung gian.</p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* TAB 6: CẤU HÌNH SYSTEM PROMPTS */}
          <TabsContent value="config" className="space-y-6">
            <Card className="shadow-sm border-indigo-200 dark:border-indigo-900 bg-gradient-to-br from-indigo-50/70 via-white to-slate-50 dark:from-slate-900 dark:via-slate-900 dark:to-indigo-950/30">
              <CardHeader className="pb-3">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <Share2 className="h-5 w-5 text-indigo-600" /> Kết nối mạng xã hội của Chủ đại lý
                    </CardTitle>
                    <CardDescription className="mt-1 text-xs sm:text-sm">
                      Kết nối tài khoản cá nhân theo nguyên tắc 1-click. Chủ đại lý chỉ bấm “Kết nối”; hệ thống tự chuyển tới trang cấp quyền chính thức.
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="w-fit border-emerald-300 bg-emerald-50 text-emerald-700 text-[11px]">
                    Tài khoản cá nhân
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                  {socialPlatforms.map((platform) => {
                    const status = socialStatus[platform.key];
                    return (
                      <div key={platform.key} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                        <div className="flex items-start gap-3">
                          <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg font-black text-white ${platform.color}`} aria-hidden="true">{platform.mark}</div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <h4 className="truncate text-sm font-bold text-slate-900 dark:text-slate-100">{platform.name}</h4>
                              <Badge variant="outline" className={`shrink-0 text-[10px] ${status?.connected ? "border-emerald-300 text-emerald-700" : "border-slate-300 text-slate-500"}`}>
                                {status?.connected ? "Đã kết nối" : "Chưa kết nối"}
                              </Badge>
                            </div>
                            <p className="mt-2 min-h-[52px] text-xs leading-5 text-slate-500 dark:text-slate-400">Dành cho Sale - Bấm kết nối để mở tài khoản thật trên trang chính thức; AI chuẩn bị nội dung, Sale kiểm tra và tự bấm Đăng.</p>
                            {status?.connected && <div className="mt-2 flex items-center gap-2">
                              {status.avatarUrl ? <img src={status.avatarUrl} alt="" className="h-7 w-7 rounded-full object-cover ring-1 ring-emerald-200" referrerPolicy="no-referrer" /> : <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-100 text-[10px] font-bold text-emerald-700">{(status.displayName || "TK").slice(0, 2).toUpperCase()}</div>}
                              <p className="truncate text-[11px] font-semibold text-emerald-700">{status.displayName || "Tài khoản đã xác nhận"}</p>
                            </div>}
                            {status?.connected && status.missingScopes && status.missingScopes.length > 0 && <p className="mt-2 rounded-md bg-amber-50 px-2 py-1 text-[10px] leading-4 text-amber-800">Yêu cầu cấp thêm quyền đăng bài: {status.missingScopes.join(", ")}</p>}
                          </div>
                        </div>
                        <div className="mt-4 flex gap-2">
                          <Button type="button" className="min-h-11 flex-1 text-xs font-bold" variant="outline" onClick={() => setSocialConnectOpen(platform.key)}>
                            <Globe className="mr-2 h-4 w-4" /> {status?.connected ? "Quản lý kết nối" : `KẾT NỐI ${platform.name.toUpperCase()}`}
                          </Button>
                          {status?.connected && <Button type="button" className="min-h-11 shrink-0 px-3 text-xs font-bold text-rose-700 hover:bg-rose-50 hover:text-rose-800" variant="outline" onClick={() => {
                            setSocialStatus(previous => {
                              const next = { ...previous };
                              delete next[platform.key];
                              return next;
                            });
                            setSocialConnectOpen(null);
                            toast.success(`Đã ngắt kết nối ${platform.name}. AI Marketing sẽ không dùng kênh này.`);
                          }}>Ngắt kết nối</Button>}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <Dialog open={Boolean(socialConnectOpen)} onOpenChange={(open) => !open && setSocialConnectOpen(null)}>
                  <DialogContent className="max-w-md">
                    {socialConnectOpen && (() => {
                      const platform = socialPlatforms.find(item => item.key === socialConnectOpen);
                      if (!platform) return null;
                      const openAuthorization = () => {
                        const isAssistedSocial = socialRuntimeQuery.data?.mode === "assisted";
                        if (isAssistedSocial) {
                          const assistedUrl = getAssistedSocialUrl(platform.key) || platform.officialUrl;
                          const popup = window.open(assistedUrl, "24seven-social-auth", "popup,width=520,height=720");
                          if (!popup) toast.error("Trình duyệt đang chặn cửa sổ kết nối. Hãy cho phép popup rồi bấm lại.");
                          else toast.info(`Đã mở ${platform.name} chính thức. Hãy đăng nhập trên cửa sổ đó.`);
                          return;
                        }
                        if (platform.key === "zalo" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
                          const fallbackUrl = platform.officialUrl;
                          let appOpened = false;
                          const markAppOpened = () => { appOpened = true; };
                          document.addEventListener("visibilitychange", markAppOpened, { once: true });
                          toast.info("Đang mở ứng dụng Zalo cá nhân...");
                          const zaloAppUrl = /Android/i.test(navigator.userAgent)
                            ? "intent://#Intent;scheme=zalo;package=com.zing.zalo;end"
                            : "zalo://";
                          window.location.href = zaloAppUrl;
                          window.setTimeout(() => {
                            document.removeEventListener("visibilitychange", markAppOpened);
                            if (!appOpened && document.visibilityState === "visible") window.location.href = fallbackUrl;
                          }, 1400);
                          return;
                        }
                        startSocialOAuthMutation.mutate({ platform: platform.key as "facebook" | "zalo" | "tiktok" }, {
                          onSuccess: ({ authorizationUrl }) => {
                            const popup = window.open(authorizationUrl, "24seven-social-auth", "popup,width=520,height=720");
                            if (!popup) toast.error("Trình duyệt đang chặn cửa sổ kết nối. Hãy cho phép popup rồi bấm lại.");
                            else toast.info(`Đã mở ${platform.name}. Hãy đăng nhập và xác nhận trên trang chính thức.`);
                          },
                          onError: (error) => toast.error(`Không thể khởi tạo kết nối ${platform.name}: ${error.message}`),
                        });
                      };
                      const confirmAssistedConnection = () => {
                        setSocialStatus(previous => ({
                          ...previous,
                          [platform.key]: {
                            connected: true,
                            displayName: `${platform.name} trên trình duyệt`,
                            scopes: [],
                            missingScopes: getMissingPublishScopes(platform.key, []),
                          },
                        }));
                        setSocialConnectOpen(null);
                        toast.success(`Đã xác nhận ${platform.name} trên trình duyệt. Sale vẫn tự bấm Đăng ở bước cuối.`);
                      };
                      const isAssistedSocial = socialRuntimeQuery.data?.mode === "assisted";
                      return <>
                        <DialogHeader><DialogTitle>Kết nối mạng xã hội</DialogTitle></DialogHeader>
                        <div className="space-y-4 text-sm">
                          <p className="text-slate-600 dark:text-slate-300">Sale chỉ cần đăng nhập và cấp quyền trên trang chính thức. Không nhập mật khẩu, App ID, App Secret hoặc token vào hệ thống.</p>
                          {platform.key === "zalo" && <div className="rounded-lg border border-dashed border-sky-300 bg-sky-50 p-4 text-center text-xs text-sky-800">Trên điện thoại, hệ thống sẽ ưu tiên mở ứng dụng Zalo cá nhân. Nếu máy không có app hoặc chặn deep-link, hệ thống mới mở trang Zalo web.</div>}
                          {socialStatus[platform.key]?.connected ? <Button type="button" variant="outline" className="min-h-11 w-full font-bold text-rose-700 hover:bg-rose-50" onClick={() => {
                            setSocialStatus(previous => {
                              const next = { ...previous };
                              delete next[platform.key];
                              return next;
                            });
                            setSocialConnectOpen(null);
                            toast.success(`Đã ngắt kết nối ${platform.name}.`);
                          }}>Ngắt kết nối tài khoản này</Button> : isAssistedSocial ? <div className="grid gap-2 sm:grid-cols-2"><Button type="button" className="min-h-11 w-full font-bold" onClick={openAuthorization}><Globe className="mr-2 h-4 w-4" /> Mở trang chính thức</Button><Button type="button" variant="outline" className="min-h-11 w-full font-bold" onClick={confirmAssistedConnection}><CheckCircle2 className="mr-2 h-4 w-4" /> Tôi đã đăng nhập</Button></div> : <Button type="button" className="min-h-11 w-full font-bold" onClick={openAuthorization}><Globe className="mr-2 h-4 w-4" /> Mở trang {platform.name} để xác nhận</Button>}
                          <p className="text-[11px] leading-5 text-slate-500">{isAssistedSocial ? "Không lưu mật khẩu/cookie/token. Sale xác nhận sau khi đăng nhập, rồi tự kiểm tra và bấm Đăng." : "Trạng thái chỉ đổi sau callback OAuth hợp lệ; hệ thống không tạo kết nối mẫu."}</p>
                        </div>
                      </>;
                    })()}
                  </DialogContent>
                </Dialog>
                <div className="flex items-start gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs leading-5 text-slate-600 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-300">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                  <p><strong>Cách dùng:</strong> Sale bấm một lần, đăng nhập và xác nhận trên nền tảng chính thức. Token được giữ ở backend; AI Marketing chỉ đăng nội dung đã được CEO duyệt và kênh đã xác nhận.</p>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-slate-600" /> Cấu Hình System Prompts cho AI Agents
                </CardTitle>
                <CardDescription>Tùy chỉnh hành vi và quy tắc chuyên trách của từng Agent phòng ban</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-medium">Chọn Agent cần cấu hình:</label>
                    <Select value={editingAgentKey} onValueChange={(v) => {
                      setEditingAgentKey(v);
                      const ag = agents.find(a => a.agentKey === v);
                      if (ag) setPromptText(ag.systemPrompt);
                    }}>
                      <SelectTrigger className="text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {agents.map(a => (
                          <SelectItem key={a.agentKey} value={a.agentKey} className="text-xs">{a.name} ({a.agentKey})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-medium">System Prompt độc lập:</label>
                  <Textarea 
                    rows={8}
                    value={promptText || (agents.find(a => a.agentKey === editingAgentKey)?.systemPrompt || "")}
                    onChange={(e) => setPromptText(e.target.value)}
                    className="font-mono text-xs"
                  />
                </div>

                <Button onClick={handleSavePrompt} className="bg-blue-600 hover:bg-blue-500 font-bold text-xs">
                  Lưu Thay Đổi System Prompt
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Modal Tạo Đơn Hàng Thật (AI Sales) */}
        <Dialog open={newOrderModal} onOpenChange={setNewOrderModal}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-base">
                <ShoppingCart className="w-5 h-5 text-emerald-600" /> Tạo Đơn Hàng Thật (AI Sales Pipeline)
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Tên khách hàng / Phòng khám:</label>
                  <Input className="text-xs" placeholder="VD: Nha khoa Sài Gòn Smile" value={orderCustName} onChange={e => setOrderCustName(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold">Số điện thoại:</label>
                  <Input className="text-xs" placeholder="VD: 0909123456" value={orderCustPhone} onChange={e => setOrderCustPhone(e.target.value)} />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold">Địa chỉ giao hàng (Kho Hệ Thống Tự Động xuất đi):</label>
                <Input className="text-xs" placeholder="VD: 123 Nguyễn Trãi, Quận 1, TP.HCM" value={orderCustAddress} onChange={e => setOrderCustAddress(e.target.value)} />
              </div>

              <div className="border-t border-slate-200 dark:border-slate-800 pt-3 space-y-3">
                <h4 className="font-semibold text-xs uppercase text-slate-600">Thêm sản phẩm từ kho Hệ Thống Tự Động:</h4>
                <div className="flex gap-2 items-end">
                  <div className="flex-1">
                    <Select value={selectedProdId} onValueChange={setSelectedProdId}>
                      <SelectTrigger className="text-xs">
                        <SelectValue placeholder="-- Chọn sản phẩm nha khoa --" />
                      </SelectTrigger>
                      <SelectContent>
                        {operationalProducts.map(p => (
                          <SelectItem key={p.id} value={p.id.toString()} className="text-xs">{p.name} - {Number(p.price).toLocaleString('vi-VN')} đ</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="w-20">
                    <Input className="text-xs" type="number" min="1" value={orderQuantity} onChange={e => setOrderQuantity(e.target.value)} placeholder="SL" />
                  </div>
                  <Button onClick={handleAddToCart} className="bg-blue-600 hover:bg-blue-500 text-xs h-9">Thêm</Button>
                </div>

                {/* Cart list */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-2 bg-slate-50 dark:bg-slate-900">
                  <h5 className="text-[11px] font-bold text-slate-500 uppercase">Giỏ hàng đơn thực tế:</h5>
                  {cartItems.length === 0 ? (
                    <p className="text-xs text-slate-400 italic">Chưa có sản phẩm nào trong giỏ.</p>
                  ) : (
                    cartItems.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs bg-white dark:bg-slate-800 p-2 rounded border border-slate-100 dark:border-slate-700">
                        <div>
                          <span className="font-bold">{item.name}</span>
                          <span className="text-slate-500 ml-2">({item.category === 'material' ? 'Vật tư' : 'Thiết bị'})</span>
                        </div>
                        <div className="font-semibold">
                          x{item.quantity} = {(item.price * item.quantity).toLocaleString()} đ
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold">Ghi chú vận hành:</label>
                <Textarea className="text-xs" placeholder="Yêu cầu giao gấp, thanh toán chuyển khoản..." value={orderNotes} onChange={e => setOrderNotes(e.target.value)} />
              </div>

              <Button onClick={handleSubmitOrder} className="w-full bg-emerald-600 hover:bg-emerald-500 font-bold py-3 text-white text-xs">
                Xác Nhận Tạo Đơn Thật & Kích Hoạt Pipeline Tự Động
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal Khởi Tạo Phiên Đàm Phán Đối Tác Mới */}
        <Dialog open={newNegModal} onOpenChange={setNewNegModal}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-base">
                <Briefcase className="w-5 h-5 text-emerald-600" /> Khởi Tạo Phiên Đàm Phán Đối Tác (AI CEO)
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-1">
                <label className="text-xs font-semibold">Tên đối tác / Nhà cung cấp:</label>
                <Input className="text-xs" placeholder="VD: Công ty Thiết bị Nha khoa DentalTech" value={negPartnerName} onChange={e => setNegPartnerName(e.target.value)} />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold">Loại đối tác:</label>
                <Select value={negPartnerType} onValueChange={setNegPartnerType}>
                  <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Nhà cung cấp vật tư" className="text-xs">Nhà cung cấp vật tư tiêu hao</SelectItem>
                    <SelectItem value="Nhà phân phối thiết bị" className="text-xs">Nhà phân phối thiết bị độc quyền</SelectItem>
                    <SelectItem value="Phòng khám đối tác chiến lược" className="text-xs">Phòng khám đối tác chiến lược</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold">Mục tiêu đàm phán tối đa hóa quyền lợi:</label>
                <Textarea className="text-xs" placeholder="VD: Đòi chiết khấu sỉ 25%, công nợ gối đầu 60 ngày và hỗ trợ marketing tại kho Hệ Thống Tự Động..." value={negObjective} onChange={e => setNegObjective(e.target.value)} />
              </div>
              <Button onClick={() => {
                if (!negPartnerName.trim() || !negObjective.trim()) {
                  toast.error("Vui lòng điền đầy đủ tên đối tác và mục tiêu đàm phán!");
                  return;
                }
                startNegMutation.mutate({
                  partnerName: negPartnerName,
                  partnerType: negPartnerType,
                  objective: negObjective,
                }, {
                  onSuccess: () => {
                    setNewNegModal(false);
                    setNegPartnerName("");
                    setNegObjective("");
                  }
                });
              }} className="w-full bg-emerald-600 hover:bg-emerald-500 font-bold py-2.5 text-white text-xs">
                Yêu Cầu AI CEO Bắt Đầu Đàm Phán & Tối Ưu
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
