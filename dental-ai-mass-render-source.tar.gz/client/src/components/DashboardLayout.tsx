import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { trpc } from "@/lib/trpc";
import { COOKIE_NAME } from "@shared/const";
import {
  clearDealerIdentity,
  dealerIdentityKey,
  getOrCreateDealerIdentity,
  saveDealerIdentity,
  type DealerIdentity,
} from "@/lib/dealerIdentity";
import { useIsMobile } from "@/hooks/useMobile";
import { LayoutDashboard, LogIn, LogOut, PanelLeft } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';

const menuItems = [
  { icon: LayoutDashboard, label: "Tổng quan", path: "/" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    try {
      const saved = window.localStorage.getItem(SIDEBAR_WIDTH_KEY);
      const parsed = saved ? Number.parseInt(saved, 10) : DEFAULT_WIDTH;
      return Number.isFinite(parsed) ? parsed : DEFAULT_WIDTH;
    } catch {
      return DEFAULT_WIDTH;
    }
  });
  const { loading: authLoading, user: authUser } = useAuth();
  const [dealer, setDealer] = useState<DealerIdentity>(() => getOrCreateDealerIdentity());
  const [isRestoringSession, setIsRestoringSession] = useState(true);
  const activatedDealerKeyRef = useRef<string | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
    } catch {
      // Sidebar width is only a preference; the dashboard remains usable if storage is blocked.
    }
  }, [sidebarWidth]);

  const utils = trpc.useUtils();
  const ownerLoginMutation = trpc.auth.ownerLogin.useMutation({
    onSuccess: async data => {
      try {
        if (data.sessionToken) {
          sessionStorage.setItem("manus-cookie", `${COOKIE_NAME}=${data.sessionToken}`);
        }
      } catch {
        // Storage may be blocked; the HttpOnly cookie remains the primary path.
      }
      setIsRestoringSession(false);
      await utils.auth.me.invalidate();
    },
    onError: () => {
      // Không chặn giao diện bằng popup. Backend vẫn sẽ trả lỗi rõ ràng cho thao tác cần Owner.
      setIsRestoringSession(false);
    },
  });

  const handleDealerLogin = (input: { name: string; phone: string; email: string }) => {
    const savedIdentity = saveDealerIdentity(input);
    if (!savedIdentity) return false;

    activatedDealerKeyRef.current = null;
    setDealer(savedIdentity);
    setIsRestoringSession(true);
    return true;
  };

  const handleDealerLogout = () => {
    clearDealerIdentity();
    activatedDealerKeyRef.current = null;
    setDealer(getOrCreateDealerIdentity());
    setIsRestoringSession(true);
  };

  useEffect(() => {
    if (authLoading) return;

    const identityKey = dealerIdentityKey(dealer);
    if (activatedDealerKeyRef.current === identityKey) return;

    if (authUser?.role === "admin") {
      activatedDealerKeyRef.current = identityKey;
      setIsRestoringSession(false);
      return;
    }

    activatedDealerKeyRef.current = identityKey;
    ownerLoginMutation.mutate(dealer);
  }, [dealer, authLoading, authUser?.role, ownerLoginMutation]);

  if (authLoading || isRestoringSession || ownerLoginMutation.isPending) {
    return <DashboardLayoutSkeleton />;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <DashboardLayoutContent
        dealer={dealer}
        onDealerLogin={handleDealerLogin}
        onDealerLogout={handleDealerLogout}
        setSidebarWidth={setSidebarWidth}
      >
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}


type DashboardLayoutContentProps = {
  children: React.ReactNode;
  dealer: DealerIdentity;
  onDealerLogin: (input: { name: string; phone: string; email: string }) => boolean;
  onDealerLogout: () => void;
  setSidebarWidth: (width: number) => void;
};

function DashboardLayoutContent({
  children,
  dealer,
  onDealerLogin,
  onDealerLogout,
  setSidebarWidth,
}: DashboardLayoutContentProps) {
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeMenuItem = menuItems.find(item => item.path === location);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (isCollapsed) {
      setIsResizing(false);
    }
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;

      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar
          collapsible="icon"
          className="border-r-0"
          disableTransition={isResizing}
        >
          <SidebarHeader className="h-16 justify-center">
            <div className="flex items-center gap-3 px-2 transition-all w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
                aria-label="Toggle navigation"
              >
                <PanelLeft className="h-4 w-4 text-muted-foreground" />
              </button>
              {!isCollapsed ? (
                <div className="flex items-center gap-2 min-w-0">
                  <span className="font-semibold tracking-tight truncate">
                    Navigation
                  </span>
                </div>
              ) : null}
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0">
            <SidebarMenu className="px-2 py-1">
              {menuItems.map(item => {
                const isActive = location === item.path;
                return (
                  <SidebarMenuItem key={item.path}>
                    <SidebarMenuButton
                      isActive={isActive}
                      onClick={() => setLocation(item.path)}
                      tooltip={item.label}
                      className={`h-10 transition-all font-normal`}
                    >
                      <item.icon
                        className={`h-4 w-4 ${isActive ? "text-primary" : ""}`}
                      />
                      <span>{item.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="p-3">
            <div
              className="flex items-center gap-3 rounded-lg px-1 py-1 group-data-[collapsible=icon]:justify-center"
              aria-label={`Chủ đại lý: ${dealer.name}, ${dealer.phone}`}
            >
              <Avatar className="h-9 w-9 border shrink-0">
                <AvatarFallback className="text-xs font-medium">
                  {dealer.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                <p className="text-sm font-medium truncate leading-none">
                  {dealer.name}
                </p>
                <p className="text-xs text-muted-foreground truncate mt-1.5">
                  {dealer.phone}
                </p>
                <p className="text-[10px] text-muted-foreground/80 truncate mt-1">
                  Chủ đại lý
                </p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => {
            if (isCollapsed) return;
            setIsResizing(true);
          }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset>
        <DealerSessionControl
          dealer={dealer}
          onLogin={onDealerLogin}
          onLogout={onDealerLogout}
        />
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-2 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg bg-background" />
              <div className="flex items-center gap-3">
                <div className="flex flex-col gap-1">
                  <span className="tracking-tight text-foreground">
                    {activeMenuItem?.label ?? "Menu"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
        <main className="flex-1 p-4 pb-16">{children}</main>
      </SidebarInset>
    </>
  );
}


function DealerSessionControl({
  dealer,
  onLogin,
  onLogout,
}: {
  dealer: DealerIdentity;
  onLogin: (input: { name: string; phone: string; email: string }) => boolean;
  onLogout: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState(() => ({
    name: dealer.name,
    phone: dealer.phone,
    email: dealer.email,
  }));
  const [error, setError] = useState("");

  useEffect(() => {
    setForm({ name: dealer.name, phone: dealer.phone, email: dealer.email });
  }, [dealer]);

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const saved = onLogin(form);
    if (!saved) {
      setError("Vui lòng nhập đúng Tên, SĐT và Email.");
      return;
    }
    setError("");
    setIsOpen(false);
  };

  return (
    <div className="fixed right-3 top-3 z-[60]">
      <div className="flex items-center gap-1 rounded-full border border-slate-200 bg-white/95 p-1 shadow-md backdrop-blur dark:border-slate-700 dark:bg-slate-900/95">
        <span
          className="hidden max-w-32 truncate px-2 text-xs font-medium text-slate-700 sm:block dark:text-slate-200"
          title={dealer.name}
        >
          {dealer.name}
        </span>
        <button
          type="button"
          onClick={() => {
            setError("");
            setIsOpen((value) => !value);
          }}
          className="inline-flex h-8 items-center gap-1 rounded-full px-2.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:text-slate-200 dark:hover:bg-slate-800"
          aria-expanded={isOpen}
          aria-controls="dealer-session-form"
        >
          <LogIn className="h-3.5 w-3.5" />
          <span>Đăng nhập</span>
        </button>
        <button
          type="button"
          onClick={() => {
            onLogout();
            setError("");
            setIsOpen(false);
          }}
          className="inline-flex h-8 items-center gap-1 rounded-full bg-slate-100 px-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
          title="Đăng xuất khỏi thông tin đại lý đang lưu"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Đăng xuất</span>
        </button>
      </div>

      {isOpen && (
        <form
          id="dealer-session-form"
          onSubmit={submit}
          className="absolute right-0 mt-2 w-64 rounded-xl border border-slate-200 bg-white p-3 shadow-xl dark:border-slate-700 dark:bg-slate-900"
        >
          <p className="mb-2 text-xs font-semibold text-slate-800 dark:text-slate-100">
            Thông tin đại lý
          </p>
          <div className="space-y-2">
            <input
              value={form.name}
              onChange={(event) => setForm({ ...form, name: event.target.value })}
              placeholder="Họ tên"
              aria-label="Họ tên đại lý"
              className="h-8 w-full rounded-md border border-slate-200 bg-transparent px-2 text-xs outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700"
            />
            <input
              value={form.phone}
              onChange={(event) => setForm({ ...form, phone: event.target.value })}
              placeholder="Số điện thoại"
              aria-label="Số điện thoại đại lý"
              className="h-8 w-full rounded-md border border-slate-200 bg-transparent px-2 text-xs outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700"
            />
            <input
              value={form.email}
              onChange={(event) => setForm({ ...form, email: event.target.value })}
              placeholder="Email"
              aria-label="Email đại lý"
              className="h-8 w-full rounded-md border border-slate-200 bg-transparent px-2 text-xs outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700"
            />
          </div>
          {error && <p className="mt-2 text-[11px] text-red-600">{error}</p>}
          <button
            type="submit"
            className="mt-3 h-8 w-full rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white transition hover:bg-indigo-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            Lưu thông tin
          </button>
        </form>
      )}
    </div>
  );
}
