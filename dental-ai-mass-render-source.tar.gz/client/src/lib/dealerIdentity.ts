export const DEALER_IDENTITY_STORAGE_KEY = "dental-zero-touch-dealer";

export const DEFAULT_DEALER_IDENTITY = {
  name: "Trương Huỳnh Minh Tân",
  phone: "0963.166.698",
  email: "owner@24sevenhc.com.vn",
  role: "owner",
} as const;

export type DealerIdentity = {
  name: string;
  phone: string;
  email: string;
  role: "owner";
};

type DealerIdentityInput = {
  name?: unknown;
  phone?: unknown;
  email?: unknown;
};

type StorageLike = Pick<Storage, "getItem" | "setItem" | "removeItem">;

function getBrowserStorage(): StorageLike | undefined {
  if (typeof window === "undefined") return undefined;
  try {
    return window.localStorage;
  } catch {
    return undefined;
  }
}

export function normalizeDealerIdentity(
  input: DealerIdentityInput,
): DealerIdentity | null {
  const name = typeof input.name === "string" ? input.name.trim() : "";
  const phone = typeof input.phone === "string" ? input.phone.trim() : "";
  const email = typeof input.email === "string" ? input.email.trim() : "";

  if (!name || !phone || !email) return null;

  const normalizedPhone = phone.replace(/[\s.-]/g, "");
  const isVietnamesePhone = /^(?:\+84|84|0)\d{8,10}$/.test(normalizedPhone);
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  if (!isVietnamesePhone || !isEmail) return null;

  return {
    name,
    phone,
    email,
    role: "owner",
  };
}

export function readDealerIdentity(
  storage: StorageLike | undefined = getBrowserStorage(),
): DealerIdentity {
  if (!storage) return DEFAULT_DEALER_IDENTITY;

  try {
    const raw = storage.getItem(DEALER_IDENTITY_STORAGE_KEY);
    if (!raw) return DEFAULT_DEALER_IDENTITY;
    return normalizeDealerIdentity(JSON.parse(raw) as DealerIdentityInput) ?? DEFAULT_DEALER_IDENTITY;
  } catch {
    return DEFAULT_DEALER_IDENTITY;
  }
}

export function saveDealerIdentity(
  input: DealerIdentityInput,
  storage: StorageLike | undefined = getBrowserStorage(),
): DealerIdentity | null {
  const identity = normalizeDealerIdentity(input);
  if (!identity || !storage) return null;

  try {
    storage.setItem(DEALER_IDENTITY_STORAGE_KEY, JSON.stringify(identity));
    return identity;
  } catch {
    return null;
  }
}

export function clearDealerIdentity(
  storage: StorageLike | undefined = getBrowserStorage(),
): void {
  try {
    storage?.removeItem(DEALER_IDENTITY_STORAGE_KEY);
  } catch {
    // Ignore storage errors so the UI can still return to setup mode.
  }
}

export function dealerIdentityKey(identity: DealerIdentity): string {
  return `${identity.name}|${identity.phone}|${identity.email}`;
}

export function getOrCreateDealerIdentity(
  storage: StorageLike | undefined = getBrowserStorage(),
): DealerIdentity {
  const identity = readDealerIdentity(storage);
  try {
    storage?.setItem(DEALER_IDENTITY_STORAGE_KEY, JSON.stringify(identity));
  } catch {
    // localStorage có thể bị chặn; vẫn cho phép hệ thống chạy với identity mặc định trong bộ nhớ.
  }
  return identity;
}
