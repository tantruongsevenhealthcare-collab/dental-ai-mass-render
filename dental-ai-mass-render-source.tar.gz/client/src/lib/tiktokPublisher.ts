export type TikTokPublisherInput = {
  script: string;
  landingUrl?: string | null;
  productName?: string | null;
  mediaUrl?: string | null;
  sourceId?: number | string;
};

function productHashtag(productName?: string | null): string {
  const value = productName?.trim().replace(/[^a-zA-Z0-9]+/g, "").slice(0, 40);
  return value ? `#${value}` : "#VatLieuNhaKhoa";
}

export function composeTikTokCaption(input: TikTokPublisherInput): string {
  const script = input.script.trim();
  const landingUrl = input.landingUrl?.trim();
  const hasHashtag = /(^|\s)#\S+/.test(script);
  const hashtags = hasHashtag ? "" : `\n\n#NhaKhoa #DentalAI ${productHashtag(input.productName)}`;
  const destination = landingUrl ? `\n\nXem chi tiết tại: ${landingUrl}` : "";
  return `${script}${hashtags}${destination}`.trim();
}

export function createTikTokPublisherPayload(input: TikTokPublisherInput) {
  return {
    type: "TIKTOK_MOBILE_SHARE" as const,
    approved: true as const,
    platform: "tiktok" as const,
    content: composeTikTokCaption(input),
    mediaUrl: input.mediaUrl?.trim() || null,
    productName: input.productName?.trim() || null,
    sourceId: input.sourceId == null ? null : String(input.sourceId),
  };
}
