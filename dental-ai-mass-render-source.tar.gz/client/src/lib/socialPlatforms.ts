export const socialPlatforms = [
  {
    key: "facebook",
    name: "Facebook cá nhân",
    mark: "f",
    color: "bg-blue-600",
    description: "Mở Facebook chính thức để Sale đăng nhập tài khoản cá nhân; giữ nguyên cơ chế mở app/fallback hiện tại.",
    officialUrl: "https://www.facebook.com/",
  },
  {
    key: "zalo",
    name: "Zalo cá nhân",
    mark: "Z",
    color: "bg-sky-500",
    description: "Mở Zalo cá nhân để Sale đăng nhập và xác nhận tài khoản; không dùng luồng Zalo Business/OA.",
    officialUrl: "https://id.zalo.me/",
  },
  {
    key: "tiktok",
    name: "TikTok cá nhân",
    mark: "♪",
    color: "bg-slate-950",
    description: "Mở TikTok chính thức để Sale đăng nhập tài khoản cá nhân; giữ nguyên cơ chế mở app hiện tại.",
    officialUrl: "https://www.tiktok.com/login",
  },
] as const;

export const requiredPublishScopes: Record<(typeof socialPlatforms)[number]["key"], string[]> = {
  facebook: ["pages_manage_posts"],
  zalo: ["oa.post"],
  tiktok: ["video.publish"],
};

export function getMissingPublishScopes(platform: string, grantedScopes: string[]): string[] {
  return (requiredPublishScopes[platform as keyof typeof requiredPublishScopes] || []).filter(scope => !grantedScopes.includes(scope));
}

export function getAssistedSocialUrl(platform: string): string | undefined {
  return socialPlatforms.find(item => item.key === platform)?.officialUrl;
}
