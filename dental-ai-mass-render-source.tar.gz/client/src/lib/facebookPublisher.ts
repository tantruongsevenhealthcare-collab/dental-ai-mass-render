export type FacebookPublisherInput = {
  content: string;
  landingUrl?: string | null;
  mediaUrl?: string | null;
  productName?: string | null;
  sourceId?: number | string;
};

export function composeFacebookPost(input: FacebookPublisherInput): string {
  const content = input.content.trim();
  const landingUrl = input.landingUrl?.trim();
  if (!landingUrl) return content;
  return `${content}\n\nXem chi tiết tại: ${landingUrl}`;
}

export function createFacebookPublisherPayload(input: FacebookPublisherInput) {
  return {
    type: "DENTAL_AI_APPROVED_POST" as const,
    approved: true as const,
    platform: "facebook" as const,
    content: composeFacebookPost(input),
    mediaUrl: input.mediaUrl?.trim() || null,
    productName: input.productName?.trim() || null,
    sourceId: input.sourceId == null ? null : String(input.sourceId),
  };
}
