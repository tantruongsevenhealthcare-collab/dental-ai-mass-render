export type DashboardOrder = { status?: string | null };
export type DashboardProposal = { status?: string | null };
export type DashboardAgent = { name: string; agentKey: string };
export type DashboardAgentLog = { agentKey?: string | null };

export const summarizeOrderStatuses = (orders: DashboardOrder[]) =>
  Object.entries(
    orders.reduce<Record<string, number>>((summary, order) => {
      const status = order.status || "unknown";
      summary[status] = (summary[status] || 0) + 1;
      return summary;
    }, {}),
  ).map(([status, value]) => ({ status, value }));

export const summarizeProposalStatuses = (proposals: DashboardProposal[]) => {
  const summary = proposals.reduce(
    (result, proposal) => {
      if (proposal.status === "approved" || proposal.status === "auto_approved") result.approved += 1;
      else result.pending += 1;
      return result;
    },
    { approved: 0, pending: 0 },
  );

  return [
    { name: "Đã duyệt", value: summary.approved, fill: "#059669" },
    { name: "Chờ duyệt", value: summary.pending, fill: "#f59e0b" },
  ].filter((item) => item.value > 0);
};

export const summarizeAgentActivity = (agents: DashboardAgent[], logs: DashboardAgentLog[]) =>
  agents.map((agent) => ({
    name: agent.name.replace(/^AI\s+/i, "").slice(0, 12),
    interactions: logs.filter((log) => log.agentKey === agent.agentKey).length,
  }));
