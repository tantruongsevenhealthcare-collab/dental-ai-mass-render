# Deploy Dental AI Mass lên Render

Dự án được cấu hình để chạy **một Web Service Node.js duy nhất**. Process này vừa phục vụ frontend React đã build vừa phục vụ Express/tRPC, Manus OAuth, callback social và các API nghiệp vụ. Render phải cấp biến `PORT`; ứng dụng bind `0.0.0.0` và health check tại `/healthz`.

## Cấu hình dịch vụ

Blueprint nằm tại `render.yaml` ở thư mục gốc. Khi tạo Web Service từ repository, dùng các lệnh tương đương:

```text
Build Command: corepack enable && pnpm install --frozen-lockfile && pnpm build
Start Command: pnpm start
Health Check Path: /healthz
```

Sau deploy, Render cấp URL dạng `https://<service-name>.onrender.com`. Đặt giá trị này vào `PUBLIC_APP_URL` để OAuth callback dùng đúng domain; nếu bỏ trống, backend dùng `RENDER_EXTERNAL_URL` của Render.

## Biến môi trường bắt buộc

Nhập các biến `DATABASE_URL`, `OAUTH_SERVER_URL`, `VITE_APP_ID`, `VITE_OAUTH_PORTAL_URL`, các biến `BUILT_IN_FORGE_*`, `OWNER_*` và sáu credentials social trong Render Dashboard. Không đưa secret vào mã nguồn hoặc frontend. Có thể để Render tự sinh `JWT_SECRET` và `SOCIAL_TOKEN_ENCRYPTION_KEY` theo Blueprint.

Redirect URI sau khi có URL Render:

```text
https://<service-name>.onrender.com/api/oauth/callback
https://<service-name>.onrender.com/api/social/facebook/callback
https://<service-name>.onrender.com/api/social/zalo/callback
https://<service-name>.onrender.com/api/social/tiktok/callback
```

Các URL chính xác cần đối chiếu với route callback trong Developer Console từng nền tảng trước khi bật OAuth Production.

## Kiểm tra sau deploy

Mở `https://<service-name>.onrender.com/healthz`; kết quả hợp lệ là JSON có `status: "ok"`. Sau đó mở trang chính, kiểm tra đăng nhập Manus, gọi một query tRPC và thử từng callback social. Free Web Service có thể ngủ khi không có traffic; nếu cần phản hồi 24/7 không cold start, chọn gói chạy liên tục của Render.

## Webhook

Các webhook phải được cấu hình vào URL HTTPS của Web Service và xác thực chữ ký/shared secret ở backend trước khi ghi dữ liệu khách hàng hoặc đơn hàng. Không dùng URL localhost và không lưu raw password/cookie social.

## Add to Home Screen

Trên iPhone: mở URL bằng Safari, bấm **Share**, chọn **Add to Home Screen**, rồi bấm **Add**. Trên Android: mở URL bằng Chrome, bấm menu ba chấm, chọn **Add to Home screen** hoặc **Install app**, rồi xác nhận.
