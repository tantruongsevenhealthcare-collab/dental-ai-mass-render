# Hướng dẫn Vận hành Hệ thống Đa tác nhân AI (Zero-Touch MAS)
**Tập đoàn Phân phối Vật tư & Thiết bị Nha khoa: 24 Seven Health Care Vietnam**
- **Kho trung tâm**: 17 Phạm Vấn, Tân Phú, TP.HCM
- **Hotline/Zalo**: 0963166698 | **Website**: https://www.24sevenhc.com.vn/
- **Google Sheets Catalogue**: [Master Data Google Sheets](https://docs.google.com/spreadsheets/d/19WB-7Lf8rzG9vYcqW_1-ZN0SB_VT0AlT0QP8H1pRzgE/edit?usp=sharing)

---

## 1. Mô hình Vận hành Zero-Touch & 5 AI Agents
Hệ thống vận hành hoàn toàn tự động theo mô hình Zero-Touch (không ôm hàng, tự động hóa toàn bộ từ Sales đến Kho và Kế toán):
1. **AI CEO**: Trung tâm điều hành thông minh. Vào lúc 08:00 sáng mỗi ngày, AI CEO tự động tổng hợp báo cáo và kích hoạt **Decision Engine** (với 4 bộ quy tắc: Tồn kho 17 Phạm Vấn, Giá niêm yết, An toàn y khoa, KPI ngày) để tự phê duyệt hoặc tạm giữ các đề xuất vận hành. AI CEO còn có **Partner Negotiation Engine** để thay mặt doanh nghiệp đàm phán quyền lợi tối đa với đối tác.
2. **AI Marketing**: Nghiên cứu thị trường hằng ngày, lập lịch đăng bài tự động trên Facebook & Zalo OA, đồng thời quản lý khu vực TikTok Livestream và thư viện video hướng dẫn sử dụng sản phẩm.
3. **AI Sales**: Tư vấn chuyên sâu dựa trên nguồn dữ liệu gốc Google Sheets, tiếp nhận thông tin khách hàng, kiểm tra tồn kho tại 17 Phạm Vấn và tạo đơn nháp trước khi chuyển tự động sang Kho & Kế toán.
4. **AI Kho**: Quản lý trung tâm kho 17 Phạm Vấn, giám sát tồn kho và cảnh báo đơn kẹt quá 24h.
5. **AI Kế toán**: Ghi nhận doanh số thực tế, phân tách tỷ lệ Vật tư / Thiết bị và tính toán hoa hồng minh bạch.

---

## 2. Hướng dẫn Sử dụng Google Sheets làm Nguồn Catalogue
- Bảng dữ liệu gốc đặt tại: `https://docs.google.com/spreadsheets/d/19WB-7Lf8rzG9vYcqW_1-ZN0SB_VT0AlT0QP8H1pRzgE/edit?usp=sharing`
- Để đồng bộ thủ công dữ liệu sản phẩm mới nhất từ Google Sheets vào hệ thống:
  1. Truy cập tab **AI Sales** hoặc bảng điều khiển sản phẩm trên giao diện.
  2. Bấm nút **"Đồng bộ Sheet"** để hệ thống tự động tải tệp CSV xuất bản, phân tích đặc tính, đơn giá, giá VAT và cập nhật cơ sở dữ liệu thời gian thực.
  3. Hoặc chạy script CLI tại thư mục dự án: `pnpm exec tsx scripts/sync-google-sheet.mjs`.

---

## 3. Quy trình Chốt đơn & Khóa Giá Server-Side
- Mọi đơn hàng do AI Sales hoặc khách hàng tạo lập đều phải thông qua thủ tục xác thực server-side: hệ thống tự động truy vấn giá chính thức từ cơ sở dữ liệu sản phẩm (bắt nguồn từ Google Sheets), tuyệt đối không tin tưởng mức giá do client gửi lên nhằm chống gian lận và sai lệch tài chính.
- Sau khi xác nhận đơn, đơn hàng tự động chuyển sang trạng thái xử lý (`processing`), trừ tồn kho tại 17 Phạm Vấn và ghi log sang Kho & Kế toán.
